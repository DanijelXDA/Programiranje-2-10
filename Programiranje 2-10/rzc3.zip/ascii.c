/* ascii.c - Prikazivanje tablice ASCII kodova.                           */

#include <stdio.h>

main () {
  char c; int i;

  printf ("\t\t  Tablica ASCII kodova\n\n");
  for (c=' '; c<' '+19; c++) {
    for (i=0; i<95; i+=19)
      printf ("%3d  %c      ", c+i, c+i);
    putchar ('\n');
  }
}
