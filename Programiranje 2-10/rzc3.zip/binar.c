/* binar.c - Ispisivanje u binarnom brojevnom sistemu.                    */

#include <stdio.h>

main () {
  short dec, i, bit;
  while (1) {
    printf ("Decimalni broj? "); scanf ("%hd", &dec);
  if (dec == 9999) break;
    printf ("Binarni broj:   ");
    for (i=1; i<=16; i++) {
      bit = (dec & 0x8000) != 0;
      printf ("%d", bit);
      if (i % 4 == 0) printf (" ");
      dec <<= 1;
    }
    printf ("\n");
  }
}
