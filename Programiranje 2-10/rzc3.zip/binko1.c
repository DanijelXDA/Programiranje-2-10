/* binko1.c - Ispisivanje binomnih koeficijenata.                         */

#include <stdio.h>

main () {
  int n, k, nmax, b[20];
  printf ("nmax? "); scanf ("%d", &nmax);
  printf ("\n");
  for (n=0; n<=nmax; n++) {
    b[n] = 1;
    for (k=n-1; k>0; k--) b[k] += b[k-1];
    for (k=0; k<=n; printf ("%4d", b[k++]));
    printf ("\n");
  }
}
