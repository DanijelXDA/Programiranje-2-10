/* binko2.c - Izracunavanje datog binomnog koeficijenta.                  */

int binko (int n, int k) {
  int i, j, b;
  for (b=i=1, j=n; i<=k; b=b*j--/i++);
  return b;
}

/* Ispisivanje Paskalovog trougla.                                        */

#include <stdio.h>

main () {
  int n, k, i, nmax;
  printf ("nmax? "); scanf ("%d", &nmax);
  putchar ('\n');
  for (n=0; n<=nmax; n++) {
    for (i=0; i<nmax-n; i++) printf ("  ");
    for (k=0; k<=n; k++) printf ("%4d", binko (n, k));
    putchar ('\n');
  }
}
