/* binko3.c - Rekurzivna funkcija za racunanje binomnog koeficijenta.     */

int binko (int n, int k) {
  return (0<k && k<n) ? binko (n-1, k-1) + binko (n-1, k) : 1;
}

#include <stdio.h>
#include <stdlib.h>

void main (int bpar, const char *vpar[]) {
  int n, k, nmax = atoi (vpar[1]);
  for (n=0; n<=nmax; n++) {
    for (k=0; k<=n; k++)
      printf ("%4d", binko (n, k));
    putchar ('\n');
  }
}
