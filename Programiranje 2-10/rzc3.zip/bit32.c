/* bit32.c - Raspakivanje 32-bitnog celobrojnog podatka.                  */

#include <stdio.h>

void bit32 (unsigned long k, char a[]) {
  int i;
  for (i=31; i>=0; i--) {
    a[i] = k & 1;
    k >>= 1;
  }
}

/* Ispitivanje funkcije bit32.                                            */

void main () {
  unsigned long broj; char bit[32]; int i;
  while (1) {
    scanf ("%lx", &broj);
  if (broj == 0x9999) break;
    printf ("Procitani broj: %lx\n", broj);
    bit32 (broj, bit);
    printf ("Bitovi broja:   ");
    for (i=0; i<32; i++) {
      printf("%d", bit[i]);
      if (i%4 == 3) putchar (' ');
    }
    printf ("\n\n");
  }
}
