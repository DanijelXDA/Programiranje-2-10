/* bitovi.c - Brojanje bitova.                                            */

#include <stdio.h>

int jedan (unsigned long k)                             /* Broj jedinica. */
  { int n; for (n=0; k; k>>=1) n += k & 1; return n; }

int nula (unsigned long k) { return jedan (~k); }       /* Broj nula.     */

void main () {                      /* Ispitivanje funkcija jedan i nula. */
  unsigned long k;
  while (1) {
    printf ("Heksadecimalni broj? "); scanf ("%lx", &k);
  if (k == 0x9999) break;
    printf ("Broj jedinica:       %d\n",   jedan (k));
    printf ("Broj nula:           %d\n\n", nula  (k));
  }
}
