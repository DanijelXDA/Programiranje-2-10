/* broj.c - Brojevi elemenata niza s pojedinim ostacima.                  */

#include <stdio.h>
#define N 50
#define K 20

void broj (const int a[], int n, int b[], int k) {
  int i;
  for (i=0; i<k; b[i++]=0);
  for (i=0; i<n; b[a[i++]%k]++);
}

/* Ispitivanje funkcije broj.                                             */

main () {
  int a[N], b[K], i, n, k;
  while (1) {
    printf ("n? "); scanf ("%d", &n);
  if (n<=0 || n>N) break;
    printf ("A? ");
    for (i=0; i<n; scanf ("%d", &a[i++]));
    printf ("k? "); scanf ("%d", &k);
    broj (a, n, b, k);
    printf ("B=");
    for (i=0; i<k; printf (" %d",b[i++]));
    printf ("\n\n");
  }
}
