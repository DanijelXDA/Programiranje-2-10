/* cifre1.c - Odredjivanje broja cifara u znakovnom nizu.                 */

#include <stdio.h>
#include <ctype.h>

int cifre (char niz[]) {
  int n=0, i=0;
  while (niz[i]) n += isdigit (niz[i++]) != 0;
  return n;
}

/* Ispitivanje funkcije cifre. */

void main () {
  char red[81]; int uk=0, n=0; float s;
  while (1) {
    gets (red);
  if (red[0] == '\0') break;      /* strlen(red)==0 */
    uk += cifre (red); n++;
  }
  s = n ? (float) uk / n : 0;
  printf ("Srednji broj cifara: %f\n", s);
}
