/* cifre2.c - Broj pojavljivanja pojedinih cifara u tekstualnoj datoteci. */

#include <stdio.h>
#include <ctype.h>

int cifre (char *imedat, int broj[10]) {
  FILE *dat = fopen (imedat, "r");
  if (dat) {
    int i, zn;
    for (i=0; i<10; broj[i++]=0);
    while ((zn = fgetc (dat)) != EOF)
      if (isdigit (zn)) broj[zn-'0']++;
    fclose (dat);
    return 1;
  } else return 0;
}

void main (int bpar, char *vpar[]) {
  int i, broj[10];
  if (cifre (vpar[1], broj))
    for (i=0; i<10; i++)
      if (broj[i])
        printf ("Cifra %d se pojavljuje %d puta.\n", i, broj[i]);
}
