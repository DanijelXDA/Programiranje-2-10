/* dimmat.c - Definicije paketa funkcija za obradu dinamickih matrica.    */

#include "dinmat.h"
#include <stdlib.h>
#include <stdio.h>

typedef enum {MEM, DIM} Greska;                      /* Sifre greasaka.   */

const char *poruke[] = { "Neuspela dodela memorije", /* Poruke o greskama.*/
                         "Neusaglasene dimenzije matrica"
                       };

static void greska (Greska g) {           /* Ispisivanje poruke o gresci. */
  printf ("\n*** %s! ***\n\a", poruke[g]);
  exit (g+1);
}

Din_mat stvori (int m, int n) {                   /* Dodela memorije.     */
  int i; Din_mat dm;
  dm.m = m; dm.n = n;
  if ((dm.a = malloc (m * sizeof(float*))) == NULL) greska (MEM);
  for (i=0; i<m; i++)
    if ((dm.a[i] = malloc (n * sizeof(float))) == NULL) greska (MEM);
  return dm;
}

void unisti (Din_mat dm) {                        /* Oslobadjanje memorije*/
  int i;
  for (i=0; i<dm.m; free(dm.a[i++]));
  free (dm.a);
}

Din_mat kopiraj (Din_mat dm) {                    /* Kopiranje matrice.   */
  int i, j;
  Din_mat dm2 = stvori (dm.m, dm.n);
  for (i=0; i<dm.m; i++)
    for (j=0; j<dm.n; j++)
      dm2.a[i][j] = dm.a[i][j];
  return dm2;
}

Din_mat citaj (int m, int n) {                    /* Citanje matrice.     */
  int i, j;
  Din_mat dm = stvori (m, n);
  for (i=0; i<m; i++)
    for (j=0; j<n; scanf("%f",&dm.a[i][j++]));
  return dm;
}

void pisi (Din_mat dm, const char *frm, int max){ /* Ispisivanje matrice. */
  int i, j;
  for (i=0; i<dm.m; i++) {
    for (j=0; j<dm.n; j++) {
      printf (frm, dm.a[i][j]);
      putchar ((j%max==max-1 || j==dm.n-1) ? '\n' : ' ');
    }
    if (dm.n > max) putchar ('\n');
  }
}

Din_mat transpon (Din_mat dm) {                   /* Transponovana matrica*/
  int i, j;
  Din_mat dm2 = stvori (dm.n, dm.m);
  for (i=0; i<dm.m; i++)
    for (j=0; j<dm.n; j++) dm2.a[j][i] = dm.a[i][j];
  return dm2;
}

Din_mat zbir (Din_mat dm1, Din_mat dm2) {         /* Zbir matrica.        */
  int i, j; Din_mat dm3;
  if (dm1.m!=dm2.m || dm1.n != dm2.n) greska (DIM);
  dm3 = stvori (dm1.m, dm1.n);
  for (i=0; i<dm3.m; i++)
    for (j=0; j<dm3.n; j++)
      dm3.a[i][j] = dm1.a[i][j] + dm2.a[i][j];
  return dm3;
}

Din_mat razlika (Din_mat dm1, Din_mat dm2) {      /* Razlika matrica.     */
  int i, j; Din_mat dm3;
  if (dm1.m!=dm2.m || dm1.n != dm2.n) greska (DIM);
  dm3 = stvori (dm1.m, dm1.n);
  for (i=0; i<dm3.m; i++)
    for (j=0; j<dm3.n; j++)
      dm3.a[i][j] = dm1.a[i][j] - dm2.a[i][j];
  return dm3;
}

Din_mat proizvod (Din_mat dm1, Din_mat dm2) {     /* Proizvod matrica.    */
  int i, j, k; Din_mat dm3;
  if (dm1.n!=dm2.m) greska (DIM);
  dm3 = stvori (dm1.m, dm2.n);
  for (i=0; i<dm3.m; i++)
    for (k=0; k<dm3.n; k++)
      for (dm3.a[i][k]=j=0; j<dm2.n; j++)
        dm3.a[i][k] += dm1.a[i][j] * dm2.a[j][k];
  return dm3;
}
