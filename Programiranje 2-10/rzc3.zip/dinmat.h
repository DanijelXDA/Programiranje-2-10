/* dinmat.h - Deklaracije paketa funkcija za obradu dinamickih matrica.   */

typedef struct { float **a; int m, n; } Din_mat; /* Struktura matrice.    */

Din_mat stvori (int m, int n);                    /* Dodela memorije.     */
void unisti (Din_mat dm);                         /* Oslobadjanje memorije*/
Din_mat kopiraj (Din_mat dm);                     /* Kopiranje matrice.   */
Din_mat citaj (int m, int n);                     /* Citanje matrice.     */
void pisi (Din_mat dm, const char *frm, int max); /* Ispisivanje matrice. */
Din_mat transpon (Din_mat dm);                    /* Transponovana matrica*/
Din_mat zbir (Din_mat dm1, Din_mat dm2);          /* Zbir matrica.        */
Din_mat razlika (Din_mat dm1, Din_mat dm2);       /* Razlika matrica.     */
Din_mat proizvod (Din_mat dm1, Din_mat dm2);      /* Proizvod matrica.    */
