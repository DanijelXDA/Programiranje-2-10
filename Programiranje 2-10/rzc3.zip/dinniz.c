/* dinniz.c - Definicije paketa funkcija za obradu dinamickih nizova.     */

#include "dinniz.h"
#include <stdio.h>
#include <stdlib.h>

Din_niz sastavi (int *a, int n) {    /* Sastavljanje dinamickog niza.     */
  Din_niz dn; int i;
  if ((dn.a = malloc ((dn.n = n) * sizeof (int))) == NULL) exit (1);
  for (i=0; i<n; i++) dn.a[i] = a[i];
  return dn;
}

void razlozi (Din_niz dn, int *a, int *n) { /* Razlaganje dinamickog niza.*/
  int i;
  for (i=0; i<dn.n; i++) a[i] = dn.a[i];
  *n = dn.n;
}

Din_niz kopiraj (Din_niz dn) {       /* Kopiranje dinamickog niza.        */
  Din_niz dn2; int i;
  if ((dn2.a = malloc ((dn2.n = dn.n) * sizeof (int))) == NULL) exit (1);
  for (i=0; i<dn.n; i++) dn2.a[i] = dn.a[i];
  return dn2;
}

void obrni (Din_niz dn) { /* Obrtanje redosleda elemenata dinamickog niza.*/
  int *a, *b;
  for (a=dn.a, b=a+dn.n-1; a<b; a++, b--) { int c = *a; *a = *b; *b = c; }
}


void izostavi (Din_niz *dn, int k) { /* Izostavljanje elemenata din. niza.*/
  int i, j;
  for (i=j=0; i<dn->n; i++) if (dn->a[i] != k) dn->a[j++] = dn->a[i];
  dn->n = j; dn->a = realloc (dn->a, j*sizeof(int));
}

Din_niz citaj () {                   /* Citanje dinamickog niza.          */
  Din_niz dn; int i;
  printf ("Duzina niza? "); scanf ("%d", &dn.n);
  if (dn.n >= 0) {
    if ((dn.a = malloc (dn.n * sizeof (int))) == NULL) exit (1);
    printf ("Elementi niza? ");
    for (i=0; i<dn.n; scanf ("%d", &dn.a[i++]));
  } else dn.a = NULL;
  return dn;
}

void pisi (Din_niz dn) {             /* Ispisivanje dinamickog niza.      */
  int i;
  for (i=0; i<dn.n; i++) {
    printf ("%6d", dn.a[i]);
    if (i%10 == 9 || i == dn.n-1) putchar ('\n');
  }
}
