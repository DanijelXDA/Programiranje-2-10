/* ekspon.c - Izracunavanje exp(x) pomocu Tejlorovog razvoja.             */

#include <stdio.h>
#include <math.h>

double ekspon (double x, int n) {
  double ex = 1, clan = 1; int i;
  for (i=1; i<n; i++) { clan *= x / i; ex += clan; }
  return ex;
}

main () {
  double x, xmin, xmax, dx, ex, ext, apsgr, relgr;
  int    n, nmin, nmax, dn, i, k;
  printf ("xmin, xmax, dx? "); scanf ("%lf%lf%lf", &xmin, &xmax, &dx);
  printf ("nmin, nmax, dn? "); scanf ("%d%d%d",    &nmin, &nmax, &dn);
  k = printf ("\n%6s %12s %3s %14s %10s\n", "x", "ext", "n", "ex", "relgr");
  for (i=0; i<k-2; i++) putchar ('='); putchar ('\n');
  for (x=xmin; x<=xmax; x+=dx)
    for (n=nmin; n<=nmax; n+=dn) {
      ex  = ekspon (x, n);                        /* Izracunata vrednost. */
      ext = exp (x);                              /* Tacna vrednost.      */
      apsgr = ex - ext;                           /* Apsolutna greska.    */
      relgr = apsgr / ext;                        /* Relativna greska.    */
      printf ("%6.2f %#12.7g %3d %#14.7g %10.2e\n", x, ext, n, ex, relgr);
    }
}
