/* fakt.c - Rekurzivna funkcija za racunanje n!                           */

long fakt (int n) {
  return (n > 0) ? n * fakt (n-1) : 1;
}

#include <stdio.h>
#include <stdlib.h>

void main (int bpar, const char *vpar[]) {
  int n, nmax = atoi (vpar[1]);
  for (n=0; n<=nmax; n++)
    printf ("%2d%12ld\n", n, fakt (n));
}
