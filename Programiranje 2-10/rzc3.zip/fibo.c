/* fibo.c - Fibonacijevi brojevi.                                         */

/* Rekurzivno:                                                            */
long fibo1 (int n) {
  return (n > 1) ? fibo1 (n-1) + fibo1 (n-2) : n;
}

/* Iterativno:                                                            */
long fibo2 (int n) {
  long f0 = 0, f1 = 1, f2 = n; int i;
  for (i=2; i<=n; i++) { f2 = f0 + f1; f0 = f1; f1 = f2; }
  return f2;
}

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* Merenje vremena izvrsavanja date funkcije.                             */
double vreme (long (*f)(int), int n) {
  clock_t t1, t2, t3; long i, k = 1; double t;
  while (1) {
    t1 = clock ();  /* Trajanje praznog ciklusa.                          */
    for (i=0; i<k; i++) ;
    t2 = clock ();  /* Trajanje ciklusa s pozivanjem funkcije.            */
    for (i=0; i<k; i++) (*f)(n);
    t3 = clock ();
    t = (double)((t3-t2) - (t2-t1)) / CLOCKS_PER_SEC;
  if (t >= 1) break;
    k += k;
  }
  return t / k;
}

/* Glavna funkcija.                                                       */
void main (int bpar, const char *vpar[]) {
  int n, nmax = (bpar > 1) ? atoi (vpar[1]) : 10;
  for (n=0; n<=nmax; n++) {
    printf ("%2d%10ld%12.3e%10ld%12.3e\n",
            n, fibo1 (n), vreme (fibo1, n),
               fibo2 (n), vreme (fibo2, n));
  }
}
