/* fuzija.c - Fuzija dva uredjena niza celih brojeva.                     */

#include <stdio.h>
#define N 100

main () {
  int a[N], na, b[N], nb, c[2*N], nc, ia, ib, ic;
  while (1) {
    printf ("na? "); scanf ("%d", &na);
  if (na<0 || na>N) break;
    printf ("A ? "); for (ia=0; ia<na; scanf ("%d", &a[ia++]));
    if (na == 0) printf ("\n");
    printf ("nb? "); scanf ("%d", &nb);
  if (nb<0 || nb>N) break;
    printf ("B ? "); for (ib=0; ib<nb; scanf ("%d", &b[ib++]));
    if (nb == 0) printf ("\n");
    for (ia=ib=ic=0; ia<na&&ib<nb; c[ic++] = (a[ia]<b[ib]) ? a[ia++] : b[ib++]);
    while (ia < na) c[ic++] = a[ia++];
    while (ib < nb) c[ic++] = b[ib++];
    nc = ic;
    printf ("C = "); for (ic=0; ic<nc; printf ("%d ", c[ic++]));
    printf ("\n\n");
  }
}
