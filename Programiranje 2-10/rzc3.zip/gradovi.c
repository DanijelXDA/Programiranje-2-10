/* gradovi.c - Uredjivanje imena gradova smestenih u dinamicku matricu.   */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAX_GRAD 100
#define MAX_DUZ  30

main () {

  char **gradovi, *grad;
  int  br_grad=0, duz, i;

  /* Citanje i obrada pojedinacnih imena: */
  printf ("\nNeuredjeni niz imena gradova:\n\n");
  gradovi = malloc (MAX_GRAD * sizeof (char *));
  do {

    grad = malloc (MAX_DUZ);
    gets (grad);    /* Citanje sledeceg imena. */

  /* Kraj ako je duzina imena nula. */
  if ((duz = strlen (grad)) == 0) { free (grad); break; }

    grad = realloc (grad, duz+1);
    puts (grad);    /* Ispisivanje procitanog imena. */

    /* Uvrstavanje novog imena u uredjeni niz starih imena: */
    for (i=br_grad-1; i>=0; i--)
      if (strcmp (gradovi[i], grad) > 0)
        gradovi[i+1] = gradovi[i];
      else break;
    gradovi[i+1] = grad;

    /* Nastavak rada ako ima jos slobodnih vrsta u matrici. */
  } while (++br_grad < MAX_GRAD);
  gradovi = realloc (gradovi, br_grad * sizeof (char *));

  /* Ispisivanje uredjenog niza imena: */
  printf ("\nUredjeni niz imena gradova:\n\n");
  for (i=0; i<br_grad; puts (gradovi[i++]));
}
