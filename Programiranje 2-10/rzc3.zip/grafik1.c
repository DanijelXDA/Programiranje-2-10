/* grafik1.c - Tabeliranje i graficki prikaz funkcije bez x-ose.          */

#include <stdio.h>
#include <math.h>
#define SIR 40  /* Sirina slike. */

main () {
  double xmin, xmax, dx, ymin, ymax, dy, y, x;
  int k;
  printf ("xmin, xmax, dx? "); scanf ("%lf%lf%lf", &xmin, &xmax, &dx);
  printf ("ymin, ymax?     "); scanf ("%lf%lf",    &ymin, &ymax);
  putchar ('\n');
  dy = (ymax - ymin) / (SIR - 1);
  for (x=xmin; x<=xmax; x+=dx) {
    y = exp (-0.1*x) * sin (x);
    k = (y - ymin) / dy;
    printf ("%9.3f %9.3f ", x, y);
    if (k>=0 && k<SIR) printf ("%*c", k+1, '*');
    putchar ('\n');
  }
}
