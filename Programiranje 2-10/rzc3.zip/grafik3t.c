/* grafik3t.c - Ispitivanje funkcije grafik.                              */

#include <stdio.h>

double oscil (double);                 /* Prototipovi funkcija.           */
double polinom (double);
void grafik (double (*)(double), double, double, int,
                                 double, double, int);

extern double poli[];                  /* Deklaracije globalnih podataka. */
extern int n;

void main () {                         /* Glavna funkcija.                */
  double xmin, xmax, ymin, ymax, (*fun)(double); int sir, vis, i; char izb[2];
  while (1) {
    printf ("\nFunkcija (O - oscilacije, P - polinom, . - kraj)? ");
    scanf ("%1s", izb);
  if (izb[0] == '.') break;
    switch (izb[0]) {
      case 'o': case 'O': fun = oscil; break;
      case 'p': case 'P': fun = polinom;
                          printf ("Red polinoma? "); scanf ("%d", &n);
                          printf ("Koeficijenti polinoma? ");
                          for (i=n; i>=0; scanf ("%lf", &poli[i--]));
                          break;
      default: printf ("*** Nedozvoljen izbor! ***\n");
               continue;
    }
    printf ("xmin, xmax, sir? "); scanf ("%lf%lf%d", &xmin, &xmax, &sir);
    printf ("ymin, ymax, vis? "); scanf ("%lf%lf%d", &ymin, &ymax, &vis);
    putchar ('\n');
    grafik (fun, xmin, xmax, sir, ymin, ymax, vis);
  }
}
