/* imena.c - Uredjivanje imena po abecednom redosledu.                    */

#include <stdio.h>
#include <string.h>
#define N 100     /* Najveci broj imena.   */
#define D 40      /* Najveca du�ina imena. */

main () {
  char ljudi[N][D+1], osoba[D+1];
  int i, j, m, n=0;

  /* Citanje neuredjenog niza imena: */
  printf ("Neuredjen niz prezimena i imena?\n\n");
  do
    gets (ljudi[n]);
  while (strcmp(ljudi[n++],". .") != 0);
  n--;

  /* Uredjivanje niza imena: */
  for (i=0; i<n-1; i++) {
    m = i;
    for (j=i+1; j<n; j++)
      if (strcmp(ljudi[j], ljudi[m]) < 0) m = j;
    if (m != i) {
      strcpy (osoba   , ljudi[i]);
      strcpy (ljudi[i], ljudi[m]);
      strcpy (ljudi[m], osoba   );
    }
  }

  /* Ispisivanje uredjenog niza imena: */
  printf ("\nUredjeni niz imena:\n\n");
  for (i=0; i<n; puts (ljudi[i++]));
}
