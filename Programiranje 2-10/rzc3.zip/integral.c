/* integral.c - Izracunavanje odredjenog integrala funkcije sin(x).       */

#include <stdio.h>
#include <math.h>

void pravoug (double(*)(double),double,double,double,double*,int*);
void trapez  (double(*)(double),double,double,double,double*,int*);

#define PI 3.1415926535897932384626433832795

void main () {
  int uspprav, usptrap, i; double eps, yprav, ytrap;
  for (i=0; i<=14; i++) {
    eps = pow (10, -i);
    pravoug (sin, 0, PI/2, eps, &yprav, &uspprav);
    trapez  (sin, 0, PI/2, eps, &ytrap, &usptrap);
    printf ("%9.2e %20.15f %3s %20.15f %3s\n",
            eps, yprav, (uspprav ? "da" : "ne"),
                 ytrap, (usptrap ? "da" : "ne"));
  }
}
