/* izost1.c - Izostavljanje odredjenih elemenata niza.                    */

#include <stdio.h>
#define N 100

main () {
  int i, j, k, n, a[N];
  while (1) {
    printf ("n? "); scanf ("%d", &n);
  if (n<=0 || n>N) break;
    printf ("A? "); for (i=0; i<n; scanf ("%d", &a[i++]));
    printf ("k? "); scanf ("%d", &k);
    for (i=j=0; i<n; i++) if (a[i] != k) a[j++] = a[i];
    n = j;
    printf ("A= "); for (i=0; i<n; printf ("%d ",a[i++]));
    printf ("\n\n");
  }
}
