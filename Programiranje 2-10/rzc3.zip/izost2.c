/* izost2.c - Izostavljanje vrste i kolone matrice sa najvecim elementom. */

#include <stdio.h>
#define N 30

void main () {
  int i, j, m, n, a[N][N],  max, imax, jmax;
  FILE *dat;

  /* Citanje matrice: */
  dat = fopen ("izost2.pod", "r");
  fscanf (dat, "%d%d", &m, &n);
  for (i=0; i<m; i++)
    for (j=0; j<n; fscanf (dat, "%d", &a[i][j++]));
  fclose (dat);

  /* Nalazenje mesta najveceg elementa: */
  max = a[0][0]; imax = jmax = 0;
  for (i=0; i<m; i++)
    for (j=0; j<n; j++)
      if (a[i][j]>max) { max=a[i][j]; imax=i; jmax=j; }

  /* Izostavljanje kolone: */
  for (i=0; i<m; i++)
    for (j=jmax; j<n-1; j++) a[i][j] = a[i][j+1];
  n--;

  /* Izostavljanje vrste: */
  for (j=0; j<n; j++)
    for (i=imax; i<m-1; i++) a[i][j] = a[i+1][j];
  m--;

  /* Upisivanje rezultata u datoteku: */
  dat = fopen ("izost2.rez", "w");
  fprintf (dat, "%d %d\n", m, n);
  for (i=0; i<m; i++) {
    for (j=0; j<n; fprintf (dat, "%d ", a[i][j++]));
    fputc ('\n', dat);
  }
  fclose (dat);
}
