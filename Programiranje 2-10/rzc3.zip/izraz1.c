/* izraz1.c - Izracunavanje zbira uzastopnih prirodnih brojeva.           */

#include <stdio.h>

main () {
  int n, s, i;
  printf ("n? "); scanf ("%d", &n);
  for (s=0, i=1; i<=n; s+=i++);
  printf ("s= %d\n", s);
}
