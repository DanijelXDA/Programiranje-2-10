/* izraz2.c - Izracunavanje proizvoda uzastopnih prirodnih brojeva.       */

#include <stdio.h>

main () {
  int n, i; long s;
  printf ("n? "); scanf ("%d", &n);
  for (s=i=1; i<=n; s*=i++);
  printf ("s= %ld\n", s);
}
