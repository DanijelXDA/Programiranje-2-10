/* izraz3.c - Izracunavanje zbira faktorijela.                            */

#include <stdio.h>

main () {
  int n, i; long s, f;
  printf ("n? "); scanf ("%d", &n);
  for (s=0, f=i=1; i<=n; i++) {
    f *= i;
    s += f;
  }
  printf ("s= %ld\n", s);
}

