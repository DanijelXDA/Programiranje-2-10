/* izraz4.c - Izracunavanje slozenog zbira.                               */

#include <stdio.h>

main () {
  int n, i; double s, g; long f;
  printf ("n? "); scanf ("%d", &n);
  for (s=g=0, f=i=1; i<=n; i++) {
    f *= i;
    g += 1. / (i+1);
    s += f / g;
  }
  printf ("s= %f\n", s);
}

