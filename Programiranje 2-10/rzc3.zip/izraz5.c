/* izraz5.c - Izracunavanje slozenog zbira.                               */

#include <stdio.h>

main () {
  int n, i, f, g, z; double s;
  printf ("n? "); scanf ("%d", &n);
  for (s=f=g=0, i=z=1; i<=n; i++) {
    f += i;
    g += i * i;
    s += z * (double)f / g;
    z = -z;
  }
  printf ("s= %f\n", s);
}
