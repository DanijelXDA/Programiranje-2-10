/* kosinus.c - Izracunavanje cos(x) pomocu Tejlorovog razvoja.            */

#include <stdio.h>
#include <math.h>

double kosinus (double x, int n) {
  double cosx = 1, clan = 1; int i;
  for (i=1; i<n; i++) { clan *= - x * x / (2*i-1) / (2*i) ; cosx += clan; }
  return cosx;
}

main () {
  double x, xmin, xmax, dx, cosx, cosxt, apsgr, relgr;
  int    n, nmin, nmax, dn, i, k;
  printf ("xmin, xmax, dx? "); scanf ("%lf%lf%lf", &xmin, &xmax, &dx);
  printf ("nmin, nmax, dn? "); scanf ("%d%d%d",    &nmin, &nmax, &dn);
  k = printf ("\n%6s %12s %3s %14s %10s\n", "x","cosxt","n","cosx","relgr");
  for (i=0; i<k-2; i++) putchar ('='); putchar ('\n');
  for (x=xmin; x<=xmax; x+=dx)
    for (n=nmin; n<=nmax; n+=dn) {
      cosx  = kosinus (x, n);                     /* Izracunata vrednost. */
      cosxt = cos (x);                            /* Tacna vrednost.      */
      apsgr = cosx - cosxt;                       /* Apsolutna greska.    */
      if (cosxt)      relgr = apsgr / cosxt;      /* Relativna greska.    */
      else if (apsgr) relgr = apsgr>0 ? 1e38 : -1e38;
      else            relgr = 0;
      printf ("%6.2f %#12.7g %3d %#14.7g %10.2e\n", x, cosxt, n, cosx, relgr);
    }
}
