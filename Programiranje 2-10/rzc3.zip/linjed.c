/* linjed.c - Resavanje sistema od dve linearne jednacine.                */

#include <stdio.h>

main () {
  double a1, b1, c1, a2, b2, c2, D, Dx, Dy, x, y;
  printf ("Koeficijenti prve jednacine?  ");
  scanf ("%lf%lf%lf", &a1, &b1, &c1);
  printf ("Koeficijenti druge jednacine? ");
  scanf ("%lf%lf%lf", &a2, &b2, &c2);
  D  = a1 * b2 - a2 * b1;
  Dx = c1 * b2 - c2 * b1;
  Dy = a1 * c2 - a2 * c1;
  if (D != 0) {
    x = Dx / D;
    y = Dy / D;
    printf ("x= %10.2f\n", x);
    printf ("y= %10.2f\n", y);
  } else
    if (Dx==0 && Dy==0)
      printf ("Sistem je neodredjen.\n");
    else
      printf ("Sistem je protivrecan.\n");
}
