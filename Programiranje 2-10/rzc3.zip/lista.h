/* lista.h - Deklaracije paketa funkcija za obradu listi.                 */

typedef struct elem { int broj; struct elem *sled; } Elem; /*Element liste*/

int duz (Elem *lst);                    /* Broj elemenata liste.          */
void pisi (Elem *lst);                  /* Ispisivanje liste.             */
Elem *na_pocetak (Elem *lst, int b);    /* Dodavanje na pocetak.          */
Elem *na_kraj (Elem *lst, int b);       /* Dodavanje na kraj.             */
Elem *citaj1 (int n);    /* Citanje liste stavljajuci brojeve na pocetak. */
Elem *citaj2 (int n);    /* Citanje liste stavljajuci brojeve na kraj.    */
Elem *umetni (Elem *lst, int b);        /* Umetanje u uredjenu listu.     */
void brisi (Elem *lst);                 /* Brisanje svih elemenata liste. */
Elem *izostavi (Elem *lst, int b); /* Izostavljanje svakog pojavljivanja. */
