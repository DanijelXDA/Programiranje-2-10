/* lista4.c - Definicije paketa za obradu dvostruko spregnutih listi.     */

#include "lista4.h"
#include <stdio.h>
#include <stdlib.h>

Lista stvori (void)                      /* Stvaranje prazne liste.       */
  { Lista lst; lst.prvi = lst.posl = lst.tek = NULL; return lst; }

void na_prvi (Lista *lst)               /* Pomeranje na prvi element.     */
  { lst->tek = lst->prvi; }

void na_posl (Lista *lst)               /* Pomeranje na poslednji element.*/
  { lst->tek = lst->posl; }

void na_sled (Lista *lst)               /* Pomeranje na sledeci element.  */
  { if (lst->tek) lst->tek = lst->tek->sled; }

void na_pret (Lista *lst)               /* Pomeranje na prethodni element.*/
  { if (lst->tek) lst->tek = lst->tek->pret; }

void nadji_sled (Lista *lst, int b)     /* Pomer. na sled. pojavljivanje. */
  { while (lst->tek && lst->tek->broj != b) lst->tek = lst->tek->sled; }

void nadji_pret (Lista *lst, int b)     /* Pomer. na pret. pojavljivanje. */
  { while (lst->tek && lst->tek->broj != b) lst->tek = lst->tek->pret; }

int ima_tek (Lista lst)                 /* Da li postoji tekuci element?  */
  { return lst.tek != NULL; }

int dohvati_tek (Lista lst) {           /* Dohvatanje tekuceg elementa.   */
  if (! lst.tek) exit (1);
  return lst.tek->broj;
}

void promeni_tek (Lista lst, int b) {   /* Menjanje tekuceg elementa.     */
  if (! lst.tek) exit (1);
  lst.tek->broj = b;
}

void dodaj_poc    (Lista *lst, int b) { /* Dodavanje ispred prvog elementa*/
  Elem *novi = malloc (sizeof(Elem));
  novi->broj = b; novi->sled = lst->prvi; novi->pret = NULL;
  if (! lst->prvi) lst->posl = novi; else lst->prvi->pret = novi;
  lst->prvi = lst->tek = novi;
}

void dodaj_kraj   (Lista *lst, int b) { /* Dodavanje iza poslednjeg elem. */
  Elem *novi = malloc (sizeof(Elem));
  novi->broj = b; novi->pret = lst->posl; novi->sled = NULL;
  if (! lst->posl) lst->prvi = novi; else lst->posl->sled = novi;
  lst->posl = lst->tek = novi;
}

void dodaj_ispred (Lista *lst, int b) { /* Dodavanje ispred tekuceg elem. */
  Elem *novi = malloc (sizeof(Elem));
  if (! lst->tek) exit (1);
  novi->broj = b; novi->pret = lst->tek->pret; novi->sled = lst->tek;
  if (! lst->tek->pret) lst->prvi = novi; else lst->tek->pret->sled = novi;
  lst->tek->pret = lst->tek = novi;
}

void dodaj_iza    (Lista *lst, int b) { /* Dodavanje iza tekuceg elementa.*/
  Elem *novi = malloc (sizeof(Elem));
  if (! lst->tek) exit (1);
  novi->broj = b; novi->sled = lst->tek->sled; novi->pret = lst->tek;
  if (! lst->tek->sled) lst->posl = novi; else lst->tek->sled->pret = novi;
  lst->tek->sled = lst->tek = novi;
}

void izbaci_tek (Lista *lst, Smer smer){/* Izbacivanje tekuceg elementa.  */
  Elem *stari = lst->tek;
  if (! lst->tek) exit (1);
  if (! lst->tek->pret) lst->prvi = lst->tek->sled;
    else                lst->tek->pret->sled = lst->tek->sled;
  if (! lst->tek->sled) lst->posl = lst->tek->pret;
    else                lst->tek->sled->pret = lst->tek->pret;
  lst->tek = (smer == NAPRED) ? lst->tek->sled : lst->tek->pret;
  free (stari);
}

void brisi_sve (Lista *lst) {           /* Brisanje svih elemenata.       */
  while (lst->prvi) {
    Elem *stari = lst->prvi; lst->prvi = lst->prvi->sled; free (stari);
  }
  lst->posl = lst->tek = NULL;
}

void pisi (Lista lst, Smer smer){       /* Ispisivanje liste.             */
  if (smer == NAPRED)
    for (na_prvi (&lst); ima_tek (lst); na_sled (&lst))
      printf ("%d ", dohvati_tek (lst));
  else
    for (na_posl (&lst); ima_tek (lst); na_pret (&lst))
      printf ("%d ", dohvati_tek (lst));
}
void citaj (Lista *lst, int n, Smer smer) { /* Citanje liste.             */
  int i, b;
  brisi_sve (lst);
  for (i = 0; i<n; i++) {
    scanf ("%d", &b);
    (smer == NAPRED) ? dodaj_kraj (lst, b) : dodaj_poc (lst, b);
  }
}
