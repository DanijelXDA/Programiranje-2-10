/* lstpisi.c - Prikazivanje sadrzaja liste iz relativne datoteke.         */

#include "reldat.h"
#include <stdio.h>

typedef struct { int sif; char txt[50]; unsigned nar; } Zapis;

int main () {
  RelDat *dat = rd_otvori ("lst.dat");
  Zapis zap;
  rd_citaj (dat, 1, &zap);
  while (zap.nar) {
    rd_citaj (dat, zap.nar, &zap);
    printf ("%5d %s\n", zap.sif, zap.txt);
  }
  return 0;
}
