/* lstpravi.c - Obrazovanje uredjene liste u relativnoj datoteci.         */

#include "reldat.h"
#include <stdio.h>

typedef struct { int sif; char txt[50]; unsigned nar; } Zapis;

int main () {
  Zapis zap;
  RelDat* dat = rd_pravi ("lst.dat", sizeof(Zapis));
  FILE *pod = fopen ("lst.pod", "r");   /* Tekst. datoteka sa podacima.   */
  zap.sif = zap.txt[0] = zap.nar = 0;   /* Glava liste.                   */
  rd_pisi (dat, 1, &zap);
  while (fscanf (pod, "%d%s", &zap.sif, &zap.txt) != EOF) {
    unsigned pre, tek, nov; int sif;
    printf ("%5d %s\n", zap.sif, zap.txt);
    nov = rd_brojzap (dat) + 1; rd_pisi (dat, nov, &zap);
    sif = zap.sif;
    rd_citaj (dat, 1, &zap); pre=1; tek=zap.nar;
    while (tek && (rd_citaj (dat, tek, &zap) , zap.sif<sif))
      { pre = tek; tek = zap.nar; }
    rd_citaj (dat, pre, &zap); zap.nar = nov; rd_pisi (dat, pre, &zap);
    rd_citaj (dat, nov, &zap); zap.nar = tek; rd_pisi (dat, nov, &zap);
  }
  return 0;
}
