/* matrica1.c - Uredjivanje matrice po zbirovima kolona.                  */

#include <stdio.h>
#define N 30

main () {

  float a[N][N], s[N], p;
  int   m, n, i, j, min;

  while (1) {

    /* Citanje dimenzija matrice: */
    printf ("\nm, n? ");
    scanf("%d%d", &m, &n);

  if (m<=0 || m>N || n<=0 || n>N) break;

    /* Citanje elemenata matrice: */
    for (i=0; i<m; i++) {
      printf ("%2d. vrsta? ", i);
      for (j=0; j<n; scanf("%f", &a[i][j++]));
    }

    /* Racunanje zbirova elemenata po kolonama: */
    for (j=0; j<n; j++)
      for (s[j]=i=0; i<m; s[j]+=a[i++][j]);

    /* Uredjivanje kolona po velicinama zbirova: */
    for (i=0; i<n-1; i++) {
      /* trazenje najmanjeg zbira */
      for (min=i,j=i+1; j<n; j++)
        if (s[j]<s[min]) min = j;
      if (min != i) {
        p=s[i]; s[i]=s[min]; s[min]=p;
        /* zamena kolona */
        for (j=0; j<m; j++)
          { p=a[j][i]; a[j][i]=a[j][min]; a[j][min]=p; }
      }
    }

    /* Ispisivanje uredjene matrice: */
    printf ("\nUredjena matrica:\n");
    for (i=0; i<m; i++) {
      for (j=0; j<n; printf ("%6.2f", a[i][j++]));
      printf ("\n");
    }
    for (j=0; j<n; j++) printf ("------"); printf ("\n");
    for (j=0; j<n; printf ("%6.2f", s[j++])); printf ("\n");
  }
}
