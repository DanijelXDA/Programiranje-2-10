/* matrica2.c - Stepenovanje simetricne matrice.                          */

#include <stdio.h>
#include <stdlib.h>

main () {
  while (1) {
    long **a, **b, **c, **d;
    int m, n, i, j, k, st;

    /* Citanje dimenzije matrice: */
    printf ("\nDimenzija matrice? "); scanf ("%d", &m);
  if (m <= 0) break;

    /* Citanje elemenata matrice: */
    a = malloc (m*sizeof(long*));
    b = malloc (m*sizeof(long*));
    c = malloc (m*sizeof(long*));
    for (i=0; i<m; i++) {
      a[i] = malloc ((i+1)*sizeof(long));
      b[i] = calloc (i+1, sizeof(long));
      c[i] = malloc ((i+1)*sizeof(long));
      printf ("%2d. vrsta? ", i+1);
      for (j=0; j<=i; scanf ("%ld", &a[i][j++]));
      b[i][i] = 1;
    }

    /* Citanje stepena: */
    printf ("Stepen? "); scanf ("%d", &n);

    /* Stepenovanje matrice: */
    for (st=1; st<=n; st++) {
      for (i=0; i<m; i++)
        for (k=0; k<=i; k++)
          for (c[i][k]=j=0; j<m; j++)
            c[i][k] += (i>j?a[i][j]:a[j][i]) * (j>k?b[j][k]:b[k][j]);
      d = c; c = b; b = d;
    }

    /* Ispisivanje rezultata: */
    printf ("\n%d. stepen matrice:\n", n);
    for (i=0; i<m; i++) {
      for (j=0; j<=i; printf ("%7ld", b[i][j++])); printf ("\n");
    }

    /* Unistavanje matrica: */
    for (i=0; i<m; i++) { free (a[i]); free (b[i]); free (c[i]); }
    free (a); free (b); free (c);
  }
}
