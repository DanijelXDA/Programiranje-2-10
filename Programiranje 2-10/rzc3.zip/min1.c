/* min1.c - Najmanji od tri broja.                                        */

#include <stdio.h>

main () {
  int a, b, c, min;
  printf ("Tri broja? ");
  scanf ("%d%d%d", &a, &b, &c);
  min = a;
  if (b < min) min = b;
  if (c < min) min = c;
  printf ("Najmanji=  %d\n", min);
}
