/* min2.c - Najmanji element niza.                                        */

#include <stdio.h>
#define NMAX 100

main () {
  double a[NMAX], min;
  int n, i;
  while (1) {
    printf ("n? "); scanf ("%d", &n);
  if (n<=0 || n>NMAX) break;
    printf ("A? "); for (i=0; i<n; scanf ("%lf", &a[i++]));
    min = a[0];
    for (i=1; i<n; i++) if (a[i] < min) min = a[i];
    printf ("min= %.2f\n\n", min);
  }
}
