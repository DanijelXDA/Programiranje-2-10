/* min3.c - Nalazenje najmanjeg elementa niza.                            */

#include <stdio.h>
#define NMAX 100

main () {
  int a[NMAX], n, min, *p;
  while (1) {
    printf ("n? "); scanf ("%d", &n);
  if (n<=0 || n>NMAX) break;
    printf ("A? "); for (p=a; p<a+n; scanf ("%d", p++));
    min = *a;
    for (p=a+1; p<a+n; p++) if (*p < min) min = *p;
    printf ("min= %d\n\n", min);
  }
}
