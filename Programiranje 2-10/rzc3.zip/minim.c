/* minim.c - Nalazenje minimuma funkcije metodom deljenja intervala.      */

#include <math.h>

void minim (double (*f)(double), double xa, double xb, int n, double eps,
            double *xmin, double *ymin) {
  double dx, x, y; int i;
  dx    = (xb - xa) / n;
  *xmin = xa;
  *ymin = (*f) (*xmin);
  while (fabs(dx)>eps*fabs(*xmin) || fabs(dx)>eps) {
    for (i=0; i<=n; i++) {
      y = (*f) (x = xa+i*dx);
      if (y < *ymin) { *xmin = x; *ymin = y; }
    }
    xa = *xmin - dx;
    xb = *xmin + dx;
    dx = (xb - xa) / n;
  }
}
