/* mimimt1.c - Nalazenje minimuma funkcije sin(x) i
               prigusenih oscilacija.                                     */

#include <stdio.h>
#include <math.h>

#define PI 3.1415926
#define DVAPI (2*PI)

double oscil (double x);               /* Prototipovi funkcija.           */
void minim (double (*f)(double), double xa, double xb, int n, double eps,
            double *xmin, double *ymin);

void main () {                         /* Glavna funkcija.                */
  int i; double x1, y1, x2, y2;
  for (i=0; i<=4; i++) {
    minim (sin,   i*DVAPI, (i+1)*DVAPI, 10, 1e-10, &x1, &y1);
    minim (oscil, i*DVAPI, (i+1)*DVAPI, 10, 1e-10, &x2, &y2);
    printf ("%15.10f%15.10f%15.10f%15.10f\n", x1, y1, x2, y2);
  }
}
