/* nzdnzst.c - Ispitivanje funkcija nzd i nzs.                            */

#include <stdio.h>

unsigned nzd (unsigned, unsigned);      /* Prototipovi funkcija.          */
unsigned nzs (unsigned, unsigned);

main () {                               /* Glavna funkcija.               */
  unsigned a, b;
  printf ("    a    b  nzd  nzs\n"
          "====================\n");
  while (1) {
    scanf ("%u%u", &a, &b);
  if (a==0 || b==0) break;
    printf ("%5u%5u%5u%5u\n", a, b, nzd(a,b), nzs(a,b));
  }
}
