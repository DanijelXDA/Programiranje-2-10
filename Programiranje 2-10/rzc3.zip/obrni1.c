/* Obrni1.c - Obrtanje redosleda elemenata niza.                          */

#include <stdio.h>
#define NMAX 100

main () {
  double a[NMAX];
  int n, i, j;
  while (1) {
    printf ("n? "); scanf ("%d", &n);
  if (n<=0 || n>NMAX) break;
    printf ("A? "); for (i=0; i<n; scanf ("%lf", &a[i++]));
    for (i=0, j=n-1; i<j; i++, j--) {
      double b = a[i]; a[i] = a[j]; a[j] = b;
    }
    printf ("A="); for (i=0; i<n; printf (" %.2f", a[i++])); printf("\n\n");
  }
}
