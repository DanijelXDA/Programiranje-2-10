/* obrni3.c - Obrtanje redosleda elemenata niza.                          */

#include <stdio.h>
#define N 30

void obrni (int a[], int n) {
  int i, j, k;
  for (i=0, j=n-1; i<j; i++, j--)
    { k = a[i]; a[i] = a[j]; a[j] = k; }
}

/* Ispitivanje funkcije obrni.                                           */

main () {
  int niz[N], n, i;
  while (1) {
    printf ("Duzina niza?   "); scanf ("%d", &n);
  if (n <= 0 || n > N) break;
    printf ("Elementi niza? "); for (i=0; i<n; scanf("%d",&niz[i++]));
    obrni (niz, n);
    printf ("Obrnuti niz:   ");
    for (i=0; i<n; printf ("%d ", niz[i++])); printf ("\n\n");
  }
}
