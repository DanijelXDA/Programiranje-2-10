/* obrni4.c - Obrtanje redosleda bitova u jednoj masinskoj reci.          */

#include <stdio.h>

unsigned obrni (unsigned k) {
  unsigned i, j;
  for (i=0, j=~0; j!=0; j>>=1) {
    i = (i << 1) | (k & 1);
    k >>= 1;
  }
  return i;
}

/* Ispitivanje funkcije obrni.                                            */

void main () {
  unsigned broj;
  while (1) {
    scanf ("%x", &broj);
  if (broj == 0x9999) break;
    printf ("Procitani broj: %x\n", broj);
    printf ("Obrnuti broj:   %x\n\n", obrni (broj));
  }
}
