/* permut.c - Generisanje permutacija.                                    */

/* Rekurzivno - generise sve permutacije.                                 */
void permut1 (int a[], int n, int i, void (*f)(int[],int)) {
  int j, b;
  if (i == n) (*f) (a, n);
  else
    for (j=i; j<n; j++) {
      b = a[i]; a[i] = a[j]; a[j] = b;
      permut1 (a, n, i+1, f);
      b = a[i]; a[i] = a[j]; a[j] = b;
    }
}

/* Iterativno - generise samo sledecu permutaciju.                        */
int permut2 (int a[], int n) {
  int i, j, k, b;
  for (i=n-2; i>=0 && a[i]>=a[i+1]; i--);
  if (i >= 0) {
    for (j=n-1; j>i && a[j]<=a[i]; j--);
    b = a[j]; a[j] = a[i]; a[i] = b;
  }
  for (j=i+1, k=n-1; j<k; j++, k--)
    { b = a[j]; a[j] = a[k]; a[k] = b; }
  return i < 0;
}

#include <stdio.h>
#include <stdlib.h>

void pisi (int a[], int n) {          /* Primer obrade jedne permutacije. */
  int i;
  for (i=0; i<n; printf ("%d ", a[i++]));
  putchar ('\n');
}

void main (int bpar, const char *vpar[]) {  /* Glavna funkcija.           */
  int i, n = atoi (vpar[1]), *a = malloc (n * sizeof(int));
  for (i=0; i<n; i++) a[i] = i + 1;
  permut1 (a, n, 0, pisi); putchar ('\n');
  do {
    pisi (a, n);
  } while (! permut2 (a, n));
}
