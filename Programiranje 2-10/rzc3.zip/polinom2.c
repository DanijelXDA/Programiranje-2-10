/* polinom2.c - Funkcija za polinom.                                      */

double poli[21]; int n; /* Koeficijenti i red polinoma. */

double polinom (double x) {
  double p=poli[n]; int i;
  for (i=n-1; i>=0; p=p*x+poli[i--]);
  return p;
}
