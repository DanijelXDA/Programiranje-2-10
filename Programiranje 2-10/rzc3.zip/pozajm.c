/* pozajm.c - Obrada pozajmljivanja knjiga iz biblioteke.                 */

#include <stdio.h>
#include <stdlib.h>

typedef struct {
  char citalac[21], naslov[31], autor[21];
  long inv_br, uzeta, rok;
} Pozajm;

void main (int bpar, char *vpar[]) {
  FILE *ul  = fopen("pozajm.dat", "rb"),
       *izl = fopen("izvest.txt", "w");
  long danas= atoi(vpar[1]) +      /*dan*/
              atoi(vpar[2])*100 +  /*mes*/
              atol(vpar[3])*10000; /*god*/
  Pozajm pozajm;
  while (fread (&pozajm, sizeof(Pozajm), 1, ul) > 0) {
    if (pozajm.rok < danas)
      fprintf (
        izl, "%s %ld %ld.%ld.%ld\n",
        pozajm.citalac, pozajm.inv_br,
        (pozajm.rok % 100),
        (pozajm.rok / 100 % 100),
        (pozajm.rok / 10000)
      );
  }
}
