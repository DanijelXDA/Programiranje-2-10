/* pozdrav.c - Ispisivanje pozdrava.                                      */

#include <stdio.h>

main () {
  printf ("Pozdrav svima!\n");
}
