/* pretraz.c - Pretrazivanje niza.                                        */

#define NE 0
#define DA 1

/* Sekvencijalno pretrazivanje.                                           */
/* (neuredjen niz) */
int sektra1 (const int a[], int n, int b) {
  int i;
  for (i=0; i<n; i++)
    if (a[i] == b) return DA;
  return NE;
}

/* (uredjen niz) */
int sektra2 (const int a[], int n, int b) {
  int i;
  for (i=0; i<n && a[i]<b; i++);
  return i<n && a[i]==b;
}

/* Binarno pretrazivanje.                                                 */
int bintra (const int a[], int n, int b) {
  int d = 0, g = n-1, s;
  while (d <= g)
    if (a [s = (d + g) / 2] == b)
      return DA;
    else if (b < a[s])
      g = s - 1;
    else
      d = s + 1;
  return NE;
}

/* Glavna funkcija za prikazivanje rada prethodnih funkcija.              */
#include <stdio.h>

main () {
  int a[30], b[10], na=0, nb=0, i;
  char z, *rez[] = {"ne", "da"};

  /* Citanje niza za pretrazivanje: */
  printf ("Rastuci niz brojeva? ");
  do scanf ("%d%c", &a[na++], &z); while (z != '\n');   /* do kraja reda */

  /* Citanje brojeva za trazenje: */
  printf ("Neuredjeni niz brojeva? ");
  do scanf ("%d%c", &b[nb++], &z); while (z != '\n');   /* do kraja reda */

  /* Pretrazivanje niza: */
  printf ("\n    b sek1 sek2  bin\n"
            "====================\n");
  for (i=0; i<nb; i++)
  for (i=0; i<nb; i++)
    printf ("%5d%5s%5s%5s\n", b[i], rez[sektra1(a,na,b[i])],
                                    rez[sektra2(a,na,b[i])],
                                    rez[bintra (a,na,b[i])]);
}
