/* prost.c - Ispitivanje da li je broj prost.                             */

int prost (unsigned p) {
  unsigned k;
  if (p == 1) return 0;
  if (p == 2) return 1;
  for (k=2; k*k<=p; k++) if (p%k == 0) return 0;
  return 1;
}

/* Ispitivanje funkcije prost.                                            */

#include <stdio.h>

main () {
  unsigned b;
  while (1) {
    printf ("Broj? "); scanf ("%d", &b);
  if (b == 9999) break;
    puts (prost (b) ? "Bro je prost." : "Broj nije prost.");
  }
}
