/* prosti.c - Obrazovanje niza prostih brojeva.                           */

#include <stdio.h>
#include <stdlib.h>

void prosti (int p[], int n) {
  int k=2, i=0, j, da; p[i++] = k;
  for (k=3; i<n; k+=2) {
    for (da=1, j=0; p[j]*p[j]<=k && (da=k%p[j])!=0; j++);
    if (da) p[i++] = k;
  }
}

/* Ispitivanje funkcije prosti.                                           */

void main (int bpar, const char *vpar[]) {
  int p[200], i, n = atoi (vpar[1]);
  prosti (p, n);
  for (i=0; i<n; i++) {
    printf ("%6d", p[i]);
    if (i%10==9 || i==n-1) putchar ('\n');
  }
}
