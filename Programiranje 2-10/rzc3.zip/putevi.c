/* putevi.c - Pronalazenje puteva izmedju gradova.                        */

#include <stdio.h>
#define N 30

int a[N][N], n,                   /* Matrica susedstva.                   */
    put[N], m,                    /* Pronadjeni put.                      */
    poc, kraj;                    /* Pocetno i krajnje mesto.             */

void pisi ()                      /* Ispisivanje puta.                    */
  { int i; for (i=0; i<m; printf ("%d ", put[i++])); putchar ('\n'); }

void nadji (int k) {              /* Nalazenje puta polazezi iz mesta 'k'.*/
  int i, j;
  put[m++] = k;
  if (k == kraj) pisi ();            /* Stiglo se u odredisno mesto.      */
  else for (i=0; i<n; i++)
         if (a[k][i]!=0) {           /* Postoji put iz 'k' u 'i' ...      */
           for (j=0; j<m && i!=put[j]; j++);
             if (j == m) nadji (i);  /* ... 'i' je novo mesto, idi dalje. */
         }
  m--;
}

void main () {                    /* Glavna funkcija.                     */
  int i, j;
  scanf ("%d", &n);
  printf ("MATRICA SUSEDSTVA:\n\n");
  for (i=0; i<n; i++) {
    for (j=0; j<n; j++) { scanf ("%d", &a[i][j]); printf ("%3d", a[i][j]);}
    putchar ('\n');
  };
  while (1) {
    scanf ("%d%d", &poc, &kraj); m = 0;
  if (poc<0 || poc>=N || kraj<0 || kraj>=N) break;
    printf ("\nPutevi od %d do %d:\n", poc, kraj);
    nadji (poc);
  }
}
