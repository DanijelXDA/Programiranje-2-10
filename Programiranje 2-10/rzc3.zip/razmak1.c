/* razmak1.c - Izostavljanje suvisnih razmaka medju recima.               */

#include <stdio.h>
#define F 0
#define T 1

main () {
  int znak, ima = T;

  while ((znak = getchar ()) != EOF)
    if (znak != ' ' && znak != '\t')
      { putchar (znak); ima = znak == '\n'; }
    else if (! ima) { putchar (' '); ima = T; }
}
