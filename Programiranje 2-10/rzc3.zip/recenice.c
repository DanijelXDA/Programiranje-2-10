/* recenice.c - Sredjivanje recenica.                                     */

#include <stdio.h>
#include <ctype.h>
#include <string.h>

void recenice (const char ulaz[], const char izlaz[]) {
  int zn, prvi=1;
  FILE *ul = fopen (ulaz, "r"), *izl = fopen (izlaz, "w");
  while ((zn = fgetc (ul)) != EOF) {
    if (isupper(zn))
      { if (!prvi) zn += 'a' - 'A'; else prvi = 0; }
    else if (islower(zn))
      { if (prvi) { zn += 'A' - 'a'; prvi = 0; } }
    else if (zn=='.' || zn=='!' || zn=='?')
      prvi = 1;
    fputc (zn, izl);
  }
  fclose (ul); fclose (izl);
}

void main () {
  char ulaz[30], izlaz[30];
  while (1) {
    printf ("Ime ulazne datoteke?  "); scanf ("%s", ulaz);
  if (strcmp (ulaz, "***")  == 0) break;
    printf ("Ime izlazne datoteke? "); scanf ("%s", izlaz);
  if (strcmp (izlaz, "***") == 0) break;
    recenice (ulaz, izlaz);
  }
}
