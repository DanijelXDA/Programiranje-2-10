/* red1.c - Definicije paketa za redove ogranicenog kapaciteta.           */

#include "red1.h"
#include <stdio.h>
#include <stdlib.h>

Red stvori (int k) { Red rd;            /* Stvaranje praznog reda.        */
  rd.niz = malloc (k * sizeof(int)); rd.kap = k;
  rd.duz = rd.posl = rd.prvi = 0;
  return rd;
}

void stavi (Red *rd, int b) {           /* Stavljanje broja u red.        */
  if (rd->duz == rd->kap) exit (1);
  rd->niz[rd->posl++] = b; rd->duz++;
  if (rd->posl == rd->kap) rd->posl = 0;
}


int uzmi (Red *rd) { int b;             /* Uzimanje broja iz reda.        */
  if (rd->duz == 0) exit (2);
  b = rd->niz[rd->prvi++]; rd->duz--;
  if (rd->prvi == rd->kap) rd->prvi = 0;
  return b;
}

int prazan (Red rd) { return rd.duz == 0; }      /* Da li je red prazan?  */

int pun    (Red rd) { return rd.duz == rd.kap; } /* Da li je red pun?     */

void pisi  (Red rd) { int i;                /* Ispisivanje sadrzaja reda. */
  for (i=0; i<rd.duz; printf ("%d ", rd.niz[(rd.prvi + i++) % rd.kap]));
}

void prazni (Red *rd) { rd->duz = rd->posl = rd->prvi = 0; } /* Praznjenje*/

void unisti (Red *rd) { free (rd->niz); }   /* Unistavanje reda.          */
