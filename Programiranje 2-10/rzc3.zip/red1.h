/* red1.h - Deklaracije paketa za redove ogranicenog kapaciteta.          */

typedef struct { int *niz, kap, duz, prvi, posl; } Red;

Red stvori (int k);                     /* Stvaranje praznog reda.        */
void stavi (Red *rd, int b);            /* Stavljanje broja u red.        */
int uzmi (Red *rd);                     /* Uzimanje broja iz reda.        */
int prazan (Red rd);                    /* Da li je red prazan?           */
int pun    (Red rd);                    /* Da li je red pun?              */
void pisi (Red rd);                     /* Ispisivanje sadrzaja reda.     */
void prazni (Red *rd);                  /* Praznjenje reda.               */
void unisti (Red *rd);                  /* Unistavanje reda.              */
