/* red1t.c - Ispitivanje paketa za redove ogranicenog kapaciteta.         */

#include "red1.h"
#include <stdio.h>

int main () {
  Red rd = stvori (10); int k, b, izbor, kraj = 0;
  while (! kraj) {
    printf ("\n1. Stvaranje reda\n"
              "2. Stavljanje podatka u red\n"
              "3. Uzimanje podatka iz reda\n"
              "4. Ispisivanje sadrzaja reda\n"
              "5. Praznjenje reda\n"
              "0. Zavrsetak rada\n\n"
              "Vas izbor? "
            );
    scanf ("%d", &izbor);
    switch (izbor) {
    case 1: /* Stvaranje novog reda: */
      printf ("Kapacitet? "); scanf ("%d", &k);
      if (k > 0) { unisti (&rd); rd = stvori (k); }
        else printf ("*** Nedozvoljeni kapacitet! ***\a\n");
      break;
    case 2: /* Stavljanje podatka u red: */
      if (! pun (rd)) {
        printf ("Broj?      "); scanf ("%d", &b); stavi (&rd, b);
      } else printf ("*** Red je pun! ***\a\n");
      break;
    case 3: /* Uzimanje broja iz reda: */
      if (! prazan (rd))
        printf ("Broj=      %d\n", uzmi (&rd));
      else printf ("*** Red je prazan! ***\a\n");
      break;
    case 4: /* Ispisivanje sadrzaja reda: */
      printf ("Red=       "); pisi (rd); putchar ('\n');
      break;
    case 5: /* Praznjenje reda: */
      prazni (&rd); break;
    case 0: /* Zavrsetak rada: */
      kraj = 1; break;
    default: /* Pogresan izbor: */
      printf ("*** Nedozvoljen izbor! ***\a\n"); break;
    }
  }
  return 0;
}
