/* red2.c - Definicije paketa za redove neogranicenog kapaciteta.         */

#include "red2.h"
#include <stdio.h>
#include <stdlib.h>

Red stvori() {Red rd; rd.prvi=rd.posl=NULL; return rd;} /* Stvaranje reda.*/

void stavi (Red *rd, int b) {            /* Stavljanje broja u red.       */
  Elem *novi = malloc (sizeof(Elem));
  novi->broj = b; novi->sled = NULL;
  if (! rd->posl) rd->prvi = novi; else rd->posl->sled = novi;
  rd->posl = novi;
}

int uzmi (Red *rd) { Elem *stari; int b; /* Uzimanje broja iz reda.       */
  if (! rd->prvi) exit (2);
  b = rd->prvi->broj;
  stari = rd->prvi; rd->prvi = rd->prvi->sled; free (stari);
  if (! rd->prvi) rd->posl = NULL;
  return b;
}

int prazan (Red rd) { return rd.prvi == NULL; } /* Da li je red prazan?   */

void pisi  (Red rd) { Elem *tek;         /* Ispisivanje sadrzaja reda.    */
  for (tek=rd.prvi; tek; tek=tek->sled) printf ("%d ", tek->broj);
}

void prazni (Red *rd) {                  /* Praznjenje reda.              */
  while (rd->prvi) {
    Elem *stari = rd->prvi; rd->prvi = rd->prvi->sled;
    free(stari);
  }
}

void unisti (Red *rd) { prazni (rd); }   /* Unistavanje reda.             */
