/* reldat.c - Definicije paketa za obradu relativnih datoteka.            */

#include "reldat.h"
#include <stdlib.h>

RelDat *rd_pravi (const char *ime, int duz) {/* Stvaranje nove datoteke.  */
  FILE *dat; RelDat *reldat;
  if ( (dat = fopen (ime, "rb" )) != 0         ||
       fclose (dat),
       (dat = fopen (ime, "wb+")) == 0         ||
       fwrite (&duz, sizeof(int), 1, dat) < 1  ||
       (reldat = malloc(sizeof(RelDat))) == 0
      ) return 0;
  reldat->dat  = dat; reldat->duz  = duz; reldat->bzap = 0;
  return reldat;
}

RelDat *rd_otvori (const char *ime) {        /* Otvaranje stare datoteke. */
  FILE *dat; RelDat *reldat;
  int duz; long vel;
  if ( (dat = fopen (ime, "rb+")) == 0         ||
       fread  (&duz, sizeof(int), 1, dat) < 1  ||
       fseek (dat, 0L, SEEK_END) != 0          ||
       (vel = ftell (dat)) == -1L              ||
       (vel - sizeof(int)) % duz != 0          ||
       (reldat = malloc(sizeof(RelDat))) == 0
      ) { fclose (dat); return 0; }
  reldat->dat  = dat;
  reldat->duz  = duz;
  reldat->bzap = (vel - sizeof(int)) / duz;
  return reldat;
}

int rd_pisi (RelDat *dat, long k, const void *zap) { /* Upisivanje zapisa.*/
  if ( fseek (dat->dat,
              (long)(k-1)*dat->duz+sizeof(int),
              SEEK_SET
             ) != 0                            ||
       fwrite (zap, dat->duz, 1, dat->dat) < 1
     ) return EOF;
  if (k > dat->bzap) dat->bzap = k;
  return 0;
}

int rd_citaj (RelDat *dat, long k, void *zap) {      /* �itanje zapisa.   */
  if ( k > dat->bzap                           ||
       fseek (dat->dat,
              (long)(k-1)*dat->duz+sizeof(int),
              SEEK_SET
             ) != 0                            ||
       fread  (zap, dat->duz, 1, dat->dat) < 1
     ) return EOF;
  return 0;
}

long rd_brojzap (RelDat *dat) {              /* Broj zapisa u datoteci.   */
  return dat->bzap;
}

int rd_zatvori (RelDat *dat) {               /* Zatvaranje datoteke.      */
  fclose (dat->dat);
  free (dat);
  return 0;
}
