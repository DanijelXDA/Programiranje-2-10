/* sekprik.c - Prikazivanje sadr�aja sekvencijalne binarne datoteke.      */

#include <stdio.h>
#include <stdlib.h>

void main (int bpar, char *vpar[]) {
  FILE *ulaz; double x[100]; int n, i;
  if ((ulaz = fopen (vpar[1], "rb")) != NULL) {
    while (fread (&n, sizeof n, 1, ulaz) != 0) {
      fread (x, sizeof (double), n, ulaz);
      printf ("%3d ", n);
      for (i=0; i<n; i++) {
	      printf ("%6.2lf%s", x[i],
	              (i==n-1 ? "\n" : i%8==7 ? "\n    " : " "));
      }
    }
  } else
    printf ("*** Greska %d pri otvaranju ***\a\n", errno);
}
