/* sinus.c - Izracunavanje sin(x) pomocu Tejlorovog razvoja.              */

#include <stdio.h>
#include <math.h>

double sinus (double x, int n) {
  double sinx = x, clan = x; int i;
  for (i=1; i<n; i++) { clan *= - x * x / (2*i) / (2*i+1) ; sinx += clan; }
  return sinx;
}

main () {
  double x, xmin, xmax, dx, sinx, sinxt, apsgr, relgr;
  int    n, nmin, nmax, dn, i, k;
  printf ("xmin, xmax, dx? "); scanf ("%lf%lf%lf", &xmin, &xmax, &dx);
  printf ("nmin, nmax, dn? "); scanf ("%d%d%d",    &nmin, &nmax, &dn);
  k = printf ("\n%6s %12s %3s %14s %10s\n", "x", "sinxt", "n", "sinx", "relgr");
  for (i=0; i<k-2; i++) putchar ('='); putchar ('\n');
  for (x=xmin; x<=xmax; x+=dx)
    for (n=nmin; n<=nmax; n+=dn) {
      sinx  = sinus (x, n);                       /* Izracunata vrednost. */
      sinxt = sin (x);                            /* Tacna vrednost.      */
      apsgr = sinx - sinxt;                       /* Apsolutna greska.    */
      if (sinxt)      relgr = apsgr / sinxt;      /* Relativna greska.    */
      else if (apsgr) relgr = apsgr>0 ? 1e38 : -1e38;
      else            relgr = 0;
      printf ("%6.2f %#12.7g %3d %#14.7g %10.2e\n", x, sinxt, n, sinx, relgr);
    }
}
