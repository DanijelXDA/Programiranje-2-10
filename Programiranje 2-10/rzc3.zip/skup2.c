/* skup2.c - Pretvaranje niza u skup.                                     */

#include <stdio.h>
#define N 100

void skup (int a[], int *n) {
  int i, j, k;
  for (i=j=0; i<*n; i++) {
    for (k=0; k<j && a[k]!=a[i]; k++);
    if (k == j) a[j++] = a[i];
  }
  *n = j;
}

/* Ispitivanje funkcije skup.                                             */

void main () {
  while (1) {
    int a[N], n, i;
    printf ("Duzina niza?    "); scanf ("%d", &n);
  if (n<0 || n>N) break;
    printf ("Elementi niza?  ");
    for (i=0; i<n; scanf ("%d", &a[i++]));
    if (n == 0) putchar ('\n');
    skup (a, &n);
    printf ("Elementi skupa: ");
    for (i=0; i<n; printf ("%d ",a[i++]));
    printf ("\n\n");
  }
}
