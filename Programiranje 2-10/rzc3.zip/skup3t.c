/* skup3t.c - Ispitivanje paketa funkcija za obradu skupova.              */

#include "skup3.h"
#include <stdio.h>
#include <stdlib.h>

void main () {
  float *s1, *s2, *s3; int n1, n2, n3, prvi = 1, i;
  while (1) {
    citaj (&s1, &n1);
  if (n1 < 0) break;
    citaj (&s2, &n2);
  if (n2 < 0) break;
    if (! prvi) putchar ('\n'); else prvi = 0;
    printf ("s1       "); pisi (s1, n1, "%.2f"); putchar ('\n');
    printf ("s2       "); pisi (s2, n2, "%.2f"); putchar ('\n');
    unija (s1, n1, s2, n2, &s3, &n3);
    printf ("s1+s2    "); pisi (s3, n3, "%.2f"); putchar ('\n');
    free (s3);
    presek (s1, n1, s2, n2, &s3, &n3);
    printf ("s1*s2    "); pisi (s3, n3, "%.2f"); putchar ('\n');
    free (s3);
    razlika (s1, n1, s2, n2, &s3, &n3);
    printf ("s1-s2    "); pisi (s3, n3, "%.2f"); putchar ('\n');
    free (s3);
    for (i=0; i<n1; i++) dodaj (&s2, &n2, s1[i]);
    printf ("s2+=s1   "); pisi (s2, n2, "%.2f"); putchar ('\n');
    free (s1); free (s2);
  }
}