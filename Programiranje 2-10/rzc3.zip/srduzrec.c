/* srduzrec.c - Srednja du�ina re�i u tekstualnoj datoteci                */

#include <stdio.h>
#include <ctype.h>
#include <string.h>

double sr_duz_rec_1 (FILE *dat) {       /* Citajuci tekst znak po znak.   */
  int br_rec=0, zb_duz=0, prvi=1, znak;
  fseek (dat, 0, SEEK_SET);
  while ((znak = fgetc (dat)) != EOF) {
    if (isspace (znak))
      prvi = 1;
    else {
      zb_duz++;
      if (prvi) { br_rec++; prvi = 0; }
    }
  }
  return (double) zb_duz / br_rec;
}

double sr_duz_rec_2 (FILE *dat) {       /* Citajuci tekst rec po rec.     */
  int br_rec=0, zb_duz=0; char rec[80];
  fseek (dat, 0, SEEK_SET);
  while ((fscanf (dat, "%s", rec)) != EOF) {
    zb_duz += strlen (rec); br_rec++;
  }
  return (double) zb_duz / br_rec;
}

void main (int bpar, char *vpar[]) {
  FILE *dat = fopen (vpar[1], "r");
  if (dat) {
    printf ("Srednja duzina reci u datoteci \"%s\" je %.2f (%.2f)\n",
            vpar[1], sr_duz_rec_1(dat), sr_duz_rec_2 (dat));
    fclose (dat);
  }
}
