/* srvred1.c - Srednja vrednost brojeva deljivih sa tri.                  */

#include <stdio.h>

main () {
  int a[100], i, k, n;
  double s;
  while (1) {
    printf ("n? "); scanf ("%d", &n);
  if (n < 0 || n >100) break;
    printf ("A? ");
    for (i=0; i<n; i++) scanf ("%d", &a[i]);
    for (s=i=k=0; i<n; i++)
      if (a[i] % 3 == 0 ) { s += a[i]; k++; }
    if (k) s /= k;
    printf ("s= %f\n", s);
  }
}
