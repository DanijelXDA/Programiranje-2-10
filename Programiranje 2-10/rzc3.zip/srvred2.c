/* srvred2.c - Srednja vrednost u zapisima tekstualne datoteke.           */

#include <stdio.h>
#define N 100

main () {
  int i, n;
  double a[N], s, z=0;
  FILE *ul, *izl;
  ul  = fopen ("srvred2.pod", "r");
  izl = fopen ("srvred2.rez", "w");
  while (fscanf (ul, "%d", &n) > 0) {
    s = 0;
    for (i=0; i<n; i++) {
      fscanf (ul, "%lf", &a[i]);
      s += a[i];
    }
    if (n) s /= n;
    z += s;
    if (s > 0) {
      fprintf (izl, "%d", n);
      for (i=0; i<n; fprintf (izl, " %f", a[i++]));
      fprintf (izl, "\n");
    }
  }
  fclose (ul); fclose (izl);
  printf ("Zbir srednjih vrednosti= %f\n", z);
}
