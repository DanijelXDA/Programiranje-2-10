/* stek1.c - Definicije paketa za stekove ogranicenog kapaciteta.         */

#include "stek1.h"
#include <stdio.h>
#include <stdlib.h>

Stek stvori (int k) { Stek stk;         /* Stvaranje praznog steka.       */
  stk.niz = malloc (k * sizeof(int)); stk.kap = k; stk.vrh = 0;
  return stk;
}

void stavi (Stek *stk, int b) {         /* Stavljanje broja na stek.      */
  if (stk->vrh == stk->kap) exit (1);
  stk->niz[stk->vrh++] = b;
}

int uzmi (Stek *stk) {                  /* Uzimanje broja sa steka.       */
  if (stk->vrh == 0) exit (2);
  return stk->niz[--stk->vrh];
}

int prazan (Stek stk) { return stk.vrh == 0; }   /* Da li je stek prazan? */

int pun    (Stek stk) { return stk.vrh == stk.kap; } /* Da li je stek pun?*/

void pisi  (Stek stk) { int i;             /* Ispisivanje sadrzaja steka. */
  for (i=stk.vrh; i>0; printf ("%d ", stk.niz[--i]));
}

void prazni (Stek *stk) { stk->vrh = 0; }        /* Praznjenje steka.     */

void unisti (Stek *stk) { free (stk->niz); }     /* Unistavanje steka.    */
