/* stek1.h - Deklaracije paketa za stekove ogranicenog kapaciteta.        */

typedef struct { int *niz, kap, vrh; } Stek;

Stek stvori (int k);                    /* Stvaranje praznog steka.       */
void stavi (Stek *stk, int b);          /* Stavljanje broja na stek.      */
int uzmi (Stek *stk);                   /* Uzimanje broja sa steka.       */
int prazan (Stek stk);                  /* Da li je stek prazan?          */
int pun    (Stek stk);                  /* Da li je stek pun?             */
void pisi (Stek stk);                   /* Ispisivanje sadrzaja steka.    */
void prazni (Stek *stk);                /* Praznjenje steka.              */
void unisti (Stek *stk);                /* Unistavanje steka.             */
