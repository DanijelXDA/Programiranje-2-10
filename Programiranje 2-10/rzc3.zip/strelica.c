/* strelica.c - Crtanje strelice na glavnom izlazu.                       */

#include <stdio.h>

main () {
  int n, i, j, nzv, kor;
  char rep = ' ';
  while (1) {
    printf ("n? "); scanf ("%d", &n);
  if (n <= 0) break;
    putchar ('\n');
    nzv = 0; kor = 1;
    for (i=1; i<=3*n; i++) {
      nzv += kor;
      for (j=1; j<=3*n; j++) putchar (rep);
      for (j=1; j<=nzv; j++) putchar ('*');
      putchar ('\n');
      if (i == n)       rep = '*';
      if (i == 3*n/2+1) kor = -1;
      if (i == 2*n)     rep = ' ';
    }
    putchar ('\n');
  }
}
