/* tabla.c - Crtanje sahovske table na glavnom izlazu.                    */

#include <stdio.h>

main () {
  int n1, n2, i, j, k, m;
  char belo = ' ', crno = '*', znak;
  float d;
  while (1) {
    printf ("d? "); scanf ("%f", &d);
  if (d <= 0) break;
    putchar ('\n');
    n1 = 0.375 * d; n2 = 0.5 * d;
    for (i=1; i<=8; i++) {
      for (j=1; j<=n1; j++) {
        for (k=1; k<=4; k++) {
          for (m=1; m<=n2; m++) putchar (belo);
          for (m=1; m<=n2; m++) putchar (crno);
        }
        putchar ('\n');
      }
      znak = belo; belo = crno; crno = znak;
    }
    putchar ('\n');
  }
}
