/* taboscil.c - Tabeliranje prigusenih oscilacija.                        */

#include <stdio.h>

double oscil (double);                 /* Prototipovi funkcija.           */
void tabela (double (*)(double), double, double, double);

void main () {                         /* Glavna funkcija.                */
  double xmin, xmax, dx;
  printf ("xmin, xmax, dx? "); scanf ("%lf%lf%lf", &xmin, &xmax, &dx);
  putchar ('\n');
  tabela (oscil, xmin, xmax, dx);
}
