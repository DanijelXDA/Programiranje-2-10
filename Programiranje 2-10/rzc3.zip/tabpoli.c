/* tabpoli.c - Tabeliranje polinoma.                                      */

#include <stdio.h>

extern double poli[];                  /* Deklaracije globalnih podataka. */
extern int n;

double polinom (double);               /* Prototipovi funkcija.           */
void tabela (double (*)(double), double, double, double);

void main () {                         /* Glavna funkcija.                */
  double xmin, xmax, dx; int i;
  printf ("Red polinoma? "); scanf ("%d", &n);
  printf ("Koeficijenti polinoma? ");
  for (i=n; i>=0; scanf ("%lf", &poli[i--]));
  printf ("xmin, xmax, dx? ");
  scanf ("%lf%lf%lf", &xmin, &xmax, &dx);
  putchar ('\n');
  tabela (polinom, xmin, xmax, dx);
}
