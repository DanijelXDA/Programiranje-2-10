/* tabul.c - Zamena tabulacija odgovarajucim brojem znakova razmaka.      */

#include <stdio.h>

main () {
  int znak, poz=0;
  while ((znak = getchar()) != EOF)
    if (znak != '\t') {
      putchar (znak);
      poz = (znak != '\n') ? poz+1 : 0;
    } else
      do
        putchar (' ');
      while (++poz % 8);
}
