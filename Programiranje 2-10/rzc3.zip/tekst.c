/**************************************************************************/
/* tekst.c                 POGRAM ZA UREDJIVANJE TEKSTA                   */
/**************************************************************************/

#include <stdio.h>
#include <ctype.h>

/*--- Parametri sistema --------------------------------------------------*/
#define RED 120                    /* Najveca duzina jednog reda.         */
#define DUZ 66                     /* Pocetna duzina jednog reda.         */

/*--- Simbolicke konstante -----------------------------------------------*/
#define T   1                      /* Logicka konstanta "true".           */
#define F   0                      /* Logicka konstanta "false".          */

/*--- Pregled potprograma ------------------------------------------------*/
void obradi_zn (int);              /* Obrada sledeceg znaka.              */
int  smesti_zn (int);              /* Smestanje u izlazni bafer.          */
void salji_red (int);              /* Slanje reda na izlaz.               */
int  uzmi_zn (void);               /* Uzimanje sledeceg znaka.            */
void vrati_zn (int);               /* Vracanje jednog znaka na izlaz.     */
int  uzmi_broj (int, int, int);    /* Uzimanje decimalnog celog broja.    */

/*--- Globalne promenljive -----------------------------------------------*/
char red[RED];                     /* Izlazni bafer za jedan red.         */
int  duz = DUZ;                    /* Duzina izlaznih redova.             */
int  poz = 0;                      /* Broj znakova u izlaznom redu.       */
int  rec = 0;                      /* Broj reci u izlaznom redu.          */
char stek[RED];                    /* Stek za vracene znakove.            */
int  vrh = 0;                      /* Broj vracenih znakova.              */

/*=== G l a v n i   p r o g r a m ========================================*/
main () {
  int zn;
  while ((zn = uzmi_zn ()) != EOF) {
    if (isspace (zn)) zn = ' ';
    obradi_zn (zn);
 }
}

/*=== Obrada sledeceg ucitanog znaka =====================================*/
void obradi_zn (int zn) {
  static int upr = F,              /* Komanda je zapoceta.                */
             ima = T;              /* Razmak je smesten.                  */
  if (upr) {                       /* Izvrsavanje komande.                */
    switch (zn) {
    case '|':                      /* Smesti znak '|'.                    */
      ima = smesti_zn (zn); break;
    case 'P':                      /* Kraj pasusa.                        */
      salji_red (F); putchar ('\n'); ima = T; break;
    case 'L':                      /* Sirina izlaznih redova.             */
      duz = uzmi_broj (1, RED, DUZ); break;
    default:                       /* Nepoznata komanda.                  */
      printf ("\n*** Neispravno: |%c\n", zn); break;
    }
    upr = F;
  } else if (zn == '|') {          /* Sledi komanda.                      */
    upr = T ;
  } else if (zn != ' ' || !ima) {  /* Slanje znaka.                       */
    ima = smesti_zn (zn);
  }
}

/*=== Smestanje znaka u izlazni bafer ====================================*/
int smesti_zn (int zn) {
  if (poz < duz) {                 /* Izlazni bafer nije pun.             */
    red[poz++] = zn;
    if (zn == ' ') rec++;
    return zn == ' ';
  } else if (zn == ' ')            /* Bafer je pun, kraj reci.            */
    salji_red (F);
  else {                           /* Bafer je pun, nije kraj reci; ...   */
    if (rec) {                     /* ... vrati zapocetu rec na ulaz ...  */
      while (zn != ' ') {
        vrati_zn (zn);
        zn = red[--poz];
      }
      rec--;
    }
    salji_red (T);                 /* ... i salji red na izlaz.           */
  }
  return T;
}

/*=== Slanje reda na izlaz uz ravnanje ===================================*/
void salji_red (int ravnaj) {
  /* Ulaz: ravnaj - indikator ravnanja desne ivice.                       */
  int raz,                         /* Broj umetnutih razmaka izmedju reci.*/
      dod,                         /* Broj dodavanja po jednog razmaka.   */
      po,                          /* Brojac pozicija pri ispisivanju.    */
      re,                          /* Brojac reci pri ispisivanju.        */
      i;                           /* Pomocni brojac.                     */

  if (ravnaj && rec) {             /* Dodatni broj razmaka.               */
    raz = (duz - poz) / rec;
    dod = (duz - poz) % rec;
  } else {
    raz = dod = 0;
  }
  for (po=0, re=0; po<poz; po++) { /* Ispisivanje.                        */
    putchar (red[po]);
    if (red[po] == ' ') {
      for (i=0; i<raz; i++) putchar (' ');
      if (re++ < dod) putchar(' ');
    }
  }
  putchar ('\n'); poz = rec = 0;
}

/*=== Ucitavanje sledceg znaka ===========================================*/
int uzmi_zn (void) { return (vrh) ? stek[--vrh] : getchar (); }

/*=== Vracanje znaka na izlaz ============================================*/
void vrati_zn (int zn) { stek[vrh++] = zn; }

/*=== Ucitavanje decimalnog broja ========================================*/
int uzmi_broj (int min, int max, int podr) {
  int zn, broj = 0;
  while (isdigit (zn = uzmi_zn ())) broj = broj * 10 + zn - '0';
  if (zn != '|') vrati_zn (zn);
  if (broj < min || broj > max) {
    printf ("\n***Broj izvan opsega: %d\n", broj);
    broj = podr;
  }
  return broj;
}

/**************************************************************************/
