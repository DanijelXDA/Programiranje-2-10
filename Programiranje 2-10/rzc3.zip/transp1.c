/* transp1.c - Transponovanje kvadratne matrice.                          */

#include <stdio.h>
#define N 20

main () {
  double a[N][N], b;
  int i, j, n;
  while (1) {

    /* Citanje dimenzije matrice: */
    printf ("\nDimenzija? "); scanf ("%d", &n);

  if (n <=0 || n > N) break;

    /* Citanje elemenata matrice: */
    for (i=0; i<n; i++) {
      printf ("%2d. vrsta? ", i);
      for (j=0; j<n; scanf("%lf", &a[i][j++]));
    }

    /* Transponovanje matrice: */
    for (i=0; i<n-1; i++)
      for (j=i+1; j<n; j++)
        { b = a[i][j]; a[i][j] = a[j][i]; a[j][i] = b; }

    /* Ispisivanje matrice: */
    printf ("\nTransponovana matrica:\n");
    for (i=0; i<n; i++) {
      for (j=0; j<n; printf ("%6.2lf", a[i][j++]));
      printf ("\n");
    }
  }
}
