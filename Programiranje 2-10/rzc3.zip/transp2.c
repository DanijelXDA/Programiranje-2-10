/* transp2.c - Transponovanje matrice.                                    */

#include <stdio.h>
#include <stdlib.h>

main () {
  while (1) {
    int **a, **b, m, n, i, j;

    /* Citanje dimenzija matrice: */
    printf ("\nBroj vrsta i kolona? ");
    scanf ("%d%d", &m, &n);
  if (m<=0 || n<=0) break;

    /* Citanje elemenata matrice: */
    a = malloc (m*sizeof(int*));
    for (i=0; i<m; i++) {
      a[i] = malloc (n*sizeof(int));
      printf ("%2d. vrsta? ", i+1);
      for (j=0; j<n; scanf ("%d", &a[i][j++]));
    }

    /* Obrazovanje transponovane matrice: */
    b = malloc (n*sizeof(int*));
    for (i=0; i<n; i++) {
      b[i] = malloc (m*sizeof(int));
      for (j=0; j<m; j++) b[i][j] = a[j][i];
    }

    /* Zamena stare matrice novom matricom: */
    for (i=0; i<m; free (a[i++])); free (a); a = b; i = m; m = n; n = i;

    /* Ispisivanje rezultata: */
    printf ("\nTransponovana matrica:\n");
    for (i=0; i<m; i++)
      { for (j=0; j<n; printf ("%5d", a[i][j++])); printf ("\n"); }

    /* Unistavanje matrice: */
    for (i=0; i<m; free (a[i++])); free (a);
  }
}
