/* ugao6.c - Crtanje sestougaone figure na glavnom izlazu.                */

#include <stdio.h>

main () {
  int n, i, j, nzv, nrz, kor;
  while (1) {
    printf ("n? "); scanf ("%d", &n);
  if (n <= 0) break;
    putchar ('\n');
    nzv = n; nrz = n - 1; kor = 1;
    for (i=1; i<=2*n-1; i++) {
      for (j=1; j<=nrz; j++) putchar (' ');
      for (j=1; j<=nzv; j++) printf ("* ");
      putchar ('\n');
      if (i == n) kor = -1;
      nzv += kor; nrz -= kor;
    }
    putchar ('\n');
  }
}
