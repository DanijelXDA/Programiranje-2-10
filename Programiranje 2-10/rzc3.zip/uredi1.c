/* uredi1.c - Uredjivanje tri broja.                                      */

#include <stdio.h>

main () {
  double a, b, c, p;
  printf ("Tri broja? ");
  scanf ("%lf%lf%lf", &a, &b, &c);
  if (a > b) { p = a; a = b; b = p; }
  if (a > c) { p = a; a = c; c = p; }
  if (b > c) { p = b; b = c; c = p; }
  printf ("Uredjeno=  %f %f %f\n", a, b, c);
}
