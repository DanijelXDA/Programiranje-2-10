/* uredi3.c - Uredjivanje niza brojeva metodom umetanja.                  */

#include <stdio.h>
#include <stdlib.h>

main () {

  int n, *a, b, i, j;

  while (1) {

    /* Citanje duzine niza: */
    printf ("\nDuzina niza? "); scanf ("%d", &n);
  if (n <= 0) break;

    /* Stvaranje i ispisivanje niza: */
    a = malloc (n*sizeof(int));
    printf ("\nPocetni niz:\n\n");
    for (i=0; i<n; i++) {
      printf ("%d ", a[i] = rand() / (RAND_MAX + 1.) * 10);
      if (i%30==29 || i==n-1) printf ("\n");
    }

    /* Uredjivanje niza: */
    for (i=1; i<n; i++) {
      b = a[i];
      for (j=i-1; j>=0 && a[j]>b; j--) a[j+1] = a[j];
      a[j+1] = b;
    }

    /* Ispisivanje uredjenog niza: */
    printf ("\nuredjeni niz:\n\n");
    for (i=0; i<n; i++) {
      printf ("%d ", a[i]);
      if (i%30==29 || i==n-1) printf ("\n");
    }

    /* Unistavanje niza: */
    free (a);
  }
}
