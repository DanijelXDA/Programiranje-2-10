/* uredi4.c - Funkcije paketa za algoritme uredjivanja nizova.            */

#include "uredi4.h"

/* Niz pokazivaca na funkcije koje ostvaruju algoritme.                   */
extern const Uredi metode[] = {izbor, izbor2, umet, umet2, zamena, podela};

/* Niz naziva metoda uredjivanja.                                         */
extern const char *nazivi[] = {
  "Metoda izbora", "Poboljsana metoda izbora",
  "Metoda umetanja", "Poboljsana metoda umetanja",
  "Metoda zamene suseda", "Metoda podele"};

/* Broj algoritama.                                                       */
extern const int br_alg = sizeof(nazivi) / sizeof(char*);

/* Metoda izbora (Selection Sort).                                        */
void izbor  (Niz a, int n) {
  int i, j; Elem b;
  for (i=0; i<n-1; i++)
    for (j=i+1; j<n; j++)
      if (a[j] < a[i]) { b = a[i]; a[i] = a[j]; a[j] = b; }
}

/* Poboljsana metoda izbora.                                              */
void izbor2 (Niz a, int n) {
  int i, j, m; Elem b;
  for (i=0; i<n-1; i++) {
    m = i;
    for (j=i+1; j<n; j++) if (a[j] < a[m]) m = j;
    if (m != i) { b = a[i]; a[i] = a[m]; a[m] = b; }
  }
}

/* Metoda umetanja (Insetrtion Sort).                                     */
void umet   (Niz a, int n) {
  int i, j; Elem b;
  for (i=1; i<n; i++) {
    for (j=i-1; j>=0 && a[j]>a[j+1]; j--)
      { b = a[j]; a[j] = a[j+1]; a[j+1] = b; }
  }
}

/* Poboljsana metoda umetanja.                                            */
void umet2  (Niz a, int n) {
  int i, j; Elem b;
  for (i=1; i<n; i++) {
    b = a[i];
    for (j=i-1; j>=0 && a[j]>b; j--) a[j+1] = a[j];
    a[j+1] = b;
  }
}

/* Metoda zamena suseda (Bubble Sort).                                    */
void zamena (Niz a, int n) {
  int i, j, dalje; Elem b;
  for (dalje=1, i=0; i<n-1 && dalje; i++)
    for (dalje=0, j=n-2; j>=i; j--)
      if (a[j] > a[j+1]) {
        b = a[j]; a[j] = a[j+1]; a[j+1] = b;
        dalje = 1;
      }
}

/* Metoda podele (Quick Sort).                                            */
void podela (Niz a, int n) {
  int i, j; Elem b;
  if (n > 1) {
    i = -1; j = n - 1;
    while (1) {
      do i++; while (a[i] < a[n-1]);
      do j--; while (j>=0 && a[j]>a[n-1]);
    if (i >= j) break;
      b = a[i]; a[i] = a[j]; a[j] = b;
    }
    b = a[i]; a[i] = a[n-1]; a[n-1] = b;
    podela (a, i); podela (a+i+1, n-i-1);
  }
}
