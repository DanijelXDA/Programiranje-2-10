/* uredi4.h - Deklaracije paketa za algoritme uredjivanja nizova.         */

typedef float Elem;                     /* Tip elemenata niza.            */
#define FMTI "%*.*f"                    /* Format za ispisivanje.         */
#define FMTU "%f"                       /* Format za citanje.             */
typedef Elem Niz[];                     /* Tip niza.                      */
typedef void (*Uredi) (Niz a, int n);   /* Tip pokazivaca na funkcije.    */

void izbor  (Niz a, int n);             /* Metoda izbora.                 */
void izbor2 (Niz a, int n);             /* Poboljsana metoda izbora.      */
void umet   (Niz a, int n);             /* Metoda umetanja.               */
void umet2  (Niz a, int n);             /* Poboljsana metoda umetanja.    */
void zamena (Niz a, int n);             /* Metoda zamene suseda.          */
void podela (Niz a, int n);             /* Metoda podele.                 */

extern const Uredi metode[];            /* Niz pokazivaca na funkcije.    */
extern const char *nazivi[];            /* Niz naziva metoda.             */
extern const int br_alg;                /* Broj algoritama.               */
