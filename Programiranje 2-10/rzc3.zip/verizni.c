/* verizni.c - Izracunavanje vrednosti veriznog razlomka                  */

#include <stdio.h>
#define N 30

double v (double a[], int n, double x) {
  int i; double u = 0;
  for (i=n-1; i>=0; u=a[i--]/(x+u));
  return u;
}

void main () {
  double a[N], x, xmin, xmax, dx;
  int    n, i;
  FILE *ul, *izl;
  ul  = fopen ("verizni.pod", "r");
  izl = fopen ("verizni.rez", "w");
  fscanf (ul, "%d", &n); fprintf (izl, "A=");
  for (i=0; i<n; i++) {
    fscanf (ul, "%lf", &a[i]);
    fprintf (izl, " %.2f", a[i]);
  }
  fputc ('\n', izl);
  fscanf (ul, "%lf%lf%lf", &xmin, &xmax, &dx);
  fprintf (izl, "xmin, xmax, dx= %.2f, %.2f, %.2f\n", xmin, xmax, dx);
  fprintf (izl, "\n       x          v(x)\n"
                "======================\n");
  for (x=xmin; x<=xmax; x+=dx)
    fprintf (izl, "%10.2f%12.2f\n",
             x, v(a,n,x));
  fclose (ul); fclose (izl);
}
