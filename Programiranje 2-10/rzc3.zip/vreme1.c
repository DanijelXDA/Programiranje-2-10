/* vreme1.c - Pakovanje i raspakivanje vremena.                           */

#include <stdio.h>

main () {
  unsigned short godina, mesec, dan, sat, minut;
  unsigned long vreme;

  printf ("Dan, mesec, godina? ");
  scanf  ("%hd%hd%hd", &dan, &mesec, &godina);
  printf ("Sat, minut? ");
  scanf  ("%hd%hd", &sat, &minut);
  vreme = (unsigned long) godina << 20 |
          (unsigned long) mesec  << 16 |
                          dan    << 11 | sat << 6 | minut;
  printf("Pakovano: %lu (%lx)\n", vreme, vreme);
  godina = vreme >> 20;
  mesec  = vreme >> 16 & 0x0f;
  dan    = vreme >> 11 & 0x1f;
  sat    = vreme >>  6 & 0x1f;
  minut  = vreme       & 0x3f;
  printf ("Raspakovano: %hd.%hd.%hd  %hd:%hd\n",
           dan, mesec, godina, sat, minut);
}
