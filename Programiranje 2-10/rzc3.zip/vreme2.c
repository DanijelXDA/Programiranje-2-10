/* vreme2.c - Vreme u obliku strukture od bitova.                         */

typedef struct {
  unsigned god:12, mes:4, dan:5, sat:5, min:6;
} Vreme;

#include <stdio.h>

void main () {
  Vreme vreme;
  short god, mes, dan, sat, min;
  printf ("Dan, mesec, godina? ");
  scanf  ("%hd%hd%hd", &dan, &mes, &god);
  printf ("Sat, minut? ");
  scanf  ("%hd%hd", &sat, &min);
  vreme.god = god; vreme.mes = mes; vreme.dan = dan;
  vreme.sat = sat; vreme.min = min;
  printf ("Procitano: %hd.%hd.%hd %hd:%hd\n",
          vreme.dan, vreme.mes, vreme.god, vreme.sat, vreme.min);
}
