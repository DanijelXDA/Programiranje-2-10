/* zbir1.c - Izracunavanje zbira dva cela broja.                          */

#include <stdio.h>

main () {
  int a, b, c;
  printf ("Unesite dva cela broja: ");
  scanf ("%d%d", &a, &b);
  c = a + b;
  printf ("Zbir unetih brojeva: %d\n", c);
}
