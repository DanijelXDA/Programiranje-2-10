/* zbir2.c - Rekurzivna funkcija za racunanje zbira elemenata niza.       */

double zbir (const double a[], int n) {
  return (n > 0) ? a[0] + zbir (a+1, n-1) : 0;
}

#include <stdio.h>
#include <stdlib.h>

void main (int bpar, const char *vpar[]) {
  int i, n = bpar - 1;
  double *a = malloc (n * sizeof(double));
  for (i=0; i<n; i++) a[i] = atof (vpar[i+1]);
  printf ("Zbir= %f\n", zbir (a, n));
  free (a);
}
