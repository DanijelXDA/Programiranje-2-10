/* znakovi1.c - Brojanje slova i cifara.                                  */

#include <stdio.h>

main () {
  int znak, vel_sl = 0, mal_sl = 0, cifra = 0;

  while ((znak = getchar ()) != EOF) {
    if (znak >= 'A' && znak <= 'Z') vel_sl++;
    if (znak >= 'a' && znak <= 'z') mal_sl++;
    if (znak >= '0' && znak <= '9') cifra ++;
  }
  printf ("Broj velikih slova u tekstu je %d.\n", vel_sl);
  printf ("Broj malih slova u tekstu je %d.\n",   mal_sl);
  printf ("Broj cifara u tekstu je %d.\n",        cifra );
}
