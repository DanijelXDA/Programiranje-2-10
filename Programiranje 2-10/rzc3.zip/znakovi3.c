/* znakovi3.c - Broj pojavljivanja pojedinih cifara i slova.              */

#include <stdio.h>
#include <ctype.h>

void znakovi (int cifre[], int slova[]) {
  int i, zn;
  for (i=0; i<10; cifre[i++]=0);
  for (i=0; i<26; slova[i++]=0);
  while ((zn = getchar ()) != EOF) {
    if (isdigit (zn)) cifre[zn-'0']++;
    if (isupper (zn)) slova[zn-'A']++;
    if (islower (zn)) slova[zn-'a']++;
  }
}

/* Ispitivanje funkcije znakovi.                                          */

void main () {
  int cifre[10], slova[26], i;
  znakovi (cifre, slova);
  for (i=0; i<10; i++)
    if (cifre[i]) printf ("%d %3d\n", i, cifre[i]);
  for (i=0; i<26; i++)
    if (slova[i]) printf ("%c %3d\n", i+'a', slova[i]);
}
