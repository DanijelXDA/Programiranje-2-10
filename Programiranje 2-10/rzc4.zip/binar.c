// binar.c - Ispisivanje u binarnom brojevnom sistemu.

#include <stdio.h>

int main() {
  while (1) {
    printf("Decimalan broj? ");
    short dec;
    scanf("%hd", &dec);
  if (dec == 9999) break;
    printf("Binaran broj:   ");
    for (int i=1; i<=16; i++) {
      short bit = (dec & 0x8000) != 0;
      printf("%d", bit);
      if (i % 4 == 0) printf(" ");
      dec <<= 1;
    }
    printf("\n");
  }
}
