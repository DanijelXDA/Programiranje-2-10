// binko1.c - Ispisivanje binomnih koeficijenata.

#include <stdio.h>

int main() {
  printf("nmax? "); int nmax; scanf("%d", &nmax);
  printf("\n");
  int b[20];
  for (int n=0; n<=nmax; n++) {
    b[n] = 1;
    for (int k=n-1; k>0; k--) b[k] += b[k-1];
    for (int k=0; k<=n; printf("%4d", b[k++]));
    printf("\n");
  }
}
