// binko2.c - Izra�unavanje datog binomnog koeficijenta.

int binko(int n, int k) {
  int b = 1;
  for (int i=1, j=n; i<=k; b=b*j--/i++);
  return b;
}

// Ispisivanje Paskalovog trougla.

#include <stdio.h>

int main() {
  printf("nmax? "); int nmax; scanf("%d", &nmax);
  putchar('\n');
  for (int n=0; n<=nmax; n++) {
    for (int i=0; i<nmax-n; i++) printf("  ");
    for (int k=0; k<=n; k++) printf("%4d", binko(n, k));
    putchar('\n');
  }
}
