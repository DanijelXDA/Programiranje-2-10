// binko3.c - Rekurzivna funkcija za ra�unanje binomnog koeficijenta.

int binko(int n, int k) {
  return (0<k && k<n) ? binko(n-1, k-1) + binko(n-1, k) : 1;
}

#include <stdio.h>
#include <stdlib.h>

int main(int bpar, const char *vpar[]) {
  int nmax = atoi(vpar[1]);
  for (int n=0; n<=nmax; n++) {
    for (int k=0; k<=n; k++)
      printf("%5d", binko(n, k));
    putchar('\n');
  }
}
