// bit32.c - Raspakivanje 32-bitnog celobrojnog podatka.

#include <stdio.h>

void bit32(unsigned long k, char a[]) {
  for (int i=31; i>=0; i--) {
    a[i] = k & 1;
    k >>= 1;
  }
}

// Ispitivanje funkcije bit32.

int main() {
  while (1) {
    unsigned long broj; scanf("%lx", &broj);
  if (broj == 0x9999) break;
    printf("Procitani broj: %lx\n", broj);
    char bit[32];
    bit32(broj, bit);
    printf("Bitovi broja:   ");
    for (int i=0; i<32; i++) {
      printf("%d", bit[i]);
      if (i%4 == 3) putchar(' ');
    }
    printf("\n\n");
  }
}
