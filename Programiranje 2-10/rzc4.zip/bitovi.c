// bitovi.c - Brojanje bitova.

#include <stdio.h>

int jedan(unsigned long k)                              // Broj jedinica.
  { int n = 0; while (k) { n += k & 1; k>>=1; } return n; }

int nula(unsigned long k) { return jedan(~k); }        // Broj nula.

int main() {                       // Ispitivanje funkcija jedan i nula.
  while (1) {
    unsigned long k;
    printf("Heksadecimalan broj? "); scanf("%lx", &k);
  if (k == 0x9999) break;
    printf("Broj jedinica:       %d\n",   jedan(k));
    printf("Broj nula:           %d\n\n", nula (k));
  }
}
