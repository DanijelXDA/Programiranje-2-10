// broj.c - Brojevi elemenata niza s pojedinim ostacima.

#include <stdio.h>
#define N 50
#define K 20

void broj(const int a[], int n, int b[], int k) {
  for (int i=0; i<k; b[i++]=0);
  for (int i=0; i<n; b[a[i++]%k]++);
}

// Ispitivanje funkcije broj.

int main() {
  while (1) {
    printf("n? "); int n; scanf("%d", &n);
  if (n<=0 || n>N) break;
    printf("A? "); int a[N];
    for (int i=0; i<n; scanf("%d", &a[i++]));
    printf("k? "); int k; scanf("%d", &k);
    int b[K];
    broj(a, n, b, k);
    printf("B=");
    for (int i=0; i<k; printf(" %d",b[i++]));
    printf("\n\n");
  }
}
