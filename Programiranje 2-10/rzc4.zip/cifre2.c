// cifre2.c - Broj pojavljivanja pojedinih cifara u tekstualnoj datoteci.

#include <stdio.h>
#include <ctype.h>

_Bool cifre(char *imedat, int broj[10]) {
  FILE *dat = fopen(imedat, "r");
  if (dat == NULL) return 0;
  for (int i=0; i<10; broj[i++]=0);
  int zn;
  while ((zn = fgetc(dat)) != EOF)
    if (isdigit(zn)) broj[zn-'0']++;
  fclose(dat);
  return 1;
}

int main(int bpar, char *vpar[]) {
  int broj[10];
  if (cifre(vpar[1], broj)) {
    for (int i=0; i<10; i++)
      if (broj[i])
        printf("Cifra %d se pojavljuje %d puta.\n", i, broj[i]);
  } else  printf("*** Otvaranje datoteke nije uspelo!\a\n");
}
