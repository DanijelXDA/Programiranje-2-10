// datum.c - Definicije paketa funkcija za obradu datuma.

#include "datum.h"
#include <stdio.h>
#include <stdlib.h>

// Brojevi dana po mesecima.
const char duz[][12]  = {{31,28,31,30,31,30,31,31,30,31,30,31},
                         {31,29,31,30,31,30,31,31,30,31,30,31}};

// Brojevi protekli dana od po�etka godine po mesecima.
const int  prot[][12] = {{0,31,59,90,120,151,181,212,243,273,304,334},
                         {0,31,60,91,121,152,182,213,244,274,305,335}};
 
// Skra�enice imena i imena dana u nedelji i meseci.
const char *dan1[] = {"po", "ut", "sr", "ce", "pe", "su", "NE"},
           *dan2[] = {"ponedeljak", "utorak", "sreda", "cetvrtak",
                      "petak", "subota", "nedelja"},
           *mes1[] = {"jan", "feb", "mar", "apr", "maj", "jun",
                      "jul", "avg", "sep", "okt", "nov", "dec"},
           *mes2[] = {"januar", "februar", "mart", "april", "maj", "jun",
                      "jul", "avgust", "septembar", "oktobar", "novembar",
                      "decembar"};

_Bool prestupna(short g) { return g%4==0 && g%100!=0 || g%400==0; }

_Bool ispravan(char d, char m, short g)
  { return g>0 && m>0 && m<=12 && d>0 && d<=duz[prestupna(g)][m-1]; }

Datum sastavi(char d, char m, short g) {
  if (!ispravan(d, m, g)) exit(1);
  return (Datum){d, m, g};
}

Datum citaj() {
  short d, m, g;
  while (1) {
    scanf("%d%d%d", &d, &m, &g);
  if (ispravan(d,m,g)) break;
    printf("\n*** Neispravan datum, unesite ponovo: ");
  }
  return sastavi(d, m, g);
}

void pisi(Datum dat, int nacin) {
  printf("%.2d.", dat.dan);
  switch (nacin) {
    case 1:  printf(" %s ", mes1[dat.mes-1]); break; // Skra�eno ime mes.
    case 2:  printf(" %s ", mes2[dat.mes-1]); break; // Puno ime meseca.
    default: printf("%.2d.", dat.mes);        break; // Redni broj meseca
  }
  printf("%d.", dat.god);
}

int dan_u_god(Datum dat)
  { return prot[prestupna(dat.god)][dat.mes-1] + dat.dan; }

long uk_dan(Datum dat) {
  short g = dat.god - 1;
  return g*365L + g/4 - g/100 + g/400 + dan_u_god(dat);
}

int dan_u_ned(Datum dat) { return (uk_dan(dat) + 6) % 7 + 1; }

int duz_mes(Datum dat) { return duz[prestupna(dat.god)][dat.mes-1]; }

Datum sutra(Datum dat) {
  if (dat.dan < duz_mes(dat)) dat.dan++;
  else {
    dat.dan = 1;
    if (dat.mes < 12) dat.mes++;
    else { dat.mes = 1; dat.god++; }
  }
  return dat;
}
 
Datum juce(Datum dat) {
  if (dat.dan > 1) dat.dan--;
  else {
    if (dat.mes > 1) dat.mes--;
    else { dat.mes = 12; dat.god--; }
    dat.dan = duz_mes(dat);
  }
  return dat;
}

Datum dodaj(Datum dat, unsigned k) {
  for (unsigned i=0; i<k; i++) dat = sutra(dat);
  return dat;
}

Datum oduzmi(Datum dat, unsigned k) {
  for (unsigned i=0; i<k; i++) dat = juce(dat);
  return dat;
}

long razlika(Datum dat1, Datum dat2) { return uk_dan(dat1)-uk_dan(dat2); }

const char *ime_mes1(Datum dat) { return mes1[dat.mes-1]; }
const char *ime_mes2(Datum dat) { return mes2[dat.mes-1]; }
const char *ime_dan1(Datum dat) { return dan1[dan_u_ned(dat)-1]; }
const char *ime_dan2(Datum dat) { return dan2[dan_u_ned(dat)-1]; }
