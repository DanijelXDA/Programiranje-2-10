// datum.h - Deklaracije paketa funkcija za obradu datuma.

typedef struct { char dan, mes; short god; } Datum;

_Bool prestupna(short g);                  // Da li je prestupna godina?
_Bool ispravan(char d, char m, short g);   // Da li je ispravan datum?
Datum sastavi(char d, char m, short g);    // Formiranje datuma.
Datum citaj(void);                         // �itanje datuma.
void pisi(Datum dat, int nacin);           // Pisanje datuma.
int dan_u_god(Datum dat);                  // Redni broj dana u godini.
long uk_dan(Datum dat);                    // Redni broj dana od 1.1.1.
int dan_u_ned(Datum dat);                  // Redni broj dana u nedelji.
int duz_mes(Datum dat);                    // Broj dana u mesecu.
Datum sutra(Datum dat);                    // Seled�i datum.
Datum juce(Datum dat);                     // Prethodni datum.
Datum dodaj(Datum dat, unsigned k);        // Dodavanje celog broja.
Datum oduzmi(Datum dat, unsigned k);       // Oduzimanje celog broja.
long razlika(Datum dat1, Datum dat2);      // Razlika dva datuma.
const char *ime_dan1(Datum dat);           // Skra�eno ime dana.
const char *ime_dan2(Datum dat);           // Potpuno ime dana.
const char *ime_mes1(Datum dat);           // Skra�eno ime meseca.
const char *ime_mes2(Datum dat);           // Potpuno ime meseca.
