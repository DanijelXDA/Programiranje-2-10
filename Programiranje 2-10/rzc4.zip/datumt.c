// datumt.c - Ispitivanje paketa funkcija za obradu datuma

#include "datum.h"
#include <stdio.h>

int main() {
  printf("Danasnji datum? "); Datum dat1 = citaj();
  printf("Datum rodjenja? "); Datum dat2 = citaj();
  printf("Danas je %s, %d. dan u godini.\n",
         ime_dan2(dat1), dan_u_god(dat1));
  printf("Rodili ste se u %s i imate %ld dana.\n",
         ime_dan2(dat2), razlika(dat1,dat2));
  return 0;
}
