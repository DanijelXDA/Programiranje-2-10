// dimmat.c - Definicije paketa funkcija za obradu dinami�kih matrica.

#include "dinmat.h"
#include <stdlib.h>
#include <stdio.h>

typedef enum {MEM, DIM} Greska;                       // �ifre gre�aka.

const char *poruke[] = { "Neuspela dodela memorije", // Poruke o gre�kama.
                         "Neusaglasene dimenzije matrica"
                       };

static void greska(Greska g) {            // Ispisivanje poruke o gre�ci.
  printf("\n*** %s! ***\n\a", poruke[g]);
  exit(g+1);
}
 
Din_mat stvori(int m, int n) {                   // Dodela memorije.
  Din_mat dm = {malloc(m * sizeof(float*)), m, n};
  if (dm.a == NULL) greska(MEM);
  for (int i=0; i<m; i++)
    if ((dm.a[i] = malloc(n * sizeof(float))) == NULL) greska(MEM);
  return dm;
}

void unisti(Din_mat dm) {                        // Osloba�anje memorije.
  for (int i=0; i<dm.m; free(dm.a[i++]));
  free(dm.a);
}

Din_mat kopiraj(Din_mat dm) {                    // Kopiranje matrice.
  Din_mat dm2 = stvori(dm.m, dm.n);
  for (int i=0; i<dm.m; i++)
    for (int j=0; j<dm.n; j++)
      dm2.a[i][j] = dm.a[i][j];
  return dm2;
}

Din_mat citaj(int m, int n) {                    // �itanje matrice.
  Din_mat dm = stvori(m, n);
  for (int i=0; i<m; i++)
    for (int j=0; j<n; scanf("%f",&dm.a[i][j++]));
  return dm;
}

void pisi(Din_mat dm, const char *frm, int max){ // Ispisivanje matrice.
  for (int i=0; i<dm.m; i++) {
    for (int j=0; j<dm.n; j++) {
      printf(frm, dm.a[i][j]);
      putchar((j%max==max-1 || j==dm.n-1) ? '\n' : ' ');
    }
    if (dm.n > max) putchar('\n');
  }
}

Din_mat transpon(Din_mat dm) {                   // Transponovana matrica
  Din_mat dm2 = stvori(dm.n, dm.m);
  for (int i=0; i<dm.m; i++)
    for (int j=0; j<dm.n; j++) dm2.a[j][i] = dm.a[i][j];
  return dm2;
}

Din_mat zbir(Din_mat dm1, Din_mat dm2) {         // Zbir matrica.
  if (dm1.m!=dm2.m || dm1.n != dm2.n) greska(DIM);;
  Din_mat dm3 = stvori(dm1.m, dm1.n);
  for (int i=0; i<dm3.m; i++)
    for (int j=0; j<dm3.n; j++)
      dm3.a[i][j] = dm1.a[i][j] + dm2.a[i][j];
  return dm3;
}
 
Din_mat razlika(Din_mat dm1, Din_mat dm2) {      // Razlika matrica.
  if (dm1.m!=dm2.m || dm1.n != dm2.n) greska(DIM);;
  Din_mat dm3 = stvori(dm1.m, dm1.n);
  for (int i=0; i<dm3.m; i++)
    for (int j=0; j<dm3.n; j++)
      dm3.a[i][j] = dm1.a[i][j] - dm2.a[i][j];
  return dm3;
}

Din_mat proizvod(Din_mat dm1, Din_mat dm2) {     // Proizvod matrica.
  if (dm1.n != dm2.m) greska(DIM);;
  Din_mat dm3 = stvori(dm1.m, dm2.n);
  for (int i=0; i<dm3.m; i++)
    for (int k=0; k<dm3.n; k++) {
      dm3.a[i][k] = 0;
      for (int j=0; j<dm2.n; j++)
        dm3.a[i][k] += dm1.a[i][j] * dm2.a[j][k];
    }
  return dm3;
}
