// dinmatt.c - Ispitivanje paketa funkcija za obradu dinami�kih matrica.

#include "dinmat.h"
#include <stdio.h>

int main() {
  while (1) {
    printf("n1, m1? "); int m, n; scanf("%d%d", &m, &n);
  if (m<=0 || n<=0) break;
    printf("Matr1?  ");
    Din_mat dm1 = citaj(m, n);
    printf("n2, m2? ");
    scanf("%d%d", &m, &n);
  if (m<=0 || n<=0) break;
    printf("Matr2?  ");
    Din_mat dm2 = citaj(m, n);
    if (dm1.m==dm2.m &&
        dm1.n==dm2.n) {
      Din_mat dm3 = zbir(dm1, dm2);
      printf("ZBIR:\n");
      pisi(dm3, "%8.2f", 8);
      unisti(dm3);
      dm3 = razlika(dm1, dm2);
      printf("RAZLIKA:\n");
      pisi(dm3, "%8.2f", 8);
      unisti(dm3);
    }
    if (dm1.n == dm2.m) {
      Din_mat dm3 = proizvod(dm1, dm2);
      printf("PROIZVOD:\n");
      pisi(dm3, "%8.2f", 8);
      unisti(dm3);
    }
    putchar('\n');
    unisti(dm1); unisti(dm2);
  }
  return 0;
}
