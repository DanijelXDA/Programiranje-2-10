// dinniz.h - Deklaracije paketa funkcija za obradu dinami�kih nizova.

typedef struct { int *a, n; } Din_niz;      // Struktura dinami�kog niza.

Din_niz sastavi (int *a, int n); // Sastavljanje dinami�kog niza.
void    razlozi (Din_niz dn, int *a, int *n); // Razlaganje dinam. niza.
Din_niz kopiraj (Din_niz dn);    // Kopiranje dinami�kog niza.
void    obrni   (Din_niz dn);    // Obrtanje redosleda elemenata din. niza.
void    izostavi(Din_niz *dn, int k); // Izostavljanje elemenata din. niza.
Din_niz citaj   (void);          // �itanje dinami�kog niza.
void    pisi    (Din_niz dn);    // Ispisivanje dinami�kog niza.
