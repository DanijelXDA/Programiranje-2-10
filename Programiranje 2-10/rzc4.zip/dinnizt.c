// dinnizt.c - Ispitivanje paketa funkcija za obradu dinami�kih nizova.

#include "dinniz.h"
#include <stdio.h>
#include <stdlib.h>

int main() { Din_niz dn1;
  while ((dn1 = citaj()), dn1.a != NULL) {
    printf("Izostavlja se? "); int k; scanf("%d", &k);
                                 printf("Procitani niz:   "); pisi(dn1);
    Din_niz dn2 = kopiraj(dn1);  printf("Kopirani niz:    "); pisi(dn2);
    obrni(dn2);                  printf("Obrnuti niz:     "); pisi(dn2);
    int a[50], n;
    razlozi(dn1, a, &n);         printf("Razlozeni niz:   ");
    for (int i=0; i<n; printf("%6d", a[i++])); putchar('\n');
    Din_niz dn3 = sastavi(a, n); printf("Sastavljeni niz: "); pisi(dn3);
    izostavi(&dn3, k);           printf("Redukovani niz:  "); pisi(dn3);
    putchar('\n'); free(dn1.a); free(dn2.a); free(dn3.a);
  }
  return 0;
}
