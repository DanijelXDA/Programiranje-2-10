// ekspon.c - Izra�unavanje exp(x) pomo�u Tejlorovog razvoja.

#include <stdio.h>
#include <math.h>

double ekspon(double x, int n) {
  double ex = 1, clan = 1;
  for (int i=1; i<n; i++) { clan *= x / i; ex += clan; }
  return ex;
}

int main() {
  double xmin, xmax, dx;
  printf("xmin, xmax, dx? "); scanf("%lf%lf%lf", &xmin, &xmax, &dx);
  int    nmin, nmax, dn;
  printf("nmin, nmax, dn? "); scanf("%d%d%d",    &nmin, &nmax, &dn);
  int k = printf("\n%6s %12s %3s %14s %10s\n",
                 "x", "ext", "n", "ex", "relgr");
  for (int i=0; i<k-2; i++) putchar('='); putchar('\n');
  for (double x=xmin; x<=xmax; x+=dx)
    for (int n=nmin; n<=nmax; n+=dn) {
      double ex  = ekspon(x, n);                  // Izra�unata vrednost.
      double ext = exp(x);                        // Ta�na vrednost.
      double apsgr = ex - ext;                    // Apsolutna gre�ka.
      double relgr = apsgr / ext;                 // Relativna gre�ka.
      printf("%6.2f %#12.7g %3d %#14.7g %10.2e\n", x, ext, n, ex, relgr);
    }
}
