// fakt.c - Rekurzivna funkcija za ra�unanje n!

long fakt(int n) {
  return (n > 0) ? n * fakt(n-1) : 1;
}

#include <stdio.h>
#include <stdlib.h>

int main(int bpar, const char *vpar[]) {
  int nmax = atoi(vpar[1]);
  for (int n=0; n<=nmax; n++)
    printf("%2d%12ld\n", n, fakt(n));
}
