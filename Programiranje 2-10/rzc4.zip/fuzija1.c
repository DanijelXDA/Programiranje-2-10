// fuzija1.c - Fuzija dva ure�ena niza celih brojeva u novi niz.

#include <stdio.h>
#define N 100

int main() {
  while (1) {
    printf("na? "); int na; scanf("%d", &na);
  if (na<0 || na>N) break;
    printf("A ? "); int a[N]; for (int ia=0; ia<na; scanf("%d", &a[ia++]));
    if (na == 0) printf("\n");
    printf("nb? "); int nb; scanf("%d", &nb);
  if (nb<0 || nb>N) break;
    printf("B ? "); int b[N]; for (int ib=0; ib<nb; scanf("%d", &b[ib++]));
    if (nb == 0) printf("\n");
    int ia = 0, ib = 0, ic = 0, c[2*N];
    while (ia<na && ib<nb) c[ic++] = (a[ia]<b[ib]) ? a[ia++] : b[ib++];
    while (ia < na) c[ic++] = a[ia++];
    while (ib < nb) c[ic++] = b[ib++];
    int nc = ic;
    printf("C = "); for (int ic=0; ic<nc; printf("%d ", c[ic++]));
    printf("\n\n");
  }
}
