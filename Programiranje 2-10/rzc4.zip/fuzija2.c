// fuzija2.c - Fuzija dva ure�ena niza celih brojeva u prvi od nizova.

#include <stdio.h>
#define N 100

int main() {
  while (1) {
    printf("na? "); int na; scanf("%d", &na);
  if (na<0 || na>N) break;
    printf("A ? "); int a[2*N]; for (int ia=0; ia<na; scanf("%d",&a[ia++]));
    if (na == 0) printf("\n");
    printf("nb? "); int nb; scanf("%d", &nb);
  if (nb<0 || nb>N) break;
    printf("B ? "); int b[N]; for (int ib=0; ib<nb; scanf("%d", &b[ib++]));
    if (nb == 0) printf("\n");
    int ia = na - 1, ib = nb - 1, ic = (na += nb) - 1;
    while (ia>=0 && ib>=0) a[ic--] = (a[ia]>b[ib]) ? a[ia--] : b[ib--];
    while (ib >= 0) a[ic--] = b[ib--];
    printf("A = "); for (int ia=0; ia<na; printf("%d ", a[ia++]));
    printf("\n\n");
  }
}
