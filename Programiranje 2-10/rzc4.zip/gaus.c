// gaus.c - Gausova eliminaciona metoda.

#include <stdio.h>
#include <stdlib.h>

int main() {
  while (1) {
    // �itanje reda sistema jedna�ina:
    int n; scanf("%d", &n);
  if (n <= 0) break;

    // �itanje koeficijenata sistema:
    printf("Sistem linearnih jednacina:\n\n");
    float **a = malloc(n * sizeof(float *));
    float  *b = malloc(n * sizeof(float));
    float  *x = malloc(n * sizeof(float));
    for (int i=0; i<n; i++) {
      a[i] = malloc(n * sizeof(float));
      for (int j=0; j<n; j++) {
        scanf("%f", &a[i][j]);
        printf("%7.3f", a[i][j]);
      }
      scanf("%f", &b[i]);
      printf(" | %7.3f\n", b[i]);
    }

    // Eliminacija unapred:
    for (int i=0; i<n-1; i++)
      for (int j=i+1; j<n; j++) {
        float c = a[j][i] / a[i][i];
        for (int k=i; k<n; k++) a[j][k] -= a[i][k] * c;
        b[j] -= b[i] * c;
      }

    // Zamenjivanje unazad:
    for (int j=n-1; j>=0; j--) {
      float c = b[j];
      for (int k=j+1; k<n; k++) c -= a[j][k] * x[k];
      x[j] = c / a[j][j];
    }

    // Ispisivanje rezultata:
    printf("\nResenja sistema:\n\n");
    for (int i=0; i<n; printf("%7.3f", x[i++]));
    putchar('\n');

    // Osloba�anje dinami�ki dodeljene
    // memorije:
    for (int i=0; i<n; free(a[i++]));
    free(a); free(b); free(x);
  }
}
