// gradovi.c - Ure�ivanje imena gradova sme�tenih u dinami�ku matricu.

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAX_GRAD 100
#define MAX_DUZ  30

int main() {

  // �itanje i obrada pojedina�nih imena:
  printf("\nNeuredjeni niz imena gradova:\n\n");
  char **gradovi = malloc(MAX_GRAD * sizeof(char *));
  int br_grad = 0;
  do {

    char *grad = malloc(MAX_DUZ);
    gets(grad);    // �itanje slede�eg imena.

  // Kraj ako je du�ina imena nula.
    int duz = strlen(grad);
  if (duz == 0) { free(grad); break; }

    grad = realloc(grad, duz+1);
    puts(grad);    // Ispisivanje pro�itanog imena.

    // Uvr�tavanje novog imena u ure�eni niz starih imena.
    int i;
    for (i=br_grad-1; i>=0; i--)
      if (strcmp(gradovi[i], grad) > 0)
        gradovi[i+1] = gradovi[i];
      else break;
    gradovi[i+1] = grad;

    // Nastavak rada ako ima jo� slobodnih vrsta u matrici.
  } while (++br_grad < MAX_GRAD);
  gradovi = realloc(gradovi, br_grad * sizeof(char *));

  // Ispisivanje ure�enog niza imena:
  printf("\nUredjeni niz imena gradova:\n\n");
  for (int i=0; i<br_grad; puts(gradovi[i++]));
}
