// grafik1.c - Tabeliranje i grafi�ki prikaz funkcije bez x-ose.

#include <stdio.h>
#include <math.h>
#define SIR 40  // �irina slike.

int main() {
  double xmin, xmax, dx, ymin, ymax;
  printf("xmin, xmax, dx? "); scanf("%lf%lf%lf", &xmin, &xmax, &dx);
  printf("ymin, ymax?     "); scanf("%lf%lf",    &ymin, &ymax);
  putchar('\n');
  double dy = (ymax - ymin) / (SIR - 1);
  for (double x=xmin; x<=xmax; x+=dx) {
    double y = exp(-0.1*x) * sin(x);
	int k = (y - ymin) / dy;
    printf("%9.3f %9.3f ", x, y);
    if (k>=0 && k<SIR) printf("%*c", k+1, '*');
    putchar('\n');
  }
}
