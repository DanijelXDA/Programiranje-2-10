// grafik2.c - Tabeliranje i grafi�ki prikaz funkcije s x-osom.

#include <stdio.h>
#include <math.h>
#define SIR 40  // �irina slike.

int main() {
  double xmin, xmax, dx, ymin, ymax;
  printf("xmin, xmax, dx? "); scanf("%lf%lf%lf", &xmin, &xmax, &dx);
  printf("ymin, ymax?     "); scanf("%lf%lf",    &ymin, &ymax);
  putchar('\n');
  double dy = (ymax - ymin) / (SIR - 1);
  int xosa = -ymin / dy;
  for (double x=xmin; x<=xmax; x+=dx) {
    double y = exp(-0.1*x) * sin(x);
    int k = (y - ymin) / dy;
    printf("%9.3f %9.3f ", x, y);
    if (k>=0 && k<SIR) {
      if (k <= xosa) {
        printf("%*c", k+1, '*');
        if (xosa>k && xosa<SIR) printf("%*c", xosa-k, '|');
      } else {
        if (xosa >=0) printf("%*c%*c", xosa+1, '|', k-xosa, '*');
        else          printf("%*c", k+1, '*');
      }
    } else if (xosa>=0 || x<SIR) printf("%*c", xosa+1, '|');
    putchar('\n');
  }
}
