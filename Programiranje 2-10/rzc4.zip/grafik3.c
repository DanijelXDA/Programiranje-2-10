// grafik3.c - Graficki prikaz realne funkcije s jednim realnim arg.

#include <stdio.h>
#include <stdlib.h>

void grafik(double (*f)(double), double xmin, double xmax, int sir,
                                 double ymin, double ymax, int vis) {
  double dx = (xmax - xmin) / (sir - 1);
  double dy = (ymax - ymin) / (vis - 1);
  int *y = malloc(sir * sizeof(int));
  for (int i=0; i<sir; i++) y[i] = ((*f)(xmin + i * dx) - ymin) / dy;
  int yosa = -xmin / dx;
  int xosa = -ymin / dy;
  for (int j=vis-1; j>=0; j--) {
    int k = -1;
    for (int i=0; i<sir; i++) {
      char zn = ' ';
      if      (y[i] == j) zn = '*';
      else if (j==xosa && i==yosa) zn = '+';
      else if (i == yosa) zn = '|';
      else if (j == xosa) zn = '-';
      if (zn != ' ') {
        printf("%*s%c", i-k-1, "", zn);
        k = i;
      }
    }
    putchar('\n');
  }
  free(y);
}
