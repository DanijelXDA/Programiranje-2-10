// grafik3t.c - Ispitivanje funkcije grafik.

#include <stdio.h>

double oscil(double);                 // Prototipi funkcija.
double polinom(double);
void grafik(double (*)(double), double, double, int,
                                double, double, int);

extern double poli[];                  // Deklaracije globalnih podataka.
extern int n;

int main() {                          // Glavna funkcija.
  while (1) {
    printf("\nFunkcija (O - oscilacije, P - polinom, . - kraj)? ");
    char izb[2]; scanf("%1s", izb);
  if (izb[0] == '.') break;
 
    double (*fun)(double);
    switch (izb[0]) {
      case 'o': case 'O': fun = oscil; break;
      case 'p': case 'P': fun = polinom;
                          printf("Red polinoma? "); scanf("%d", &n);
                          printf("Koeficijenti polinoma? ");
                          for (int i=n; i>=0; scanf("%lf", &poli[i--]));
                          break;
      default: printf("*** Nedozvoljen izbor! ***\n");
               continue;
    }
    double xmin, xmax, ymin, ymax; int sir,vis;
    printf("xmin, xmax, sir? "); scanf("%lf%lf%d", &xmin, &xmax, &sir);
    printf("ymin, ymax, vis? "); scanf("%lf%lf%d", &ymin, &ymax, &vis);
    putchar('\n');
    grafik(fun, xmin, xmax, sir, ymin, ymax, vis);
  }
}
