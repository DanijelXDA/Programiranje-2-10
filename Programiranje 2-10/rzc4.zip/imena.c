// imena.c - Ure�ivanje imena po abecednom redosledu.

#include <stdio.h>
#include <string.h>
#define N 100     // Najve�i broj imena.
#define D 40      // Najve�a du�ina imena.

int main() {

  // �itanje neure�enog niza imena:
  char ljudi[N][D+1]; int n = 0;
  printf("Neuredjen niz prezimena i imena?\n\n");
  do
    gets(ljudi[n]);
  while (strcmp(ljudi[n++],". .") != 0);
  n--;

  // Ure�ivanje niza imena:
  for (int i=0; i<n-1; i++) {
    int m = i;
    for (int j=i+1; j<n; j++)
      if (strcmp(ljudi[j], ljudi[m]) < 0) m = j;
    if (m != i) {
      char osoba[D+1];
      strcpy(osoba   , ljudi[i]);
      strcpy(ljudi[i], ljudi[m]);
      strcpy(ljudi[m], osoba   );
    }
  }

  // Ispisivanje ure�enog niza imena:
  printf("\nUredjeni niz imena:\n\n");
  for (int i=0; i<n; puts(ljudi[i++]));
}
