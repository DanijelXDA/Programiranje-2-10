// izost2.c - Izostavljanje bloka elemenata niza.

#include <stdio.h>
#define N 100

int main() {
  while (1) {
    printf("n? "); int n; scanf("%d", &n);
  if (n<=0 || n>N) break;
    printf("A? "); int a[N];
    for (int i=0; i<n; scanf("%d", &a[i++]));
    printf("p,k? "); int p, k; scanf("%d%d", &p, &k);
    for (int i=p+k; i<n; i++) a[i-k] = a[i];
    n -= k;
    printf("A= "); for (int i=0; i<n; printf("%d ",a[i++]));
    printf("\n\n");
  }
}
