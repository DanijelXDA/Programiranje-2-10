// izost3.c - Izostavljanje odre�enih elemenata niza.

#include <stdio.h>
#define N 100

int main() {
  while (1) {
    printf("n? "); int n; scanf("%d", &n);
  if (n<=0 || n>N) break;
    printf("A? "); int a[N];
    for (int i=0; i<n; scanf("%d", &a[i++]));
    printf("b? "); int b; scanf("%d", &b);
    int j = 0;
    for (int i=0; i<n; i++) if (a[i] != b) a[j++] = a[i];
    n = j;
    printf("A= "); for (int i=0; i<n; printf("%d ",a[i++]));
    printf("\n\n");
  }
}
