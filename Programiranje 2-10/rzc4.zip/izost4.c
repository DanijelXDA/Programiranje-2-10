// izost4.c - Izostavljanje vrste i kolone matrice sa najve�im elementom.

#include <stdio.h>
#define N 30

int main() {
  // �itanje matrice:
  FILE *dat = fopen("izost4.pod", "r");
  int m, n, a[N][N];
  fscanf(dat, "%d%d", &m, &n);
  for (int i=0; i<m; i++)
    for (int j=0; j<n; fscanf(dat, "%d", &a[i][j++]));
  fclose(dat);

  // Nala�enje mesta najve�eg elementa:
  int max = a[0][0], imax = 0, jmax = 0;
  for (int i=0; i<m; i++)
    for (int j=0; j<n; j++)
      if (a[i][j]>max) { max=a[i][j]; imax=i; jmax=j; }

  // Izostavljanje kolone:
  for (int i=0; i<m; i++)
    for (int j=jmax; j<n-1; j++) a[i][j] = a[i][j+1];
  n--;

  // Izostavljanje vrste:
  for (int j=0; j<n; j++)
    for (int i=imax; i<m-1; i++) a[i][j] = a[i+1][j];
  m--;

  // Upisivanje rezultata u datoteku:
  dat = fopen("izost4.rez", "w");
  fprintf(dat, "%d %d\n", m, n);
  for (int i=0; i<m; i++) {
    for (int j=0; j<n; fprintf(dat, "%d ", a[i][j++]));
    fputc('\n', dat);
  }
  fclose(dat);
}
