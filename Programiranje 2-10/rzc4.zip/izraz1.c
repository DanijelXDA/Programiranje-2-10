// izraz1.c - Izra�unavanje zbira uzastopnih prirodnih brojeva.

#include <stdio.h>

int main() {
  printf("n? "); int n; scanf("%d", &n);
  int s = 0;
  for (int i=1; i<=n; s+=i++);
  printf("s= %d\n", s);
}
