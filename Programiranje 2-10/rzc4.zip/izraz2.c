// izraz2.c - Izra�unavanje proizvoda uzastopnih prirodnih brojeva.

#include <stdio.h>

int main() {
  printf("n? "); int n; scanf("%d", &n);
  long s = 1;
  for (int i=1; i<=n; s*=i++);
  printf("s= %ld\n", s);
}
