// izraz3.c - Izra�unavanje zbira faktorijela.

#include <stdio.h>

int main() {
  printf("n? "); int n; scanf("%d", &n);
  long s = 0, f = 1;
  for (int i=1; i<=n; i++) {
    f *= i;
    s += f;
  }
//  for (int i=1; i<=n; s+=(f*=i++));
  printf("s= %ld\n", s);
}
