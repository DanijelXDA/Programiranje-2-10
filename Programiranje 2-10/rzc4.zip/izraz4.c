// izraz4.c - Izra�unavanje slo�enog zbira.

#include <stdio.h>

int main() {
  printf("n? "); int n; scanf("%d", &n);
  double s = 0, g = 0; long f = 1;
  for (int i=1; i<=n; i++) {
    f *= i;
    g += 1. / (i+1);
    s += f / g;
  }
  printf("s= %f\n", s);
}
