// izraz5.c - Izra�unavanje slo�enog zbira.

#include <stdio.h>

int main() {
  printf("n? "); int n; scanf("%d", &n);
  int f = 0, g = 0, z = 1; double s = 0;
  for (int i=1; i<=n; i++) {
    f += i;
    g += i * i;
    s += z * (double)f / g;
    z = -z;
  }
  printf("s= %f\n", s);
}
