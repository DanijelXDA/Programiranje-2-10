// kompleks.c - Obrada kompleksnih brojeva.

#include <math.h>
#include <stdio.h>

typedef struct { double re, im; } Kompl;  // Struktura kompleksnog broja.

Kompl zbir   (Kompl a, Kompl b) { a.re += b.re; a.im += b.im; return a; }

Kompl razlika(Kompl a, Kompl b) { a.re -= b.re; a.im -= b.im; return a; }

Kompl proizvod(Kompl a, Kompl b) { Kompl c;
  c.re = a.re * b.re - a.im * b.im; c.im = a.im * b.re + a.re * b.im;
  return c;
}

Kompl kolicnik(Kompl a, Kompl b) { Kompl c;
  double d = pow(b.re, 2) + pow(b.im, 2);
  c.re = (a.re*b.re + a.im*b.im) / d; c.im = (a.im*b.re - a.re*b.im) / d;
  return c;
}

int main() {
  while (1) {
    Kompl x, y;
    printf("\nPrvi  broj (re,im)? "); scanf("%lf%lf", &x.re, &x.im);
    printf(  "Drugi broj (re,im)? "); scanf("%lf%lf", &y.re, &y.im);
  if (y.re==0 && y.im==0) break;
    printf("x     = (%f,%f)\n", x.re, x.im);
    printf("y     = (%f,%f)\n", y.re, y.im);
    Kompl z;
    z = zbir    (x, y); printf("x+y   = (%f,%f)\n", z.re, z.im);
    z = razlika (x, y); printf("x-y   = (%f,%f)\n", z.re, z.im);
    z = proizvod(x, y); printf("x*y   = (%f,%f)\n", z.re, z.im);
    z = kolicnik(x, y); printf("x/y   = (%f,%f)\n", z.re, z.im);
  }
  Kompl j = {0, 1}, z = proizvod(j, j);
                        printf("\nj^2   = (%f,%f)\n", z.re, z.im);
}
