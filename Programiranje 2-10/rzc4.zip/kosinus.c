// kosinus.c - Izra�unavanje cos(x) pomo�u Tejlorovog razvoja.

#include <stdio.h>
#include <math.h>

double kosinus(double x, int n) {
  double cosx = 1, clan = 1;
  for (int i=1; i<n; i++) { clan *= - x*x / (2*i-1) / (2*i); cosx += clan; }
  return cosx;
}

int main() {
  double xmin, xmax, dx;
  printf("xmin, xmax, dx? "); scanf("%lf%lf%lf", &xmin, &xmax, &dx);
  int    nmin, nmax, dn;
  printf("nmin, nmax, dn? "); scanf("%d%d%d",    &nmin, &nmax, &dn);
  int k = printf("\n%6s %12s %3s %14s %10s\n",
                 "x", "cosxt", "n", "cosx", "relgr");
  for (int i=0; i<k-2; i++) putchar('='); putchar('\n');
  for (double x=xmin; x<=xmax; x+=dx)
    for (int n=nmin; n<=nmax; n+=dn) {
      double cosx  = kosinus(x, n);               // Izra�unata vrednost.
      double cosxt = cos(x);                      // Ta�na vrednost.
      double apsgr = cosx - cosxt;                // Apsolutna gre�ka.
      double relgr = cosxt!=0 ? apsgr/cosxt :     // Relativna gre�ka.
                     relgr >0 ?  1e38       :
                     relgr <0 ? -1e38       : 0;
      printf("%6.2f %#12.7g %3d %#14.7g %10.2e\n", x,cosxt,n,cosx,relgr);
    }
}
