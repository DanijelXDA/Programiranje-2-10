// krug.c - Izra�unavanje obima kruga i povr�ine kruga.

#include <stdio.h>
#define PI 3.14159265359

int main() {
  double r;
  printf("Poluprecnik? ");
  scanf("%lf", &r);
  printf("Obim     = %.3f\n", 2*r*PI);
  printf("Povrsina = %.3f\n", r*r*PI);
}
