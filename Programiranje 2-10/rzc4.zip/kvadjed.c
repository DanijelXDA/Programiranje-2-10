// kvadjed.c - Re�avanje kvadratne jedna�ine.

#include <stdio.h>
#include <math.h>

int main() {
  double a, b, c,                            // Koeficijenti jedna�ine.
         d,                                  // Diskriminanta jedna�ine.
         x1, x2,                             // Realni delovi korena.
         y1, y2;                             // Imaginarni delovi korena.
  typedef enum { REALNI, DVOSTRUKI,          // Vrsta re�enja jedna�ine.
                 KOMPLEKSNI, LINEARNA, POGRESNA } Vrsta;
  Vrsta  vrsta;

  printf("Koeficijenti kvadratne jednacine? ");
  scanf("%lf%lf%lf", &a, &b, &c);

  if (a) {
    d = b * b - 4 * a * c;
    if (d > 0) {
      vrsta = REALNI;
      x1 = (- b + sqrt(d)) / (2 * a);
      x2 = (- b - sqrt(d)) / (2 * a);
    } else if (d == 0) {
      vrsta = DVOSTRUKI;
      x1 = - b / (2 * a);
    } else {
      vrsta = KOMPLEKSNI;
      x1 = - b / (2 * a);
      y1 = sqrt(-d) / (2*a);
      x2 = x1;
      y2 = - y1;
    }
  } else
    if (b) {
      vrsta = LINEARNA;
      x1 = - c / b;
    } else
      vrsta = POGRESNA;

  if (vrsta == REALNI)
    printf("Realni koreni su %.2f i %.2f\n", x1, x2);
  else if (vrsta == DVOSTRUKI)
    printf("Dvostruki realni koren je %.2f\n", x1);
  else if (vrsta == KOMPLEKSNI)
    printf("Kompleksni koreni su (%.2f,%.2f) i (%.2f,%.2f)\n",
           x1, y1, x2, y2);
  else if (vrsta == LINEARNA)
    printf("Resenje linearne jednacine je %.2f\n", x1);
  else if (vrsta == POGRESNA)
    printf("Podaci nemaju smisla!\n");
}
