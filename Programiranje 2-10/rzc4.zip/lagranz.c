// lagranz.c - Tabeliranje Lagran�ovog polinoma.

double lagranz(const double X[], const double Y[], int n, double x) {
  double p = 0;
  for (int i=0; i<n; i++) {
    double q=Y[i];
    for (int j=0; j<n; j++)
      if (j != i) q *= (x-X[j]) / (X[i]-X[j]);
    p += q;
  }
  return p;
}

#include <stdio.h>

int main() {
  printf("n? "); int n;scanf("%d", &n);
  double X[100], Y[100];
  for (int i=0; i<n; i++) {
    printf("x[%d], y[%d]? ", i, i);
    scanf("%lf%lf", &X[i], &Y[i]);
  }
  printf("xmin, xmax, dx? ");
  double xmin, xmax, dx;
  scanf("%lf%lf%lf", &xmin, &xmax, &dx);
  printf("\n     x            p(x)\n"
         "========================\n");
  for (double x=xmin; x<=xmax; x+=dx) {
    printf("%12.2f%12.2f\n", x, lagranz(X, Y, n, x));
  }
}
