// linjed.c - Re�avanje sistema od dve linearne jedna�ine.

#include <stdio.h>

int main() {
  printf("Koeficijenti prve jednacine?  ");
  double a1, b1, c1;
  scanf("%lf%lf%lf", &a1, &b1, &c1);
  printf("Koeficijenti druge jednacine? ");
  double a2, b2, c2;
  scanf("%lf%lf%lf", &a2, &b2, &c2);
  double D  = a1 * b2 - a2 * b1;
  double Dx = c1 * b2 - c2 * b1;
  double Dy = a1 * c2 - a2 * c1;
  if (D != 0) {
    double x = Dx / D;
    double y = Dy / D;
    printf("x= %10.2f\n", x);
    printf("y= %10.2f\n", y);
  } else
    if (Dx==0 && Dy==0)
      printf("Sistem je neodredjen.\n");
    else
      printf("Sistem je protivrecan.\n");
}
