// lista2.c - Definicije paketa funkcija za obradu listi (rekurzivno).

#include "lista.h"
#include <stdio.h>
#include <stdlib.h>

int duz(Elem *lst) {                   // Broj elemenata liste.
  return lst ? duz(lst->sled) + 1 : 0;
}

void pisi(Elem *lst) {                 // Ispisivanje liste.
  if (lst) { printf("%d ", lst->broj); pisi(lst->sled); }
}


Elem *na_pocetak(Elem *lst, int b) {   // Dodavanje na po�etak.
  Elem *novi = malloc(sizeof(Elem));
  novi->broj = b; novi->sled = lst;
  return novi;
}

Elem *na_kraj(Elem *lst, int b) {      // Dodavanje na kraj.
  if (!lst) {
   lst = malloc(sizeof(Elem));
   lst->broj = b; lst->sled = NULL;
 } else
   lst->sled = na_kraj(lst->sled, b);
 return lst;
}

Elem *citaj1(int n) {   // �itanje liste uz obrtanje redosleda.
  if (n == 0) return NULL;
  else {
    Elem *novi = malloc(sizeof(Elem));
    novi->sled = citaj1(n - 1);
    scanf("%d", &novi->broj);
    return novi;
  }
}

Elem *citaj2(int n) {   // �itanje liste uz �uvanje redosleda.
  if (n == 0) return NULL;
  else {
    Elem *novi = malloc(sizeof(Elem));
    scanf("%d", &novi->broj);
    novi->sled = citaj2(n - 1);
    return novi;
  }
}
 
Elem *umetni(Elem *lst, int b) {       // Umetanje u ure�enu listu.
  if (!lst || lst->broj >= b) {
    Elem *novi = malloc(sizeof(Elem));
    novi->broj = b; novi->sled = lst;
    return novi;
  } else {
    lst->sled = umetni(lst->sled, b);
    return lst;
  }
}

void brisi(Elem *lst) {                // Brisanje svih elemenata liste.
  if (lst) {
    brisi(lst->sled);
    free(lst);
  }
}

Elem *izostavi(Elem *lst, int b){ // Izostavljanje svakog pojavljivanja.
  if (lst) {
    if (lst->broj !=  b) {
      lst->sled = izostavi(lst->sled, b);
    } else {
      Elem *stari = lst;
      lst = izostavi(lst->sled, b);
      free(stari);
    }
  }
  return lst;
}
