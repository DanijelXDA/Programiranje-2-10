// lista4.h - Deklaracije paketa za obradu dvostruko spregnutih listi.

typedef struct elem { int broj; struct elem *pret, *sled; } Elem;
typedef struct { Elem *prvi, *posl, *tek; } Lista;
typedef enum {NAPRED, NAZAD} Smer;

Lista stvori(void);                      // Stvaranje prazne liste.
void  na_prvi(Lista *lst);               // Pomeranje na prvi element.
void  na_posl(Lista *lst);               // Pomeranje na poslednji element.
void  na_sled(Lista *lst);               // Pomeranje na slede�i element.
void  na_pret(Lista *lst);               // Pomeranje na prethodni element.
void  nadji_sled(Lista *lst, int b);     // Pomer. na sled. pojavljivanje.
void  nadji_pret(Lista *lst, int b);     // Pomer. na pret. pojavljivanje.
_Bool ima_tek(Lista lst);                // Da li postoji teku�i element?
int   dohvati_tek(Lista lst);            // Dohvatanje teku�eg elementa.
void  promeni_tek(Lista lst, int b);     // Menjanje teku�eg elementa.
void  dodaj_poc   (Lista *lst, int b);   // Dodavanje ispred prvog elementa.
void  dodaj_kraj  (Lista *lst, int b);   // Dodavanje iza poslednjeg elem.
void  dodaj_ispred(Lista *lst, int b);   // Dodavanje ispred teku�eg elem.
void  dodaj_iza   (Lista *lst, int b);   // Dodavanje iza teku�eg elementa.
void  izbaci_tek(Lista *lst, Smer smer); // Izbacivanje teku�eg elementa.
void  brisi_sve(Lista *lst);             // Brisanje svih elemenata.
void  pisi (Lista lst, Smer smer);       // Ispisivanje liste.
void  citaj(Lista *lst, int n, Smer smer);  // �itanje liste.
