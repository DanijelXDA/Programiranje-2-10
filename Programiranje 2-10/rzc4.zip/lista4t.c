// lista4t.c - Ispitivanje paketa za obradu dvostruko spregnutih listi.

#include "lista4.h"
#include <stdio.h>

int main() {
  Lista lst = stvori();
  while (1) {
    printf("n?        "); int n; scanf("%d", &n);
  if (n <0) break;
    printf("Lista?    "); citaj(&lst, n, NAPRED);
    if (n == 0) putchar('\n');
    printf("Izost?    "); int k; scanf("%d", &k);
    printf("Napred=   "); pisi(lst, NAPRED); putchar('\n');
    printf("Nazad=    "); pisi(lst, NAZAD);  putchar('\n');

    // Izbacivanje svakog pojavljivanja datog broja:
    na_prvi(&lst); nadji_sled(&lst, k);
    while (ima_tek(lst)) { izbaci_tek(&lst, NAPRED); nadji_sled(&lst ,k); }
    printf("Skraceno= "); pisi(lst, NAPRED); printf("\n\n");
  }
  brisi_sve(&lst);
  return 0;
}
