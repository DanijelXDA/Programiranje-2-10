// listat.c - Ispitivanje paketa funkcija za obradu listi.

#include "lista.h"
#include <stdio.h>

int main() { Elem *lst = NULL; _Bool kraj = 0;
  while (!kraj) {
    printf("\n1. Dodavanje broja na pocetak liste\n"
             "2. Dodavanje broja na kraj liste\n"
             "3. Umetanje broja u uredjenu listu\n"
             "4. Izostavljanje broja iz liste\n"
             "5. Brisanje svih elemenata liste\n"
             "6. Citanje uz obrtanje redosleda brojeva\n"
             "7. Citanje uz cuvanje redosleda brojeva\n"
             "8. Odredjivanje duzine liste\n"
             "9. Ispisivanje liste\n"
             "0. Zavrsetak rada\n\n"
             "Vas izbor? "
           );
    int izbor; scanf("%d", &izbor);
    switch (izbor) {
    case 1: case 2: case 3: case 4:
      printf("Broj?      "); int broj; scanf("%d", &broj);
      switch (izbor) {
      case 1: // Dodavanje broja na po�etak liste:
        lst = na_pocetak(lst, broj); break;
      case 2: // Dodavanje broja na kraj liste:
        lst = na_kraj(lst, broj);    break;
      case 3: // Umetanje broja u ure�enu listu:
        lst = umetni(lst, broj);     break;
      case 4: // Izostavljanje broja iz liste:
        lst = izostavi(lst, broj);   break;
      } break;
    case 5: // Brisanje svih elemenata liste:
      brisi(lst); lst = NULL; break;
    case 6: case 7: // �itanje liste:
      printf("Duzina?    "); int n; scanf("%d", &n);
      printf("Elementi?  "); brisi(lst);
      switch (izbor) {
      case 6: // uz obrtanje redosleda brojeva:
        lst = citaj1(n); break;
      case 7: // uz �uvanje redosleda brojeva:
        lst = citaj2(n); break;
      } break;
 
    case 8: // Odre�ivanje du�ine liste:
      printf("Duzina=    %d\n", duz(lst)); break;
    case 9: // Ispisivanje liste:
      printf("Lista=     "); pisi(lst); putchar('\n'); break;
    case 0: // Zavr�etak rada:
      kraj = 1; break;
    default: // Pogre�an izbor:
      printf("*** Nedozvoljen izbor! ***\a\n"); break;
    }
  }
}
