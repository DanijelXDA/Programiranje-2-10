// lstpravi.c - Obrazovanje ure�ene liste u relativnoj datoteci.

#include "reldat.h"
#include <stdio.h>

typedef struct { int sif; char txt[50]; unsigned nar; } Zapis;

int main() {
  RelDat* dat = rd_pravi("lst.dat", sizeof(Zapis));
  FILE *pod = fopen("lst.pod", "r"); // Tekstualna datoteka sa podacima.
  Zapis zap = {0, "\0", 0};          // Glava liste.
  rd_pisi(dat, 1, &zap);
  while (fscanf(pod, "%d%s", &zap.sif, &zap.txt) != EOF) {
    printf("%5d %s\n", zap.sif, zap.txt);
    unsigned nov = rd_brojzap(dat) + 1; rd_pisi(dat, nov, &zap);
    int sif = zap.sif;
    rd_citaj(dat, 1, &zap);
    int pre = 1, tek = zap.nar;
    while (tek && (rd_citaj(dat, tek, &zap) , zap.sif<sif))
      { pre = tek; tek = zap.nar; }
    rd_citaj(dat, pre, &zap); zap.nar = nov; rd_pisi(dat, pre, &zap);
    rd_citaj(dat, nov, &zap); zap.nar = tek; rd_pisi(dat, nov, &zap);
  }
  return 0;
}
