// magacin.c - Obrada relativne binarne datoteke.

#include <stdio.h>

int main() {
  typedef struct { char naziv[30]; float kolicina, cena; } Zapis;
  Zapis zapis;
  float ukupno=0, promena; int sifra, duzina = sizeof zapis;
  FILE *datot = fopen("magacin.dat", "rb+"),
       *prom  = fopen("promene.txt", "r");
  while (fscanf(prom, "%d%f", &sifra, &promena) != EOF) {
    fseek(datot, (long)(sifra-1)*duzina, SEEK_SET);
    fread(&zapis, duzina, 1, datot);
    zapis.kolicina += promena;
    ukupno += zapis.cena * promena;
    fseek(datot, -(long)duzina, SEEK_CUR);
    fwrite(&zapis, duzina, 1, datot);
  }
  printf("Ukupna promena vrednosti robe je %.2f\n", ukupno);
}
