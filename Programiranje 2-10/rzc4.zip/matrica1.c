// matrica1.c - Ure�ivanje matrice po zbirovima kolona.

#include <stdio.h>
#define N 30

int main() {
  while (1) {

    // �itanje dimenzija matrice:
    printf("\nm, n? "); int m, n;
    scanf("%d%d", &m, &n);

  if (m<=0 || m>N || n<=0 || n>N) break;

    // �itanje elemenata matrice:
    float a[N][N];
    for (int i=0; i<m; i++) {
      printf("%2d. vrsta? ", i);
      for (int j=0; j<n; scanf("%f", &a[i][j++]));
    }

    // Ra�unanje zbirova elemenata po kolonama:
    float s[N];
    for (int j=0; j<n; j++) {
      s[j] = 0;
      for (int i=0; i<m; s[j]+=a[i++][j]);
    }

    // Ure�ivanje kolona po veli�inama zbirova:
    for (int i=0; i<n-1; i++) {
      // tra�enje najmanjeg zbira
      int min = i;
      for (int j=i+1; j<n; j++)
        if (s[j]<s[min]) min = j;
      if (min != i) {
        float p=s[i]; s[i]=s[min]; s[min]=p; 
        // zamena kolona
        for (int j=0; j<m; j++)
          { float p=a[j][i]; a[j][i]=a[j][min]; a[j][min]=p; }
      }
    }

    // Ispisivanje ure�ene matrice:
    printf("\nUredjena matrica:\n");
    for (int i=0; i<m; i++) {
      printf("      ");
      for (int j=0; j<n; printf("%6.2f", a[i][j++]));
      printf("\n");
    }
    printf("      "); 
    for (int j=0; j<n; j++) printf("------");
    printf("\n"); printf("      "); 
    for (int j=0; j<n; printf("%6.2f", s[j++]));
    printf("\n");
  }
}
