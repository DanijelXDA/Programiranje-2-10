// matrica2.c - Stepenovanje simetri�ne matrice.

#include <stdio.h>
#include <stdlib.h>

int main() {
  while(1) {
    // �itanje dimenzije matrice:
    printf("\nDimenzija matrice? ");
    int m; scanf("%d", &m);
  if (m <= 0) break;

    // �itanje elemenata matrice:
    long **a = malloc(m*sizeof(long*));
    long **b = malloc(m*sizeof(long*));
    long **c = malloc(m*sizeof(long*));
    for (int i=0; i<m; i++) {
      a[i] = malloc((i+1)*sizeof(long));
      b[i] = calloc(i+1, sizeof(long));
      c[i] = malloc((i+1)*sizeof(long));
      printf("%2d. vrsta? ", i+1);
      for (int j=0; j<=i; scanf("%ld", &a[i][j++]));
      b[i][i] = 1;
    }

    // �itanje stepena:
    printf("Stepen? "); int n; scanf("%d", &n);

    // Stepenovanje matrice:
    for (int st=1; st<=n; st++) {
      for (int i=0; i<m; i++)
        for (int k=0; k<=i; k++) {
          c[i][k] = 0;
          for (int j=0; j<m; j++)
            c[i][k] += (i>j?a[i][j]:a[j][i]) * (j>k?b[j][k]:b[k][j]);
        }
      long **d = c; c = b; b = d;
    }

    // Ispisivanje rezultata:
    printf("\n%d. stepen matrice:\n", n);
    for (int i=0; i<m; i++) {
      for (int j=0; j<=i;
           printf("%7ld", b[i][j++]));
      printf("\n");
    }

    // Uni�tavanje matrica:
    for (int i=0; i<m; i++) {
      free(a[i]); free (b[i]); free (c[i]);
    }
    free(a); free(b); free(c);
  }
}
