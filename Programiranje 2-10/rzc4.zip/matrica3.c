// matrica3.c - Obrada matrica u tekstualnim datotekama.

#include <stdio.h>
#define N 50

typedef float Matr[N][N];

// R(m,n) = P(m,n) + Q(m,n)
void zbir(const Matr p, const Matr q, Matr r, int m, int n) {
  for (int i=0; i<m; i++)
    for (int j=0; j<n; j++)
      r[i][j] = p[i][j] + q[i][j];
}

// R(m,n) = P(m,n) - Q(m,n)
void razlika(const Matr p, const Matr q, Matr r, int m, int n) {
  for (int i=0; i<m; i++)
    for (int j=0; j<n; j++)
      r[i][j] = p[i][j] - q[i][j];
}

// R(l,n) = P(l,m) * Q(m,n)
void proizvod(const Matr p, const Matr q, Matr r, int l, int m, int n) {
  for (int i=0; i<l; i++)
    for (int k=0; k<n; k++) {
      r[i][k] = 0;
      for (int j=0; j<m; j++)
        r[i][k] += p[i][j] * q[j][k];
    }
}

_Bool citaj(FILE *dat, Matr p, int *m, int *n) {
  fscanf(dat, "%d%d", m, n);
  if (*m<=0 || *m>N || *n<=0 || *n>N) return 0;
  for (int i=0; i<*m; i++)
    for (int j=0; j<*n; fscanf(dat, "%f", &p[i][j++]));
  return 1;
}
 
void pisi(FILE *dat, const char *naslov, const Matr p, int m, int n,
          const char *frm, int k) {
  fprintf(dat, "\n%s\n\n", naslov);
  for (int i=0; i<m; i++) {
    for (int j=0; j<n; j++) {
      fprintf(dat, frm, p[i][j]);
      if (j%k==k-1 || j==n-1) fputc('\n', dat);
    }
    if (n > 10) fputc('\n', dat);
  }
}

int main() {
  while (1) {
    printf("Ulazna datoteka?  "); char ulaz[20];  scanf("%s", ulaz );
  if (ulaz[0] == '*') break;
    printf("Izlazna datoteka? "); char izlaz[20]; scanf("%s", izlaz);
    FILE *ul  = fopen(ulaz,  "r");
    FILE *izl = fopen(izlaz, "w");
    Matr a, b, c; int ma, na, mb, nb;
    while (citaj(ul, a, &ma, &na) && citaj(ul, b, &mb, &nb)) {
      pisi(izl, "Prva matrica",      a, ma, na, "%6.1f", 10);
      pisi(izl, "Druga matrica",     b, mb, nb, "%6.1f", 10);
      if (ma==mb && na==nb) {
        zbir    (a, b, c, ma, na);
        pisi(izl, "Zbir matrica",
             c, ma, na, "%6.1f", 10);
        razlika (a, b, c, ma, na);
        pisi(izl, "Razlika matrica",
             c, ma, na, "%6.1f", 10);
      }
      if (na == mb) {
        proizvod(a, b, c, ma, na, nb);
        pisi(izl, "Proizvod matrica",
             c, ma, nb, "%6.1f", 10);
      }
    }
    fclose(ul); fclose(izl);
  }
}
