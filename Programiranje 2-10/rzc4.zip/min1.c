// min1.c - Najmanji od tri broja.

#include <stdio.h>

int main() {
  printf("Tri broja? ");
  int a, b, c;
  scanf("%d%d%d", &a, &b, &c);
  int min = a;
  if (b < min) min = b;
  if (c < min) min = c;
  printf("Najmanji=  %d\n", min);
}
