// min2.c - Najmanji element niza.

#include <stdio.h>
#define N_MAX 100

int main() {
  while (1) {
    printf("n? "); int n; scanf("%d", &n);
  if (n<=0 || n>N_MAX) break;
    printf("A? "); double a[N_MAX];
    for (int i=0; i<n; scanf("%lf", &a[i++]));
    double min = a[0];
    for (int i=1; i<n; i++) if (a[i] < min) min = a[i];
    printf("min= %.2f\n\n", min);
  }
}
