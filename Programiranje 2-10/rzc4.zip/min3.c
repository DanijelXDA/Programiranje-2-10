// min3.c - Nala�enje najmanjeg elementa niza.

#include <stdio.h>
#define NMAX 100

int main() {
  while (1) {
    printf("n? "); int n; scanf("%d", &n);
  if (n<=0 || n>NMAX) break;
    printf("A? "); int a[NMAX];
    for (int *p=a; p<a+n; scanf("%d", p++));
    int min = *a;
    for (int *p=a+1; p<a+n; p++) if (*p < min) min = *p;
    printf("min= %d\n\n", min);
  }
}
