// minim.c - Nala�enje minimuma funkcije metodom deljenja intervala.

#include <math.h>

void minim(double (*f)(double), double xa, double xb, int n, double eps,
           double *xmin, double *ymin) {
  double dx = (xb - xa) / n; *xmin = xa; *ymin = (*f)(*xmin);
  while (fabs(dx)>eps*fabs(*xmin) || fabs(dx)>eps) {
    for (int i=0; i<=n; i++) {
      double x = xa+i*dx, y = (*f)(x);
      if (y < *ymin) { *xmin = x; *ymin = y; }
    }
    xa = *xmin - dx; xb = *xmin + dx; dx = (xb - xa) / n;
  }
}
