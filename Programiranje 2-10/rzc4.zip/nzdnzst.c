// nzdnzst.c - Ispitivanje funkcija nzd i nzs.

#include <stdio.h>

unsigned nzd(unsigned, unsigned);                 // Prototipi funkcija.
unsigned nzs(unsigned, unsigned);

int main() {                                      // Glavna funkcija.
  printf("    a    b  nzd  nzs\n"
         "====================\n");
  while (1) {
    unsigned a, b; scanf("%u%u", &a, &b);
  if (a==0 || b==0) break;
    printf("%5u%5u%5u%5u\n", a, b, nzd(a,b), nzs(a,b));
  }
}
