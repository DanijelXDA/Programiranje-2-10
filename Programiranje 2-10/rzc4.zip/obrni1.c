// obrni1.c � Obrtanje redosleda elemenata niza.

#include <stdio.h>
#define N_MAX 100

int main() {
  while (1) {
    printf("n? "); int n; scanf("%d", &n);
  if (n<=0 || n>N_MAX) break;
    printf("A? "); double a[N_MAX];
    for (int i=0; i<n; scanf("%lf", &a[i++]));
    for (int i=0, j=n-1; i<j; i++, j--) {
      double b = a[i]; a[i] = a[j]; a[j] = b;
    }
    printf("A="); for (int i=0; i<n; printf(" %.2f", a[i++]));
    printf("\n\n");
  }
}
