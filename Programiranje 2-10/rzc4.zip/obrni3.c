// obrni3.c � Obrtanje redosleda elemenata niza.

#include <stdio.h>
#define N 30

void obrni(int a[], int n) {
  for (int i=0, j=n-1; i<j; i++, j--)
    { int k = a[i]; a[i] = a[j]; a[j] = k; }
}

// Ispitivanje funkcije obrni.

int main() {

  while (1) {
    printf("Duzina niza?   "); int n; scanf("%d", &n);
  if (n <= 0 || n > N) break;
    printf("Elementi niza? "); int niz[N];
    for (int i=0; i<n; scanf("%d",&niz[i++]));
    obrni(niz, n);
    printf("Obrnuti niz:   ");
    for (int i=0; i<n; printf("%d ", niz[i++])); printf("\n\n");
  }
}
