// obrni4.c � Obrtanje redosleda bitova u jednoj ma�inskoj re�i.

#include <stdio.h>

unsigned obrni(unsigned k) {
  unsigned i = 0;
  for (unsigned j=~0; j!=0; j>>=1) {
    i = (i << 1) | (k & 1);
    k >>= 1;
  }
  return i;
}

int main() { // Ispitivanje funkcije obrni.
  while (1) {
    unsigned broj; scanf("%x", &broj);
  if (broj == 0x9999) break;
    printf("Procitani broj: %x\n", broj);
    printf("Obrnuti broj:   %x\n\n", obrni(broj));
  }
}
