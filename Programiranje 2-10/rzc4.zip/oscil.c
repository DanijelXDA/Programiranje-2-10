// oscil.c - Funkcija za prigu�ene oscilacije.

#include <math.h>

double oscil(double x) { return exp(-0.1 * x) * sin(x); }
