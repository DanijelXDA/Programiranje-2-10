// permut.c - Generisanje permutacija.

// Rekurzivno - generi�e sve permutacije.
void permut1(int a[], int n, int i,
             void (*f)(int[],int)) {
  if (i == n) (*f)(a, n);
  else for (int j=i; j<n; j++) {
         int b = a[i]; a[i] = a[j]; a[j] = b;
         permut1(a, n, i+1, f);
         b = a[i]; a[i] = a[j]; a[j] = b;
       }
}

// Iterativno - generi�e samo slede�u permutaciju.
_Bool permut2(int a[], int n) {
  int i=n-2; while (i>=0 && a[i]>=a[i+1]) i--;
  if (i >= 0) {
    int j=n-1; while (j>i && a[j]<=a[i]) j--;
    int b = a[j]; a[j] = a[i]; a[i] = b;
  }
  for (int j=i+1, k=n-1; j<k; j++, k--)
    { int b = a[j]; a[j] = a[k]; a[k] = b; }
  return i < 0;
}

#include <stdio.h>
#include <stdlib.h>

void pisi(int a[], int n) {           // Primer obrade jedne permutacije.
  for (int i=0; i<n; printf("%d ", a[i++])); putchar('\n');
}

int main(int bpar, const char *vpar[]) {  // Glavna funkcija.
  int n = atoi(vpar[1]), *a = malloc(n * sizeof(int));
  for (int i=0; i<n; i++) a[i] = i + 1;
  permut1(a, n, 0, pisi); putchar('\n');
  do { pisi(a, n); } while (!permut2(a, n));
}
