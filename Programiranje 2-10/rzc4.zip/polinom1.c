// polinom1.c - Tabeliranje polinoma zadatog pomo�u koeficijenata.

#include <stdio.h>

int main() {
  printf("Red polinoma? "); int n; scanf("%d", &n);
  printf("Koeficijenti? "); float poli[200];
    for (int i=n; i>=0; i--) scanf("%f", &poli[i]);
  printf("xmin,xmax,dx? "); float xmin, xmax, dx;
    scanf("%f%f%f", &xmin, &xmax, &dx);
  printf("\n       x      p(x)\n====================\n");
  for (float x=xmin; x<=xmax; x+=dx) {
    float p=poli[n];
    for (int i=n-1; i>=0; p=p*x+poli[i--]);
    printf("%10.2f%10.2f\n", x, p);
  }
}
