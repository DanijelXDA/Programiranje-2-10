// polinom3.c - Obrada polinoma.

#include <stdio.h>

typedef struct { double a[21]; int n; } Poli;

Poli zbir    (Poli p1, Poli p2) { // Zbir dva polinoma.
  Poli p;
  p.n = (p1.n > p2.n) ? p1.n : p2.n;
  for (int i=0; i<=p.n; i++)
    if      (i > p2.n) p.a[i] = p1.a[i];
    else if (i > p1.n) p.a[i] =           p2.a[i];
    else               p.a[i] = p1.a[i] + p2.a[i];
  while (p.n>=0 && p.a[p.n]==0) p.n--;
  return p;
}

Poli razlika (Poli p1, Poli p2) { // Razlika dva polinoma.
  Poli p;
  p.n = (p1.n > p2.n) ? p1.n : p2.n;
  for (int i=0; i<=p.n; i++)
    if      (i > p2.n) p.a[i] = p1.a[i];
    else if (i > p1.n) p.a[i] =         - p2.a[i];
    else               p.a[i] = p1.a[i] - p2.a[i];
  while (p.n>=0 && p.a[p.n]==0) p.n--;
  return p;
}

Poli proizvod(Poli p1, Poli p2) { // Proizvod dva polinoma.
  Poli p;
  p.n = (p1.n<0 || p2.n<0) ? -1 : p1.n+p2.n;
  for (int i=0; i<=p.n; p.a[i++]=0) ;
  for (int i=0; i<=p1.n; i++)
    for (int j=0; j<=p2.n; j++)
      p.a[i+j] += p1.a[i] * p2.a[j];
  return p;
}

Poli kolicnik(Poli p1, Poli p2, Poli *ostatak) { //Koli�nik dva polinoma.
  Poli p;
  p.n=p1.n-p2.n;
  for (int i=p.n; i>=0; i--) {
    p.a[i] = p1.a[p2.n+i] / p2.a[p2.n];
    for (int j=0; j<=p2.n; j++)
      p1.a[j+i] -= p2.a[j] * p.a[i];
  }
  while (p1.n>=0 && p1.a[p1.n]==0) p1.n--;
  *ostatak = p1; return p;
}

Poli citaj() { // �itanje polinoma.
  Poli p; scanf("%d", &p.n);
  for (int i=p.n; i>=0; scanf("%lf", &p.a[i--]));
  return p;
}
 
void pisi(Poli  p, char f[]) {   // Pisanje polinoma.
  printf("p[");
  for (int i=p.n; i>=0; i--) {
    printf(f, p.a[i]);
    if (i>0) putchar(',');
  }
  putchar(']');
}

int main() { // Ispitivanje prethodnih funkcija.
  while (1) {
    Poli p1 = citaj();
    Poli p2 = citaj();
  if (p2.n < 0) break;
    printf("P1    = "); pisi(p1, "%.2f"); putchar('\n');
    printf("P2    = "); pisi(p2, "%.2f"); putchar('\n');
    printf("P1+P2 = "); Poli p3 = zbir(p1, p2);
                        pisi(p3, "%.2f"); putchar('\n');
    printf("P1-P2 = "); pisi(razlika(p1,p2),      "%.2f"); putchar('\n');
    printf("P1*P2 = "); pisi(proizvod(p1,p2),     "%.2f"); putchar('\n');
    printf("P1/P2 = "); pisi(kolicnik(p1,p2,&p3), "%.2f"); putchar('\n');
    printf("P1%%P2 = ");pisi(p3, "%.2f"); putchar('\n');
    putchar('\n');
  }
}
