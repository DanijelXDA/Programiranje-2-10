// pozdrav.c - Ispisivanje pozdrava.

#include <stdio.h>

int main() {
  printf("Pozdrav svima!\n");
}
