// premesti.c - Zamena najmanjeg i najve�eg elementa matrice.

#include <stdio.h>
#define N 30

int main() {

  // �itanje matrice:
  char ime[20]; printf("Ime ulazne datoteke?  "); scanf("%s", ime);
  FILE *dat = fopen(ime, "r");
  int m, n; fscanf(dat, "%d%d", &m, &n);
  int a[N][N];
  for (int i=0; i<m; i++)
    for (int j=0; j<n; fscanf(dat, "%d", &a[i][j++]));
  fclose(dat);

  // Nala�enje mesta najmanjeg i najve�eg elementa:
  int min = a[0][0], max = min, imin = 0, jmin = 0, imax = 0, jmax = 0;
  for (int i=0; i<m; i++)
    for (int j=0; j<n; j++)
      if (a[i][j] < min) {
        min  = a[i][j]; imin = i; jmin = j;
      } else if (a[i][j] > max) {
        max  = a[i][j]; imax = i; jmax = j;
      }

  // Me�usobna zamena dve vrste i dve kolone:
  for (int i=0; i<m; i++)
    { int b = a[i][jmin]; a[i][jmin] = a[i][jmax]; a[i][jmax] = b; }
  for (int j=0; j<n; j++)
    { int b = a[imin][j]; a[imin][j] = a[imax][j]; a[imax][j] = b; }

  // Upisivanje rezultata u datoteku:
  printf("Ime izlazne datoteke? "); scanf("%s", ime);
  dat = fopen(ime, "w"); fprintf(dat, "%d %d\n", m, n);
  for (int i=0; i<m; i++) {
    for (int j=0; j<n; fprintf(dat, "%d ", a[i][j++]));
    fputc('\n', dat);
  }
  fclose(dat);
}
