// pretraz.c - Pretra�ivanje niza.

#define NE 0
#define DA 1

// Sekvencijalno pretra�ivanje.
// (neure�en niz)
_Bool sektra1(const int a[], int n, int b) {
  for (int i=0; i<n; i++)
    if (a[i] == b) return DA;
  return NE;
}

// (ure�en niz)
_Bool sektra2(const int a[], int n, int b) {
  int i = 0;
  while (i<n && a[i]<b) i++;
  return i<n && a[i]==b;
}

// Binarno pretra�ivanje.
_Bool bintra(const int a[], int n, int b) {
  int d = 0, g = n-1;
  while (d <= g) {
    int s = (d + g) / 2;
    if (a[s] == b)
      return DA;
    else if (b < a[s])
      g = s - 1;
    else
      d = s + 1;
  }
  return NE;
}
 
// Glavna funkcija za prikazivanje rada prethodnih funkcija.
#include <stdio.h>

int main() {///
  int a[30], b[10], na=0, nb=0, i;
  char z, *rez[] = {"ne", "da"};

  // �itanje niza za pretra�ivanje:
  printf("Rastuci niz brojeva? ");
  do scanf("%d%c", &a[na++], &z); while (z != '\n');     // do kraja reda

  // �itanje brojeva za tra�enje:
  printf("Neuredjeni niz brojeva? ");
  do scanf("%d%c", &b[nb++], &z); while (z != '\n');    // do kraja reda

  // Pretra�ivanje niza:
  printf("\n    b sek1 sek2  bin\n"
            "====================\n");
  for (i=0; i<nb; i++)
    printf("%5d%5s%5s%5s\n", b[i], rez[sektra1(a,na,b[i])], 
                                   rez[sektra2(a,na,b[i])],
                                   rez[bintra (a,na,b[i])]);
}
