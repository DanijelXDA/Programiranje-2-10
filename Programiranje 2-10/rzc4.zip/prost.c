// prost.c - Ispitivanje da li je broj prost.

_Bool prost(unsigned p) {
  if (p == 1) return 0;
  if (p == 2) return 1;
  for (unsigned k=2; k*k<=p; k++) if (p%k == 0) return 0;
  return 1;
}

// Ispitivanje funkcije prost.

#include <stdio.h>

int main() {
  while (1) {
    printf("Broj? "); unsigned b; scanf("%u", &b);
  if (b == 9999) break;
    puts(prost(b) ? "Broj je prost." : "Broj nije prost.");
  }
}
