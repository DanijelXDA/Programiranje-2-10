// putevi.c - Pronala�enje puteva izmedju gradova.

#include <stdio.h>
#define N 30

int a[N][N], n,                    // Matrica susedstva.
    put[N], m,                     // Prona�eni put.
    poc, kraj;                     // Po�etno i krajnje mesto.

void pisi()                        // Ispisivanje puta.
  { for (int i=0; i<m; printf("%d ", put[i++])); putchar('\n'); }

void nadji(int k) {                // Nala�enje puta polaze�i iz mesta k.
  put[m++] = k;
  if (k == kraj) pisi();           // Stiglo se u odredi�no mesto.
  else for (int i=0; i<n; i++)
         if (a[k][i]!=0) {         // Postoji put iz k u i ...
           int j=0; while (j<m && i!=put[j]) j++;
           if (j == m) nadji(i);   // ... i je novo mesto, idi dalje.
         }
  m--;
}

int main() {                      // Glavna funkcija.
  scanf("%d", &n);
  printf("MATRICA SUSEDSTVA:\n\n");
  for (int i=0; i<n; i++) {
    for (int j=0; j<n; j++)
      { scanf("%d", &a[i][j]); printf("%3d", a[i][j]);}
    putchar('\n');
  };
  while (1) {
    scanf("%d%d", &poc, &kraj); m = 0;
  if (poc<0 || poc>=N || kraj<0 || kraj>=N) break;
    printf("\nPutevi od %d do %d:\n", poc, kraj);
    nadji(poc);
  }
}
