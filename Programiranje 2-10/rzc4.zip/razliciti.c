// razliciti.c - Broj razli�itih elemenata niza.

int razliciti(const int niz[], int n) {
  int rez=0;
  for (int i=0; i<n; i++) {
    int j = 0; while (j<i && niz[j]!=niz[i]) j++;
    if (j == i) rez++;
  }
  return rez;
}

// Ispitivanje funkcije razliciti.

#include <stdio.h>
#define N 50

int main() {
  while (1) {
    printf("Duzina niza?   "); int n; scanf("%d", &n);
  if (n <= 0 || n > N) break;
    printf("Elementi niza? "); int niz[N];
    for (int i=0; i<n; scanf("%d",&niz[i++]));
    printf("Broj razlicitih elemenata je %d\n\n", razliciti(niz,n));
  }
}
