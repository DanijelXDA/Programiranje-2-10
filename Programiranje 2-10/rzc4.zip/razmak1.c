// razmak1.c - Izostavljanje suvi�nih razmaka me�u re�ima.

#include <stdio.h>
#define F 0
#define T 1

int main() {
  int znak; _Bool ima = T;

  while ((znak = getchar()) != EOF)
    if (znak != ' ' && znak != '\t')
      { putchar(znak); ima = znak == '\n'; }
    else if (!ima) { putchar(' '); ima = T; }
}
