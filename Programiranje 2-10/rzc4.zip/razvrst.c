// razvrst.c - Razvrstavanje elemenata niza.

#include <stdio.h>
#define N 100

int main() {
  while (1) {
    printf("\nn? "); int na; scanf("%d", &na);
  if (na<=0 || na>N) break;
    printf("A? "); int a[N]; for (int i=0; i<na; scanf("%d", &a[i++]));
    int b[N], c[N], nb = 0, nc = 0;
    for (int i=0; i<na; a[i]<0 ? (b[nb++]=a[i++]) : (c[nc++]=a[i++]));
    printf("B= "); for (int i=0; i<nb; printf("%d ", b[i++])); printf("\n");
    printf("C= "); for (int i=0; i<nc; printf("%d ", c[i++])); printf("\n");
  }
}
