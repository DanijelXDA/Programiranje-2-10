// red1.c - Definicije paketa za redove ograni�enog kapaciteta.

#include "red1.h"
#include <stdio.h>
#include <stdlib.h>

Red stvori(int k) {                    // Stvaranje praznog reda.
  return (Red){malloc(k * sizeof(int)), k, 0, 0, 0};
}

void stavi(Red *rd, int b) {           // Stavljanje broja u red.
  if (rd->duz == rd->kap) exit(1);
  rd->niz[rd->posl++] = b; rd->duz++;
  if (rd->posl == rd->kap) rd->posl = 0;
}
int uzmi(Red *rd) {                        // Uzimanje broja iz reda.
  if (rd->duz == 0) exit(2);
  int b = rd->niz[rd->prvi++]; rd->duz--;
  if (rd->prvi == rd->kap) rd->prvi = 0;
  return b;
}

_Bool prazan(Red rd) { return rd.duz == 0; }      // Da li je red prazan?

_Bool pun   (Red rd) { return rd.duz == rd.kap; } // Da li je red pun?

void pisi (Red rd) {                       // Ispisivanje sadr�aja reda.
  for (int i=0; i<rd.duz; printf("%d ", rd.niz[(rd.prvi + i++) % rd.kap]));
}

void prazni(Red *rd)                       // Pra�njenje reda.
  { rd->duz = rd->posl = rd->prvi = 0; }

void unisti(Red *rd) { free(rd->niz); }    // Uni�tavanje reda.
