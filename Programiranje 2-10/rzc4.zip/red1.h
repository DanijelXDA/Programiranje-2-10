// red1.h - Deklaracije paketa za redove ograni�enog kapaciteta.

typedef struct { int *niz, kap, duz, prvi, posl; } Red;

Red   stvori(int k);                   // Stvaranje praznog reda.
void  stavi (Red *rd, int b);          // Stavljanje broja u red.
int   uzmi  (Red *rd);                 // Uzimanje broja iz reda.
_Bool prazan(Red rd);                  // Da li je red prazan?
_Bool pun   (Red rd);                  // Da li je red pun?
void  pisi  (Red rd);                  // Ispisivanje sadr�aja reda.
void  prazni(Red *rd);                 // Pra�njenje reda.
void  unisti(Red *rd);                 // Uni�tavanje reda.
