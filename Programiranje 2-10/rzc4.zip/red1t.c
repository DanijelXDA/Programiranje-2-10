// red1t.c - Ispitivanje paketa za redove ograni�enog kapaciteta.

#include "red1.h"
#include <stdio.h>

int main() {
  Red rd = stvori(10); _Bool kraj = 0;
  while (!kraj) { printf("\n1. Stvaranje reda\n"
                           "2. Stavljanje podatka u red\n"
                           "3. Uzimanje podatka iz reda\n"
                           "4. Ispisivanje sadrzaja reda\n"
                           "5. Praznjenje reda\n"
                           "0. Zavrsetak rada\n\n"
                           "Vas izbor? "
                        );
    int izbor; scanf("%d", &izbor);
    switch (izbor) {
    case 1: // Stvaranje novog reda:
      printf("Kapacitet? "); int k; scanf("%d", &k);
      if (k > 0) { unisti(&rd); rd = stvori(k); }
        else printf("*** Nedozvoljeni kapacitet! ***\a\n");
      break;
    case 2: // Stavljanje podatka u red:
      if (!pun(rd)) {
        printf("Broj?      "); int b; scanf("%d", &b); stavi(&rd, b);
      } else printf("*** Red je pun! ***\a\n");
      break;
    case 3: // Uzimanje broja iz reda:
      if (!prazan(rd))
        printf("Broj=      %d\n", uzmi(&rd));
      else printf("*** Red je prazan! ***\a\n");
      break;
 
    case 4: // Ispisivanje sadr�aja reda:
      printf("Red=       "); pisi(rd); putchar('\n'); break;
    case 5: // Pra�njenje reda:
      prazni(&rd); break;
    case 0: // Zavr�etak rada:
      kraj = 1; break;
    default: // Pogre�an izbor:
      printf("*** Nedozvoljen izbor! ***\a\n"); break;
    }
  }
  return 0;
}
