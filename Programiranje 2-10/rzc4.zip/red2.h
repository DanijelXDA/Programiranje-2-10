// red2.h - Deklaracije paketa za redove neograni�enog kapaciteta.

typedef struct elem { int broj; struct elem *sled; } Elem;
typedef struct { Elem *prvi, *posl; } Red;

Red stvori(void);                      // Stvaranje praznog reda.
void stavi(Red *rd, int b);            // Stavljanje broja u red.
int uzmi(Red *rd);                     // Uzimanje broja iz reda.
_Bool prazan(Red rd);                  // Da li je red prazan?
void pisi(Red rd);                     // Ispisivanje sadr�aja reda.
void prazni(Red *rd);                  // Pra�njenje reda.
void unisti(Red *rd);                  // Uni�tavanje reda.
