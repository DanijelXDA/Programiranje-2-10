// redosled.c - Zna�aj redosleda sabiranja realnih brojeva.

#include <stdio.h>

int main() {
  while (1) {
    long n; scanf("%ld", &n);
  if (n <= 0) break;
    float s1 = 0;
    for (int i=1; i<=n; i++) s1 += 1. / i / i;
    float s2 = 0;
    for (int i=n; i>=1; i--) s2 += 1. / i / i;
    printf("%7ld %10.6f %10.6f\n", n, s1, s2);
  }
}
