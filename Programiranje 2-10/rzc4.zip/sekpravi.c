// sekpravi.c � Stvaranje sekvencijalne binarne datoteke.

#include <stdio.h>
#include <stdlib.h>

int main(int bpar, char *vpar[]) {
  FILE *ulaz  = fopen(vpar[1], "r");
  FILE *izlaz = fopen(vpar[2], "wb");
  if (ulaz!=NULL && izlaz!=NULL) {
    double x[100]; int n;
    while (fscanf(ulaz,"%d",&n) != EOF) {
      for (int i=0; i<n; fscanf(ulaz,"%lf",&x[i++])) ;
      fwrite(&n, sizeof n, 1, izlaz);
      fwrite(x, sizeof(double), n, izlaz);
    }
  } else
    printf("*** Greska %d pri otvaranju ***\a\n", errno);
}
