// sekprik.c - Prikazivanje sadr�aja sekvencijalne binarne datoteke.

#include <stdio.h>
#include <stdlib.h>

int main(int bpar, char *vpar[]) {
  FILE *ulaz;
  if ((ulaz = fopen(vpar[1], "rb")) != NULL) {
    double x[100]; int n;
    while (fread(&n, sizeof n, 1, ulaz) != 0) {
      fread(x, sizeof(double), n, ulaz);
      printf("%3d ", n);
      for (int i=0; i<n; i++) {
	      printf("%6.2lf%s", x[i],
	              (i==n-1 ? "\n" : i%8==7 ? "\n    " : " "));
      }
    }
  } else
    printf("*** Greska %d pri otvaranju ***\a\n", errno);
}
