// sekradi.c - Obrada sekvencijalne binarne datoteke.

#include <stdio.h>
#include <stdlib.h>

int main(int bpar, char *vpar[]) {
  FILE *ulaz, *poz, *neg; int g = 0;
  if      ((ulaz = fopen(vpar[1], "rb")) == NULL) g = 1;
  else if ((poz  = fopen(vpar[2], "wb")) == NULL) g = 2;
  else if ((neg  = fopen(vpar[3], "wb")) == NULL) g = 3;
  else {
    double x[100]; int n;
    while (fread(&n, sizeof n, 1, ulaz) != 0) {
      fread(x, sizeof(double), n, ulaz);
      double s = 0;
      for (int i=0; i<n; s+=x[i++]);
      if (s) {
        fwrite(&n, sizeof n, 1, (s>0 ? poz : neg));
        fwrite(x, sizeof(double), n, (s>0 ? poz : neg));
      }
    }
  }
  if (g) printf("*** Greska %d pri otvaranju datoteke %d\n", errno, g);
  return g;
}
