// sinus.c - Izra�unavanje sin(x) pomo�u Tejlorovog razvoja.

#include <stdio.h>
#include <math.h>

double sinus(double x, int n) {
  double sinx = x, clan = x; int i;
  for (i=1; i<n; i++) { clan *= - x * x / (2*i) / (2*i+1) ; sinx += clan; }
  return sinx;
}

int main() {
  double xmin, xmax, dx;
  printf("xmin, xmax, dx? "); scanf("%lf%lf%lf", &xmin, &xmax, &dx);
  int    nmin, nmax, dn;
  printf("nmin, nmax, dn? "); scanf("%d%d%d",    &nmin, &nmax, &dn);
  int k = printf("\n%6s %12s %3s %14s %10s\n",
             "x", "sinxt", "n", "sinx", "relgr");
  for (int i=0; i<k-2; i++) putchar('='); putchar('\n');
  for (double x=xmin; x<=xmax; x+=dx)
    for (int n=nmin; n<=nmax; n+=dn) {
      double sinx  = sinus(x, n);                 // Izra�unata vrednost.
      double sinxt = sin(x);                      // Ta�na vrednost.
      double apsgr = sinx - sinxt;                // Apsolutna gre�ka.
      double relgr = sinxt!=0 ? apsgr/sinxt :     // Relativna gre�ka.
                     relgr >0 ?  1e38       :
                     relgr <0 ? -1e38       : 0;
      printf("%6.2f %#12.7g %3d %#14.7g %10.2e\n", x,sinxt,n,sinx,relgr);
    }
}
