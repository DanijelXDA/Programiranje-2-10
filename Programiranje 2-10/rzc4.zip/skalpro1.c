// skalpro1.c - Skalarni proizvod dva vektora.

#include <stdio.h>
#define DIM 50

int main() {
  while (1) {
    printf("\nDuzina vektora (najvise %d)? ", DIM);
    int n; scanf("%d", &n);
  if (n <= 0 || n > DIM) break;
    printf("Komponente vektora A? ");
    double a[DIM];
    for (int i=0; i<n; scanf("%lf", &a[i++]));
    printf("Komponente vektora B? ");
    double b[DIM];
    for (int i=0; i<n; scanf("%lf", &b[i++]));
    double skal_pro = 0;
    for (int i=0; i<n; i++) skal_pro += a[i] * b[i];
    printf("Skalarni proizvod A*B= %10.3f\n", skal_pro);
  }
}
