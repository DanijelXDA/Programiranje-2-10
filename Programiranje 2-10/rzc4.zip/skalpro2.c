// skalpro2.c - Rekurzivna funkcija za ra�unanje
//              skalarnog proizvoda dva vektora.

float skalpro(const float a[], const float b[], int n) {
  return (n > 0) ? a[0] * b[0] + skalpro(a+1, b+1, n-1) : 0;
}

#include <stdio.h>

int main() {
  printf("n? "); int n; scanf("%d", &n);
  printf("A? "); float a[20]; for (int i=0; i<n; scanf("%f", &a[i++]));
  printf("B? "); float b[20]; for (int i=0; i<n; scanf("%f", &b[i++]));
  printf("s= %f\n", skalpro(a, b, n));
}
