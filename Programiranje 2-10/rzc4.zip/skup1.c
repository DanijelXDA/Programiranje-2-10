// skup1.c - Obrada skupova realnih brojeva.

#include <stdio.h>
#include <stdlib.h>

int main() {
  while (1) {
    
    // �itanje podataka:
    printf("\nn1?    "); int n1; scanf("%d", &n1);
  if (n1<0) break;
    float *s1 = malloc(n1*sizeof(float));
    printf("S1?    "); for (int i=0; i<n1; scanf("%f", &s1[i++]));
    if (n1 == 0) printf("\n");
    printf("n2?    "); int n2; scanf("%d", &n2);
  if (n2<0) break;
    float *s2 = malloc(n2*sizeof(float));
    printf("S2?    "); for (int i=0; i<n2; scanf("%f", &s2[i++]));
    if (n2 == 0) printf("\n");

    // Unija dva skupa:
    float *s3 = malloc((n1+n2)*sizeof(float));
    int n3 = 0;
    for (int i=0; i<n1; s3[n3++]=s1[i++]);
    for (int j=0; j<n2; j++) {
      int i = 0; while (i<n1 && s1[i]!=s2[j]) i++;
      if (i == n1) s3[n3++] = s2[j];
    }
    s3 = realloc(s3, n3*sizeof(float));
    printf("s1+s2= "); for (int i=0; i<n3; printf("%.2f ", s3[i++]));
    printf("\n");
    free (s3);
    
    // Presek dva skupa:
    s3 = malloc((n1<n2?n1:n2)*sizeof(float));
    n3 = 0;
    for (int i=0; i<n1; i++) {
      int j = 0; while (j<n2 && s1[i]!=s2[j]) j++;
      if (j < n2) s3[n3++] = s1[i];
    }
    s3 = realloc(s3, n3*sizeof(float));
    printf("s1*s2= "); for (int i=0; i<n3; printf("%.2f ", s3[i++]));
    printf("\n");
    free (s3);
 
    // Razlika dva skupa:
    s3 =  malloc(n1*sizeof(float));
    n3 = 0;
    for (int i=0; i<n1; i++) {
      int j = 0; while (j<n2 && s1[i]!=s2[j]) j++;
      if (j == n2) s3[n3++] = s1[i];
    }
    s3 =  realloc(s3, n3*sizeof(float));
    printf("s1-s2= "); for (int i=0; i<n3; printf("%.2f ", s3[i++]));
    printf("\n");
    free(s3);

    free(s1); free(s2);
  }
}
