// skup2.c - Pretvaranje niza u skup.

#include <stdio.h>
#define N 100

void skup(int a[], int *n) {
  int j = 0;
  for (int i=0; i<*n; i++) {
    int k=0; while (k<j && a[k]!=a[i]) k++;
    if (k == j) a[j++] = a[i];
  }
  *n = j;
}

// Ispitivanje funkcije skup.

int main() {
  while (1) {
    printf("Duzina niza?    "); int n; scanf("%d", &n);
  if (n<0 || n>N) break;
    printf("Elementi niza?  "); int a[N];
    if (n == 0) putchar('\n');
    for (int i=0; i<n; scanf("%d", &a[i++]));
    skup(a, &n);
    printf("Elementi skupa: ");
    for (int i=0; i<n; printf("%d ",a[i++]));
    printf("\n\n");
  }
}
