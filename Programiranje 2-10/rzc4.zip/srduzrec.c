// srduzrec.c - Srednja du�ina re�i u tekstualnoj datoteci

#include <stdio.h>
#include <ctype.h>
#include <string.h>

double sr_duz_rec_1(FILE *dat) {       // �itaju�i tekst znak po znak.
  fseek(dat, 0, SEEK_SET);
  int br_rec=0, zb_duz=0, znak; _Bool prvi=1;
  while ((znak = fgetc(dat)) != EOF) {
    if (isspace(znak))
      prvi = 1;
    else {
      zb_duz++;
      if (prvi) { br_rec++; prvi = 0; }
    }
  }
  return (double) zb_duz / br_rec;
}

double sr_duz_rec_2(FILE *dat) {       // �itaju�i tekst re� po re�.
  fseek(dat, 0, SEEK_SET);
  int br_rec=0, zb_duz=0; char rec[80];
  while ((fscanf(dat, "%s", rec)) != EOF) {
    zb_duz += strlen(rec); br_rec++;
  }
  return (double) zb_duz / br_rec;
}

int main(int bpar, char *vpar[]) {
  FILE *dat = fopen(vpar[1], "r");
  if (dat) {
    printf("Srednja duzina reci u datoteci \"%s\" je %.2f (%.2f)\n",
           vpar[1], sr_duz_rec_1(dat), sr_duz_rec_2(dat));
    fclose(dat);
  }
}
