// srvred2.c - Srednja vrednost brojeva deljivih sa tri.

#include <stdio.h>

int main() {
  double s;
  while (1) {
    printf("n? "); int n; scanf("%d", &n);
  if (n <= 0) break;
    printf("A? "); int a[n];
      for (int i=0; i<n; i++) scanf("%d", &a[i]);
    double s = 0; int k = 0;
    for (int i=0; i<n; i++)
      if (a[i] % 3 == 0 ) { s += a[i]; k++; }
    if (k) s /= k;
    printf("s= %f\n", s);
  }
}
