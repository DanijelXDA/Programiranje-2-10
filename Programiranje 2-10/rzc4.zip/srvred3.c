// srvred3.c - Srednja vrednost u zapisima tekstualne datoteke.

#include <stdio.h>
#define N 100

int main() {
  FILE *ul  = fopen("srvred3.pod", "r");
  FILE *izl = fopen("srvred3.rez", "w");
  double z=0; int n;
  while (fscanf(ul, "%d", &n) > 0) {
    double a[N], s = 0;
    for (int i=0; i<n; i++) {
      fscanf(ul, "%lf", &a[i]);
      s += a[i];
    }
    if (n) s /= n;
    z += s;
    if (s > 0) {
      fprintf(izl, "%d", n);
      for (int i=0; i<n; fprintf(izl, " %f", a[i++]));
      fprintf(izl, "\n");
    }
  }
  fclose(ul); fclose(izl);
  printf("Zbir srednjih vrednosti= %f\n", z);
}
