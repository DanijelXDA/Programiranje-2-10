// stablo.h - Deklaracije paketa za obradu sa binarnih stabala.

typedef struct cvor { int broj; struct cvor *levo, *desno; } Cvor;
typedef Cvor *Stablo;

Stablo stvori  (void);                  // Stvaranje praznog stabla.
int    vel     (Stablo stb);            // Broj �vorova u stablu.
int    zbir    (Stablo stb);            // Zbir brojeva u stablu.
void   pisi_kld(Stablo stb);            // Prefiksno ispisivanje.
void   pisi_lkd(Stablo stb);            // Infiksno ispisivanje.
void   pisi_ldk(Stablo stb);            // Postfiksno ispisivanje.
void   crtaj   (Stablo stb, int nivo);  // Grafi�ki prikaz stabla.
int    pojav   (Stablo stb, int b);     // Broj pojavljivanja u stablu.
int    min_u   (Stablo stb);            // Najmanji u ure�enom stablu.
int    max_u   (Stablo stb);            // Najve�i u ure�enom stablu.
int    min_n   (Stablo stb);            // Najmanji u neure�enom stablu.
int    max_n   (Stablo stb);            // Najve�i u neure�enom stablu.
_Bool  uredjeno(Stablo stb);            // Da li je stablo ure�eno?
Cvor  *nadji_u (Stablo stb, int b);     // Tra�enje u ure�enom stablu.
Cvor  *nadji_n (Stablo stb, int b);     // Tra�enje u neure�enom stablu.

Stablo dodaj_u (Stablo stb, int b);     // Dodavanje u ure�eno stablo.
Stablo dodaj_n (Stablo stb, int b);     // Dodavanje u neure�eno stablo.
Stablo citaj_u (int n);                 // �itanje ure�enog stabla.
Stablo citaj_n (int n);                 // �itanje neure�enog stabla.
Stablo brisi   (Stablo stb);            // Brisanje celog stabla.
Stablo izost_u (Stablo stb, int b);     // Izost. iz ure�enog stabla.
Stablo izost_n (Stablo stb, int b);     // Izost. iz neure�enog stabla.
Stablo balans_u(Stablo stb);            // Balansiranje ure�enog stabla.
Stablo balans_n(Stablo stb);            // Balansiranje neure�enog stabla.
