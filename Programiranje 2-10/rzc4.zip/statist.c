// statist.c - Srednja vrednost i standardna devijacija
//             niza realnih brojeva.

#include <stdio.h>
#include <math.h>

int main() {
  int n, i;
  printf("\nBroj elemenata niza? "); scanf("%d", &n);
  while (n > 0) {
    printf("Elementi niza? ");
    double s = 0, d = 0;
    for (i=1; i<=n; i++) { double a; scanf("%lf", &a); s += a; d += a * a; }
    s /= n; d = sqrt(d / n - s * s);
    printf("Srednja vrednost:      %.4f\n", s);
    printf("Standardna devijacija: %.4f\n", d);
    printf("\nBroj elemenata niza? "); scanf("%d", &n);
  }
}
