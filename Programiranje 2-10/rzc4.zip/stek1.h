// stek1.h - Deklaracije paketa za stekove ograni�enog kapaciteta.

typedef struct { int *niz, kap, vrh; } Stek;

Stek stvori(int k);                    // Stvaranje praznog steka.
void stavi(Stek *stk, int b);          // Stavljanje broja na stek.
int uzmi(Stek *stk);                   // Uzimanje broja sa steka.
int prazan(Stek stk);                  // Da li je stek prazan?
int pun   (Stek stk);                  // Da li je stek pun?
void pisi(Stek stk);                   // Ispisivanje sadr�aja steka.
void prazni(Stek *stk);                // Pra�njenje steka.
void unisti(Stek *stk);                // Uni�tavanje steka.
