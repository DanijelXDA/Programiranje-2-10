// stek2.c - Definicije paketa za stekove neograni�enog kapaciteta.

#include "stek2.h"
#include <stdio.h>
#include <stdlib.h>

Stek stvori() { return NULL; }         // Stvaranje praznog steka.

void stavi(Stek *stk, int b) {         // Stavljanje broja na stek.
  Elem *novi = malloc(sizeof(Elem));
  novi->broj = b; novi->sled = *stk; *stk = novi;
}

int uzmi(Stek *stk) {                  // Uzimanje broja sa steka.
  if (*stk == NULL) exit(2);
  int b = (*stk)->broj;
  Elem *stari = *stk; *stk = (*stk)->sled; free(stari);
  return b;
}

int prazan(Stek stk) { return stk == NULL; } // Da li je stek prazan?
 
void pisi (Stek stk) {                 // Ispisivanje sadr�aja steka.
  for (Elem *tek=stk; tek; tek=tek->sled) printf("%d ", tek->broj);
}

void prazni(Stek *stk) {               // Pra�njenje steka.
  while (*stk) { Elem *stari=*stk; (*stk)=(*stk)->sled; free(stari); }
}

void unisti(Stek *stk) { prazni(stk); } // Uni�tavanje steka.
