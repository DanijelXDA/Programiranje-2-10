// stek2t.c - Ispitivanje paketa za stekove neograni�enog kapaciteta.

#include "stek2.h"
#include <stdio.h>

int main() {
  Stek stk = stvori(); _Bool kraj = 0;
  while (!kraj) { printf("\n1. Stavljanje podatka na stek\n"
                           "2. Uzimanje podatka sa steka\n"
                           "3. Ispisivanje sadrzaja steka\n"
                           "4. Praznjenje steka\n"
                           "0. Zavrsetak rada\n\n"
                           "Vas izbor? "
                        );
    int izbor; scanf("%d", &izbor);
    switch (izbor) {
    case 1: // Stavljanje podatka na stek:
      printf("Broj?      "); int b; scanf("%d", &b); stavi(&stk, b); break;
    case 2: // Uzimanje broja sa steka:
      if (!prazan(stk)) printf("Broj=      %d\n", uzmi(&stk));
        else printf("*** Stek je prazan! ***\a\n");
      break;
    case 3: // Ispisivanje sadr�aja steka:
      printf("Stek=      "); pisi(stk); putchar('\n'); break;
    case 4: // Pra�njenje steka:
      prazni(&stk); break;
    case 0: // Zavr�etak rada:
      kraj = 1; break;
    default: // Pogre�an izbor:
      printf("*** Nedozvoljen izbor! ***\a\n"); break;
    }
  }
  return 0;
}
