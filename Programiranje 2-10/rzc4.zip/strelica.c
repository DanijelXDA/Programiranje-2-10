// strelica.c - Crtanje strelice na glavnom izlazu.

#include <stdio.h>

int main() {
  while (1) {
    printf("n? "); int n; scanf("%d", &n);
  if (n <= 0) break;
    putchar('\n');
    char rep = ' ';
    int nzv = 0, kor = 1;
    for (int i=1; i<=3*n; i++) {
      nzv += kor;
      for (int j=1; j<=3*n; j++) putchar(rep);
      for (int j=1; j<=nzv; j++) putchar('*');
      putchar('\n');
      if (i == n)       rep = '*';
      if (i == 3*n/2+1) kor = -1;
      if (i == 2*n)     rep = ' ';
    }
    putchar('\n');
  }
}
