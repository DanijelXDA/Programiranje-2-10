/* tabela1.c - Tabeliranje vrednosti izraza.                              */

#include <stdio.h>

main () {
  double xmin, xmax, dx, x, y;
  printf ("xmin, xmax, dx? ");
  scanf ("%lf%lf%lf", &xmin, &xmax, &dx);
  printf ("\n      x         y\n====================\n");
  for (x=xmin; x<=xmax; x+=dx) {
    y = (x*x - 2*x - 2) / (x*x +1);
    printf ("%10.3f%10.3f\n", x, y);
  }
}
