// tabela2.c - Tabeliranje vrednosti izraza.

#include <stdio.h>

int main() {
  printf("n? "); int n; scanf("%d", &n);
  printf("xmin, xmax, dx? ");
  double xmin, xmax, dx;
  scanf("%lf%lf%lf", &xmin, &xmax, &dx);
  printf("\n      x         s\n"
         "====================\n");
  for (double x=xmin; x<=xmax; x+=dx) {
    double s = 0, p = 1;
    for (int i=1; i<=n; i++)
      s += (p *= x);
    printf("%10.3f%10.3f\n", x, s);
  }
}
