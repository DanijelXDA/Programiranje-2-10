// tabela4.c - Tabeliranje realne funkcije s jednim realnim argumentom.

#include <stdio.h>

void tabela(double (*f)(double), double xmin, double xmax, double dx) {
  printf("     x       f(x)\n"
         "==================\n");
  for (double x=xmin; x<=xmax; x+=dx)
    printf("%8.2f%10.4f\n", x, (*f)(x));
}
