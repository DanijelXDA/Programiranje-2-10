// tabla.c - Crtanje �ahovske table na glavnom izlazu.

#include <stdio.h>

int main() {
  while (1) {
    printf("d? "); float d;
    scanf("%f", &d);
  if (d <= 0) break;
    putchar('\n');
    int n1 = 0.375 * d, n2 = 0.5 * d;
    char belo = ' ', crno = '*';
    for (int i=1; i<=8; i++) {
      for (int j=1; j<=n1; j++) {
        for (int k=1; k<=4; k++) {
          for (int m=1; m<=n2; m++)
            putchar(belo);
          for (int m=1; m<=n2; m++)
            putchar(crno);
        }
        putchar('\n');
      }
      char znak = belo;
      belo = crno;
      crno = znak;
    }
    putchar('\n');
  }
}
