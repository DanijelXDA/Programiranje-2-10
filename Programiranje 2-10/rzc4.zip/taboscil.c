// taboscil.c - Tabeliranje prigu�enih oscilacija.

#include <stdio.h>

double oscil(double);                 // Prototipi funkcija.
void tabela(double (*)(double), double, double, double);

int main() {                         // Glavna funkcija.
  double xmin, xmax, dx;
  printf("xmin, xmax, dx? "); scanf("%lf%lf%lf", &xmin, &xmax, &dx);
  putchar('\n');
  tabela(oscil, xmin, xmax, dx);
}
