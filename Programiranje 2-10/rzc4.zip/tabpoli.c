// tabpoli.c - Tabeliranje polinoma.

#include <stdio.h>

extern double poli[];                  // Deklaracije globalnih podataka.
extern int n;
double polinom(double);                // Prototipi funkcija.
void tabela(double (*)(double), double, double, double);

int main() {                          // Glavna funkcija.
  printf("Red polinoma? "); scanf("%d", &n);
  printf("Koeficijenti polinoma? ");
  for (int i=n; i>=0; scanf("%lf", &poli[i--]));
  printf("xmin, xmax, dx? "); double xmin, xmax, dx;
  scanf("%lf%lf%lf", &xmin, &xmax, &dx);
  putchar('\n');
  tabela(polinom, xmin, xmax, dx);
}
