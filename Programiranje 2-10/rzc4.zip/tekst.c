//**************************************************************************
// tekst.c                 POGRAM ZA URE�IVANJE TEKSTA
//**************************************************************************

#include <stdio.h>
#include <ctype.h>

//--- Parametri sistema ----------------------------------------------------
#define RED 120                    // Najve�a du�ina jednog reda.
#define DUZ 66                     // Po�etna du�ina jednog reda.

//--- Simboli�ke konstante -------------------------------------------------
#define T   1                      // Logi�ka konstanta "true".
#define F   0                      // Logi�ka konstanta "false".

//--- Pregled potprograma --------------------------------------------------
void  obradi_zn(int);              // Obrada slede�eg znaka.
_Bool smesti_zn(int);              // Sme�tanje u izlazni bafer.
void  salji_red(int);              // Slanje reda na izlaz.
int   uzmi_zn(void);               // Uzimanje slede�eg znaka.
void  vrati_zn(int);               // Vra�anje jednog znaka na izlaz.
int   uzmi_broj(int, int, int);    // Uzimanje decimalnog celog broja.

//--- Globalne promenljive -------------------------------------------------
char red[RED];                     // Izlazni bafer za jedan red.
int  duz = DUZ;                    // Du�ina izlaznih redova.
int  poz = 0;                      // Broj znakova u izlaznom redu.
int  rec = 0;                      // Broj re�i u izlaznom redu.
char stek[RED];                    // Stek za vra�ene znakove.
int  vrh = 0;                      // Broj vra�enih znakova.

//=== G l a v n a   f u n k c i j a ========================================
int main() {
  int zn;
  while ((zn = uzmi_zn()) != EOF) {
    if (isspace(zn)) zn = ' ';
    obradi_zn(zn);
 }
}

 
//=== Obrada slede�eg u�itanog znaka =======================================
void obradi_zn(int zn) {
  static _Bool upr = F,            // Komanda je zapo�eta.
               ima = T;            // Razmak je sme�ten.
  if (upr) {                       // Izvr�avanje komande.
    switch (zn) {
    case '|':                      // Smesti znak '|'.
      ima = smesti_zn(zn); break;
    case 'P':                      // Kraj pasusa.
      salji_red(F); putchar('\n'); ima = T; break;
    case 'L':                      // �irina izlaznih redova.
      duz = uzmi_broj(1, RED, DUZ); break;
    default:                       // Nepoznata komanda.
      printf("\n*** Neispravno: |%c\n", zn); break;
    }
    upr = F;
  } else if(zn == '|') {           // Sledi komanda.
    upr = T ;
  } else if(zn != ' ' || !ima) {   // Slanje znaka.
    ima = smesti_zn(zn);
  }
}

//=== Sme�tanje znaka u izlazni bafer ======================================
_Bool smesti_zn(int zn) {
  if (poz < duz) {                 // Izlazni bafer nije pun.
    red[poz++] = zn;
    if (zn == ' ') rec++;
    return zn == ' ';
  } else if (zn == ' ')            // Bafer je pun, kraj re�i.
    salji_red(F);
  else {                           // Bafer je pun, nije kraj re�i; ...
    if (rec) {                     // ... vrati zapo�etu re� na ulaz ...
      while (zn != ' ') {
        vrati_zn(zn);
        zn = red[--poz];
      }
      rec--;
    }
    salji_red(T);                  // ... i salji red na izlaz.
  }
  return T;
}
 
//=== Slanje reda na izlaz uz ravnanje =====================================
void salji_red(int ravnaj) {
  // Ulaz: ravnaj - indikator ravnanja desne ivice.
  int raz,                         // Broj umetnutih razmaka izme�u re�i.
      dod,                         // Broj dodavanja po jednog razmaka.
      po,                          // Broja� pozicija pri ispisivanju.
      re,                          // Broja� re�i pri ispisivanju.
      i;                           // Pomo�ni broja�.

  if (ravnaj && rec) {             // Dodatni broj razmaka.
    raz = (duz - poz) / rec;
    dod = (duz - poz) % rec;
  } else {
    raz = dod = 0;
  }
  for (po=0, re=0; po<poz; po++) { // Ispisivanje.
    putchar(red[po]);
    if (red[po] == ' ') {
      for (i=0; i<raz; i++) putchar(' ');
      if (re++ < dod) putchar(' ');
    }
  }
  putchar('\n'); poz = rec = 0;
}

//=== U�itavanje sled�eg znaka =============================================
int uzmi_zn(void) { return (vrh) ? stek[--vrh] : getchar(); }

//=== Vra�anje znaka na izlaz ==============================================
void vrati_zn(int zn) { stek[vrh++] = zn; }

//=== U�itavanje decimalnog broja ==========================================
int uzmi_broj(int min, int max, int podr) {
  int zn, broj = 0;
  while (isdigit(zn = uzmi_zn())) broj = broj * 10 + zn - '0';
  if (zn != '|') vrati_zn(zn);
  if (broj < min || broj > max) {
    printf("\n***Broj izvan opsega: %d\n", broj);
    broj = podr;
  }
  return broj;
}

//**************************************************************************
