// transp2.c - Transponovanje matrice.

#include <stdio.h>
#include <stdlib.h>

int main() {
  while (1) {
    // �itanje dimenzija matrice:
    printf("\nBroj vrsta i kolona? ");
    int m, n; scanf("%d%d", &m, &n);
  if (m<=0 || n<=0) break;

    // �itanje elemenata matrice:
    int **a = malloc(m*sizeof(int*));
    for (int i=0; i<m; i++) {
      a[i] = malloc(n*sizeof(int));
      printf("%2d. vrsta? ", i+1);
      for (int j=0; j<n; scanf("%d", &a[i][j++]));
    }

    // Obrazovanje transponovane matrice:
    int **b = malloc(n*sizeof(int*));
    for (int i=0; i<n; i++) {
      b[i] = malloc(m*sizeof(int));
      for (int j=0; j<m; j++) b[i][j] = a[j][i];
    }

    // Zamena stare matrice novom matricom:
    for (int i=0; i<m; free(a[i++])); free(a);
    a = b; int p = m; m = n; n = p;

    // Ispisivanje rezultata:
    printf("\nTransponovana matrica:\n");
    for (int i=0; i<m; i++) {
      for (int j=0; j<n;
           printf("%5d", a[i][j++]));
      printf("\n");
    }

    // Uni�tavanje matrice:
    for (int i=0; i<m; free(a[i++]));
    free(a);
  }
}
