// trapez.c - Nala�enje odre�enog integrala metodom trapeza.

#include <math.h>
#define MAX 20

void trapez(double (*f)(double), double xa, double xb, double eps,
            double *y, _Bool *uspeh) {
  long k = 0, n = 1; double dx  = xb - xa, y0 = 1e38;
  *y = ((*f)(xa) + (*f)(xb)) * dx * 0.5;
  while (k<=MAX && fabs(*y-y0)>eps*fabs(*y)) {
    y0 = *y; n += n; dx *= 0.5; *y = 0;
    for (int i=0; i<n; i++) *y += (*f)(xa+i*dx);
    *y = (*y + ((*f)(xa) + (*f)(xb)) * 0.5) * dx; k++;
  }
  *uspeh = k <= MAX;
}
