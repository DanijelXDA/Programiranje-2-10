// ugao6.c - Crtanje se�tougaone figure na glavnom izlazu.

#include <stdio.h>

int main() {
  int n, i, j, nzv, nrz, kor;
  while (1) {
    printf("n? "); int n; scanf("%d", &n);
  if (n <= 0) break;
    putchar('\n');
    int nzv = n, nrz = n - 1, kor = 1;
    for (int i=1; i<=2*n-1; i++) {
      for (int j=1; j<=nrz; j++) putchar(' ');
      for (int j=1; j<=nzv; j++) printf("* ");
      putchar('\n');
      if (i == n) kor = -1;
      nzv += kor; nrz -= kor;
    }
    putchar('\n');
  }
}
