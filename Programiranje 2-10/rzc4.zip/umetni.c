/* umetni.c - Umetanje broja u uredjeni niz.                              */

#include <stdio.h>
#define N 50

main () {
  int i, n, b, a[N+1];
  while (1) {
    printf ("n? "); scanf("%d", &n);
  if (n<=0 || n>N) break;
    printf ("A? "); for (i=0; i<n; scanf ("%d", &a[i++]));
    printf ("b? "); scanf ("%d", &b);
    for (i=n-1; i>=0 && a[i]>b; i--) a[i+1] = a[i];
    a[i+1] = b;
    n++;
    printf ("A= "); for (i=0; i<n; printf ("%d ", a[i++]));
    printf ("\n\n");
  }
}
