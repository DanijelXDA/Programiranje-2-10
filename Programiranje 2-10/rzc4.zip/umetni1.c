// umetni1.c - Umetanje elemenata niza u drugi niz.

#include <stdio.h>
#define N 20

int main() {
  while (1) {
    printf("m? "); int m; scanf("%d", &m);
  if (m<=0 || m>D) break;
    printf("A? "); int a[2*N];
    for (int i=0; i<m; scanf("%d", &a[i++]));
    printf("n? "); int n; scanf("%d", &n);
  if (n<=0 || n>D) break;
    printf("B? "); int b[N];
    for (int i=0; i<n; scanf("%d", &b[i++]));
    printf("p? "); int p; scanf("%d", &p);
    p = (p<0) ? 0 : (p>m) ? m : p;
    for (int i=m-1; i>=p; i--) a[i+n] = a[i];
    for (int i=0; i<n; i++) a[i+p] = b[i];
    m += n;
    printf("A= ");
    for (int i=0; i<m; printf("%d ",a[i++]));
    printf("\n\n");
  }
}
