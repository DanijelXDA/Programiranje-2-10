// umetni2.c - Umetanje broja u ure�eni niz.

#include <stdio.h>
#define N 50

int main() {
  while (1) {
    printf("n? "); int n; scanf("%d", &n);
  if (n<=0 || n>N) break;
    printf("A? "); int a[N+1]; for (int i=0; i<n; scanf("%d", &a[i++]));
    printf("b? "); int b; scanf("%d", &b);
    int i = n-1; while (i>=0 && a[i]>b) { a[i+1] = a[i]; i--; }
    a[i+1] = b;
    n++;
    printf("A= "); for (int i=0; i<n; printf("%d ", a[i++]));
    printf("\n\n");
  }
}
