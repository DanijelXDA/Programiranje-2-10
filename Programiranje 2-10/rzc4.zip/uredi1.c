// uredi1.c - Ure�ivanje tri broja.

#include <stdio.h>

int main() {
  printf("Tri broja? ");
  double a, b, c;
  scanf("%lf%lf%lf", &a, &b, &c);
  if (a > b) { double p = a; a = b; b = p; }
  if (a > c) { double p = a; a = c; c = p; }
  if (b > c) { double p = b; b = c; c = p; }
  printf("Uredjeno=  %f %f %f\n", a, b, c);
}
