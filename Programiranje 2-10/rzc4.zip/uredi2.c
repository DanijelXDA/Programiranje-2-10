// uredi2.c - Ure�ivanje niza brojeva metodom izbora.

#include <stdio.h>
#include <stdlib.h>
#define N 500

int main() {
  while (1) {

    // �itanje du�ine niza:
    printf("\nDuzina niza? "); int n;
    scanf("%d", &n);
  if (n <= 0 || n > N) break;

    // Stvaranje i ispisivanje niza:
    printf("\nPocetni niz:\n\n"); int a[N];
    for (int i=0; i<n; i++) {
      printf ("%d ", a[i] = rand() / (RAND_MAX + 1.) * 10);
      if (i%30==29 || i==n-1) printf ("\n");
    }

    // Ure�ivanje niza:
    for (int i=0; i<n-1; i++)
      for (int j=i+1; j<n; j++)
        if (a[i] > a[j]) { int b = a[i]; a[i] = a[j]; a[j] = b; }

    // Ispisivanje ure�enog niza:
    printf("\nUredjeni niz:\n\n");
    for (int i=0; i<n; i++) {
      printf("%d ", a[i]);
      if (i%30==29 || i==n-1) printf("\n");
    }
  }
}
