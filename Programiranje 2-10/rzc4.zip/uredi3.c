// uredi3.c � Ure�ivanje niza brojeva metodom umetanja.

#include <stdio.h>
#include <stdlib.h>

int main() {
  while (1) {

    // �itanje duzine niza:
    printf("\nDuzina niza? ");
    int n; scanf("%d", &n);
  if (n <= 0) break;

    // Stvaranje i ispisivanje niza:
    int *a = malloc(n*sizeof(int));
    printf("\nPocetni niz:\n\n");
    for (int i=0; i<n; i++) {
      printf("%d ", a[i] = rand() / (RAND_MAX + 1.) * 10);
      if (i%30==29 || i==n-1) printf("\n");
    }

    // Ure�ivanje niza:
    for (int i=1; i<n; i++) {
      int b = a[i], j = i-1;
      while (j>=0 && a[j]>b) { a[j+1] = a[j]; j--; }
      a[j+1] = b;
    }

    // Ispisivanje ure�enog niza:
    printf("\nUredjeni niz:\n\n");
    for (int i=0; i<n; i++) {
      printf("%d ", a[i]);
      if (i%30==29 || i==n-1) printf("\n");
    }

    // Uni�tavanje niza:
    free(a);
  }
}
