// uredi4.c - Definicije paketa za algoritme ure�ivanja.

#include "uredi4.h"

// Niz pokaziva�a na funkcije koje ostvaruju algoritme.
const Uredi metode[] = {izbor, izbor2, umet, umet2, zamena, podela};

// Niz naziva metoda ure�ivanja.
const char *nazivi[] = {
  "Metoda izbora", "Poboljsana metoda izbora",
  "Metoda umetanja", "Poboljsana metoda umetanja",
  "Metoda zamene suseda", "Metoda podele"};

// Broj algoritama.
const int br_alg = sizeof(nazivi) / sizeof(char*);

// Metoda izbora (Selection Sort).
void izbor (Niz a, int n) {
  for (int i=0; i<n-1; i++)
    for (int j=i+1; j<n; j++)
      if (a[j] < a[i]) { Elem b = a[i]; a[i] = a[j]; a[j] = b; }
}

// Pobolj�ana metoda izbora.
void izbor2(Niz a, int n) {
  for (int i=0; i<n-1; i++) {
    int m = i;
    for (int j=i+1; j<n; j++) if (a[j] < a[m]) m = j;
    if (m != i) { Elem b = a[i]; a[i] = a[m]; a[m] = b; }
  }
}
 
// Metoda umetanja (Insetrtion Sort).
void umet  (Niz a, int n) {
  for (int i=1; i<n; i++) {
    int j = i - 1; while (j>=0 && a[j]>a[j+1])
      { Elem b = a[j]; a[j] = a[j+1]; a[j+1] = b; j--; }
  }
}

// Pobolj�ana metoda umetanja.
void umet2 (Niz a, int n) {
  for (int i=1; i<n; i++) {
    Elem b = a[i];
    int j = i - 1; while (j>=0 && a[j]>b) { a[j+1] = a[j]; j--; }
    a[j+1] = b;
  }
}

// Metoda zamena suseda (Bubble Sort).
void zamena(Niz a, int n) {
  _Bool dalje = 1;
  for (int i=0; i<n-1 && dalje; i++) {
    dalje = 0;
    for (int j=n-2; j>=i; j--)
      if (a[j] > a[j+1]) {
        Elem b=a[j]; a[j]=a[j+1];
        a[j+1]=b; dalje = 1;
      }
  }
}

// Metoda podele (Quick Sort).
void podela(Niz a, int n) {
  if (n > 1) {
    int i = -1, j = n - 1;
    while (1) {
      do i++; while (a[i] < a[n-1]);
      do j--; while (j>=0 && a[j]>a[n-1]);
    if (i >= j) break;
      Elem b = a[i]; a[i] = a[j]; a[j] = b;
    }
    Elem b = a[i]; a[i] = a[n-1]; a[n-1] = b;
    podela(a, i); podela(a+i+1, n-i-1);
  }
}
