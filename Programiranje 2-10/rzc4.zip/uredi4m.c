// uredi4m.c - Merenje trajanja ure�ivanja.

#include "uredi4.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

const int alg[] = {   0,    1,    2,    3,    4,           // Algoritmi.
                        3,      5,       5};
const int duz[] = {10000, 10000, 10000, 10000, 10000,      // Duzine nizova.
                   100000, 100000, 1000000};
const int N = sizeof(alg) / sizeof(int);                   // Broj merenja.
const int K = 10;                                          // Broj ponavljanja.
const long S = 314159;                                     // Klica za generator.
int main() {
  for (int n = 0; n<N; n++) {
    int duzina=duz[n], algoritam = alg[n];
    srand(S);
    Elem *niz = malloc((long)duzina * sizeof(Elem));
    double t = 0;
    for (int k=0; k<K; k++) {
      for (int i=0; i<duzina; niz[i++]=rand()/(RAND_MAX+1.)*1000);
      clock_t t1 = clock();
      (*metode[algoritam])(niz, duzina);
      clock_t t2 = clock();
      t += (double)(t2-t1)/CLOCKS_PER_SEC;
    }
    printf("%-30s (%10d): %10.3f\n", nazivi[algoritam], duzina, t/K);
    free(niz);
  }
}
