// uredi4t.c - Ispitivanje algoritama ure�ivanja.

#include "uredi4.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Ispisivanje niza.
void pisi(const char *nasl, Niz a, int n) {
  printf("\n%s\n\n", nasl);
  for (int i=0; i<n; i++) { printf(FMTI, 7, 1, a[i]);
                            if (i%10==9 || i==n-1) putchar('\n'); }
}
 
// Glavna funkcija.
int main() {
  int duzina=1000, algoritam = 0;
  Elem *niz = malloc((long)duzina * sizeof(Elem));

  while (1) { // Ispisivanje menija:
    printf("\n1. Zadavanje duzine niza\n"
             "2. Postavljanje generatora slucajnih brojeva\n"
             "3. Izbor algoritma\n"
             "4. Primena algoritma\n"
             "9. Kraj programa\n"
             "Vas izbor? ");
    int izbor; scanf("%d", &izbor);
    switch (izbor) {

      case 1: // Zadavanje du�ine niza:
        printf("Duzina niza? "); int d; scanf("%d", &d);
        if (d > 0){
          duzina = d;
          free(niz);
          niz = malloc((long)duzina * sizeof(Elem));
        } else printf("*** Nedozvoljena duzina!\n");
        break;

      case 2: // Postavljanje generatora slu�ajnih brojeva:
        printf("Pocetna vrednost generatora? ");
        int p; scanf("%d", &p);
        srand(p);
        break;

      case 3: // Izbor algoritma:
        putchar('\n');
        for (int i=0; i<br_alg; i++)
          printf("%d. %s\n", i+1, nazivi[i]);
        printf("Vas izbor? "); scanf("%d", &izbor);
        if (izbor>0 && izbor<=br_alg) algoritam = izbor - 1;
          else printf("*** Nedozvoljeni izbor!\n");
        break;

      case 4: // Primena algoritma:
        for (int i=0; i<duzina; niz[i++]=rand()/(RAND_MAX+1.)*1000);
        if (duzina <= 100) pisi("Pocetni niz:", niz, duzina);;
        clock_t t1 = clock();
        (*metode[algoritam])(niz, duzina);
        clock_t t2 = clock();
        if (duzina <= 100) pisi("Uredjeni niz:", niz, duzina);
        else               printf("%s (%d): %.3f\n", nazivi[algoritam],
                                  duzina, (double)(t2-t1)/CLOCKS_PER_SEC);
        break;

      case 9: // Kraj programa:
        free(niz); exit(0);

      default: // Pogresan izbor:
        printf("*** Nedozvoljeni izbor!\n");
        break;
    }
  }
}
