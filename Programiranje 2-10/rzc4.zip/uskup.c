// uskup.c - Pretvaranje niza u skup.

#include <stdio.h>
#define N 30

void uskup(int a[], int *n) {
  int k = 0;
  for (int i=0; i<*n; i++) {
    int j = 0; while (j<k && a[j]!=a[i]) j++;
    if (j == k) a[k++] = a[i];
  }
  *n = k;
}

int main() {
  char ulaz[20], izlaz[20];
  printf("Ime ulazne datoteke?  "); scanf("%s", ulaz);
  printf("Ime izlazne datoteke? "); scanf("%s", izlaz);
  FILE *ul = fopen(ulaz, "r"), *izl = fopen(izlaz, "w");
  while (1) {
    int n; fscanf(ul, "%d", &n);
  if (n<0 || n>N) break;
    int a[N]; fprintf(izl, "\nNiz=  ");
    for (int i=0; i<n; i++)
      { fscanf(ul,  "%d", &a[i]); fprintf(izl, "%d ", a[i]); }
    uskup(a, &n);
    fprintf(izl, "\nSkup= ");
    for (int i=0; i<n; i++) fprintf(izl, "%d ", a[i]); fputc('\n', izl);
  }
  fclose(ul); fclose(izl);
}
