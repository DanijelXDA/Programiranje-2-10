// velceo.h - Deklaracije paketa za obradu velikih celih brojeva.

#include <stdio.h>

#define DA 1
#define NE 0
typedef _Bool Log; // Tip za logi�ke podatke.

Log nula    (const char a[], int na);
int uporedi (const char a[], int na, const char b[], int nb);
void kopiraj(const char a[], int na, char b[], int *nb);
Log zbir    (const char a[], int na, const char b[], int nb,
             char c[], int *nc);
Log razlika (const char a[], int na, const char b[], int nb,
             char c[], int *nc);
Log proizvod(const char a[], int na, const char b[], int nb,
             char c[], int *nc);
Log kolicnik(const char a[], int na, const char b[], int nb,
             char c[], int *nc, char d[], int *nd);
Log  citaj  (char a[], int *n);
void pisi   (const char a[], int n, int sir, Log grupe);
