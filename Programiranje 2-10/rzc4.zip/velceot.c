// velceot.c - Ispitivanje paketa za obradu velikih celih brojeva.

#include "velceo.h"
#include <stdio.h>
#define N 30

int main() {
  char a[N], b[N]; int na, nb;
  while (citaj(a, &na) && citaj(b, &nb)) {
    printf("a=   "); pisi(a, na, N, DA); putchar('\n');
    printf("b=   "); pisi(b, nb, N, DA); putchar('\n');
    char c[2*N]; int nc;
    printf("a+b= "); zbir(a, na, b, nb, c, &nc);
                     pisi(c, nc, N, DA); putchar('\n');
    printf("a-b= ");
    if (razlika(a, na, b, nb, c, &nc))
                    { pisi(c, nc, N, DA); putchar('\n'); }
      else            printf("ne moze\n");
    printf("a*b= "); proizvod(a, na, b, nb, c, &nc);
                     pisi(c, nc, N, DA); putchar('\n');
 
    printf("a/b= ");
    char d[N]; int nd;
    if (kolicnik(a, na, b, nb, c, &nc, d, &nd)) {
                        pisi(c, nc, N, DA); putchar('\n');
      printf("a%%b= "); pisi(d, nd, N, DA); putchar('\n');
    } else              printf("ne moze\n");
    putchar('\n');
  }
}

