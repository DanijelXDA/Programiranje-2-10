// verizni.c - Izra�unavanje vrednosti veri�nog razlomka

#include <stdio.h>
#define N 30

double v(double a[], int n, double x) {
  double u = 0;
  for (int i=n-1; i>=0; u=a[i--]/(x+u));
  return u;
}

int main() {
  FILE *ul  = fopen("verizni.pod", "r");
  FILE *izl = fopen("verizni.rez", "w");
  int n; fscanf(ul, "%d", &n);
  double a[N]; fprintf(izl, "A=");
  for (int i=0; i<n; i++) {
    fscanf(ul, "%lf", &a[i]);
    fprintf(izl, " %.2f", a[i]);
  }
  fputc('\n', izl);
  double xmin, xmax, dx;
  fscanf(ul, "%lf%lf%lf", &xmin, &xmax, &dx);
  fprintf(izl, "xmin, xmax, dx= %.2f, %.2f, %.2f\n", xmin, xmax, dx);
  fprintf(izl, "\n       x          v(x)\n"
               "======================\n");
  for (double x=xmin; x<=xmax; x+=dx)
    fprintf(izl, "%10.2f%12.2f\n",
            x, v(a,n,x));
  fclose(ul); fclose(izl);
}
