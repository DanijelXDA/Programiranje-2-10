// vreme2.c - Vreme u obliku strukture od bitova.

typedef struct {
  unsigned god:12, mes:4, dan:5, sat:5, min:6;
} Vreme;

#include <stdio.h>

int main() {
  printf("Dan, mesec, godina? ");
  short god, mes, dan;
  scanf ("%hd%hd%hd", &dan, &mes, &god);
  printf("Sat, minut? ");
  short sat, min;
  scanf ("%hd%hd", &sat, &min);
  Vreme vreme;
  vreme.god = god; vreme.mes = mes; vreme.dan = dan;
  vreme.sat = sat; vreme.min = min;
  printf("Procitano: %hd.%hd.%hd %hd:%hd\n",
         vreme.dan, vreme.mes, vreme.god, vreme.sat, vreme.min);
}
