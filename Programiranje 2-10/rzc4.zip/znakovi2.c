// znakovi2.c - Brojanje slova i cifara.

#include <stdio.h>
#include <ctype.h>

int main() {
  int znak, vel_sl = 0, mal_sl = 0, cifra = 0;
  while ((znak = getchar()) != EOF) {
    vel_sl += isupper(znak) != 0;
    mal_sl += islower(znak) != 0;
    cifra  += isdigit(znak) != 0;
  }
  printf("Broj velikih slova u tekstu je %d.\n", vel_sl);
  printf("Broj malih slova u tekstu je %d.\n",   mal_sl);
  printf("Broj cifara u tekstu je %d.\n",        cifra );
}
