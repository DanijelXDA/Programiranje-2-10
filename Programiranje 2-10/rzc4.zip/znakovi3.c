// znakovi3.c - Broj pojavljivanja pojedinih cifara i slova.

#include <stdio.h>
#include <ctype.h>

void znakovi(int cifre[], int slova[]) {
  for (int i=0; i<10; cifre[i++]=0);
  for (int i=0; i<26; slova[i++]=0);
  int zn;
  while ((zn = getchar()) != EOF) {
    if (isdigit(zn)) cifre[zn-'0']++;
    if (isupper(zn)) slova[zn-'A']++;
    if (islower(zn)) slova[zn-'a']++;
  }
}

// Ispitivanje funkcije znakovi.

int main() {
  int cifre[10], slova[26];
  znakovi(cifre, slova);
  for (int i=0; i<10; i++)
    if (cifre[i]) printf("%d %3d\n", i, cifre[i]);
  for (int i=0; i<26; i++)
    if (slova[i]) printf("%c %3d\n", i+'a', slova[i]);
}
